@include('backend.admin.includes.header')
<style>
    
    .color-check{
      background-color: rgba(250, 249, 249, 0.3);
      border-radius: 5px;
      margin: auto auto;
      padding: 40px;
      position:absolute;
      left: 0;
      right: 0;
      width: 550px;
      top:50%;
    }

   .color-check:before {
     background-image: url('{{ asset('/simple_admin/images/TV_App.png') }}');
      width: 100%;
      height: 100%;
      background-size: cover;
      content: "";
      position: fixed;
      left: 0;
      right: 0;
      top: 0;
      bottom: 0;
      z-index: -1;
      filter: blur(0px);

    }
        .text{
          color:white;
        }
  </style>
  <body>
    <section>
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="wrapper-page">
              <div class="m-t-40 card-box color-check">
                <div class="text-center">
                  <h2 class="text-uppercase m-t-0 m-b-30">
                      <span class="text">
                        <img class="rounded-circle image" src="{{asset('simple_admin/images/nissan_chhap.png')}}"
                         alt="" height="50" width="50"
                      /> डिजिटल सूचना बोर्ड</span>
                  </h2>
                </div>
                <div class="account-content">
                    <!-- Session Status -->
                    <x-auth-session-status class="mb-4" :status="session('status')" />

                    <!-- Validation Errors -->
                    <x-auth-validation-errors class="mb-4" :errors="$errors" />
                    <form method="POST" action="{{ route('login') }}">
                        @csrf
                        <div class="form-group m-b-20 text">
                          <div class="col-12">
                            <label for="emailaddress">प्रयोगकर्ताको इमेल</label>
                            <input
                              class="form-control"
                              type="email"
                              id="emailaddress"
                              name="email"
                              required=""
                              placeholder="प्रयोगकर्ताको इमेल हाल्नुहोस"
                            />
                          </div>
                        </div>

                        <div class="form-group m-b-20 text">
                          <div class="col-12">
                            <label for="password">पास्वोर्ड</label>
                            <input
                              class="form-control"
                              type="password"
                              required=""
                              id="password"
                              name="password"
                              placeholder="प्रयोगकर्ताको पास्वोर्ड हाल्नुहोस"
                            />
                          </div>
                        </div>

                        <div class="form-group m-b-30 text">
                          <div class="col-12">
                            <div class="checkbox checkbox-primary">
                              <input id="checkbox5" type="checkbox"/ style=" width: 20px;
                              height: 20px; border:solid #FFFFFF;">
                              <label for="checkbox5" class="text-light ml-2">
                                Remember me
                              </label>
                            </div>
                          </div>
                        </div>

                        <div class="form-group account-btn text-center m-t-10">
                          <div class="col-12">
                            <button
                              class="btn btn-lg btn-primary btn-block"
                              type="submit"
                            >
                              लग इन 
                            </button>
                          </div>
                        </div>
                  </form>

                  <div class="clearfix"></div>
                </div>
              </div>
              <!-- end card-box-->

              {{-- <div class="row m-t-50">
                <div class="col-sm-12 text-center">
                  <p class="text-muted">
                    Don't have an account?
                    <a href="pages-register.html" class="text-dark m-l-5"
                      >Sign Up</a
                    >
                  </p>
                </div>
              </div> --}}
            </div>
            <!-- end wrapper -->
          </div>
        </div>
      </div>
    </section>
  </body>
@include('backend.admin.includes.footer')
