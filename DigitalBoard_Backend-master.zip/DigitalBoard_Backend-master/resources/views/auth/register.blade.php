@extends('layouts.app')

@section('dashboard_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('breadcum_title')
<li class="breadcrumb-item active"> <a href="{{route('user.index')}}">प्रयोगकर्ता</a></li>
<li class="breadcrumb-item active"> <a href="{{ route('register') }}">नँया</a></li>
@endsection

@section('create_button')
<a href="{{ route('user.index') }}" data-toggle="modal" data-placement="top" title="प्रयोगकर्ता"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>
@endsection

@section('box_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('content')
        <x-guest-layout>
            <section>
                <div>
                    <div class="row">
                        <div class="col-lg-12">

                            <div>

                                <div class="m-t-40 card-box">
                                    <div class="text-center">
                                        <h2 class="text-uppercase m-t-0 m-b-30">
                                            <a href="index.html" class="text-dark">
                                                <span><img src="{{asset('simple_admin/images/nissan_chhap.png')}}" alt="" height="50"> नेपाल सरकार </span>
                                            </a>
                                        </h2>
                                        <!--<h4 class="text-uppercase font-bold m-b-0">Sign In</h4>-->
                                    </div>
                                    <div class="account-content">
                                        <!-- Validation Errors -->
                                        <x-auth-validation-errors class="mb-4" :errors="$errors" />
                                        <form method="POST" action="{{ route('user.register') }}" enctype="multipart/form-data" id="userForm">
                                            @csrf
            
                                                <div class="column-full">
                                                    <div class="form-group m-b-20">
                                                        <label for="username">प्रयोगकर्ताको नाम</label><sup class="text-danger">*</sup>
                                                        <input class="form-control" type="text" id="username" required=""   name="name" value="{{old('name')}}" placeholder="प्रयोगकर्ताको नाम">
                                                    </div>
                                                </div>
                                                <div class="column-full">
                                                <div class="form-group m-b-20">
                                                        <label for="emailaddress">इमेल</label><sup class="text-danger">*</sup>
                                                        <input class="form-control" type="email" id="emailaddress" name="email" required="" value="{{old('email')}}" placeholder="प्रयोगकर्ताको इमेल">
                                                    </div>
                                                </div>
                                            
                                            <div class="row">
                                                
                                                <div class="col-6">
                                                    <div class="form-group m-b-20">
                                                        <label for="password">पासवर्ड</label><sup class="text-danger">*</sup>
                                                        <input class="form-control" type="password" required="" id="password" name="password" value="{{old('password')}}" placeholder="प्रयोगकर्ताको पासवर्ड">
                                                    </div>
                                                </div>

                                            
                                                <div class="col-6">
                                                    <div class="form-group m-b-20">
                                                        <label for="password">पुन: पासवर्ड</label><sup class="text-danger">*</sup>
                                                        <input class="form-control" type="password" required="" id="password" name="password_confirmation" value="{{old('password_confirmation')}}" placeholder=" पुन: पासवर्ड">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-6">
                                                    <div class="form-group m-b-20">
                                                        <label for="userAddress">ठेगाना</label><sup class="text-danger">*</sup>
                                                        <input class="form-control" type="text" id="userAddress" name="user_address" value="{{old('user_address')}}" required="" placeholder="प्रयोगकर्ताको ठेगाना">
                                                    </div>
                                                </div> 
                                                <div class="col-6">
                                                    <div class="form-group m-b-20">
                                                        <label for="mobileNumber">मोबाइल नं</label><sup class="text-danger">*</sup>
                                                        <input class="form-control" type="text" id="mobileNumber" name="mobile_number" maxlength="10"value="{{old('mobile_number')}}" required="" placeholder="प्रयोगकर्ताको मोबाइल नं">
                                                    </div>
                                                </div> 
                                            </div> 

                                            <div class="form-group m-b-20">
                                                <div class="col-12">
                                                    <label for="userType">प्रयोगकर्ताको प्रकार </label>
                                                    <select class="form-control" name="user_type" id="userType">
                                                        @if(Auth:: user()->user_type == "Superadmin")
                                                            <option selected disabled>प्रकार छनोट </option>
                                                            <option value="Admin">Admin</option>
                                                            <option value="User">User</option>
                                                        @else
                                                            <option value="User" selected>User</option>
                                                        @endif
                                                    </select>
                                                </div>
                                            </div> 
                                            
                                            
                                            <div class="form-group m-b-20 userOffice">
                                                <div class="col-12">
                                                    <label for="userAddress">प्रयोगकर्ताको कार्यालय</label><sup class="text-danger">*</sup>
                                                    <select class="form-control" name="userOffice" id="userOffice">
                                                        <option selected disabled> कार्यालय छनोट</option>
                                                        @foreach($offices as $office)
                                                        <option value="{{$office['id']}}">{{$office['nepali_name']}}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                            
                                            <div class = "office_department_information" @if(Auth:: user()->user_type == "Superadmin") style="display:none" @endif>
                                                <div class="form-group m-b-20 userDepartment">
                                                    <div class="col-12">
                                                        <label for="userDepartment">प्रयोगकर्ताको सचिवालय/ महाशाखा / शाखा</label><sup class="text-danger">*</sup>
                                                        <select class="form-control userDepartment1" name="userDepartment" id="userDepartment">
                                                            <option selected disabled> संरचना छनोट</option>
                                                            @foreach($departments as $department)
                                                            {{-- <option value="{{$department['id']}}">{{$department['department_name']}}</option> --}}
                                                            @endforeach
                                                        </select>
                                                    </div>
                                                </div> 
                                            </div>

                                            <div class="form-group account-btn text-center m-t-10">
                                                <div class="column-full">
                                                    <button class="btn btn-lg btn-primary btn-block" type="submit">Register</button>
                                                </div>
                                            </div>

                                        </form>

                                        <div class="clearfix"></div>

                                    </div>
                                </div>
                                <!-- end card-box-->


                                <div class="row m-t-50">
                                    <div class="col-sm-12 text-center">
                                        <p class="text-muted">Already have an account?  <a href="pages-login.html" class="text-dark m-l-5">Sign In</a></p>
                                    </div>
                                </div>

                            </div>
                            <!-- end wrapper -->

                        </div>
                    </div>
                </div>
            </section>
        </x-guest-layout>
@endsection

