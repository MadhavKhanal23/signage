@extends('layouts.app')

@section('dashboard_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('breadcum_title')
<li class="breadcrumb-item active"> <a href="{{route('employee.index')}}">कर्मचारी</a></li>
<li class="breadcrumb-item active"> <a href="{{route('employee.create')}}">नँया</a></li>

@endsection

@section('create_button')
<a href="{{ route('employee.create') }}" data-toggle="modal" data-placement="top" title="नँया कर्मचारी"><i class="fa fa-plus" aria-hidden="true"></i></a>
@endsection

@section('box_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('content')
    <div class="m-t-40 card-box">
        <div class="text-center">
            <h2 class="text-uppercase m-t-0 m-b-30">
                <a href="index.html" class="text-dark">
                    <span><img src="{{asset('simple_admin/images/nissan_chhap.png')}}" alt="" height="50"> नेपाल सरकार </span>
                </a>
            </h2>
        </div>
        <div>
            @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
            @endif
        </div>
        <form method="POST" action="{{ route('employee.store') }}" enctype="multipart/form-data">
            @csrf
            <div class="form-group m-b-20">
                <div class="column-full">
                    <label>सचिवालय/ महाशाखा / शाखा</label><sup class="text-danger">*</sup>
                    <div class="input-group">
                        <select class="form-control" id="employee_office" name="employee_office">
                            <option selected disabled> सचिवालय/महाशाखा/शाखा छनौट गर्नुहोस् </option>
                            @foreach ($departments as $department)
                                <option value={{$department['id']}}>{{$department->office['nepali_name']}} - {{$department['department_name']}}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-6">
                <div class="form-group m-b-20">
                    
                        <label for="employee_name">कर्मचारी नाम</label><sup class="text-danger">*</sup>
                        <input class="form-control" type="text" id="employee_name" required=""   name="employee_name" placeholder="कर्मचारी नाम" value="{{old('employee_name')}}">
                    </div>
                </div>
                <div class="col-6">
                <div class="form-group m-b-20">
                    
                        <label for="employee_name">पद</label><sup class="text-danger">*</sup>
                        <input class="form-control" type="text" id="employee_designation" required=""   name="employee_designation" placeholder="कर्मचारी पद" value="{{old('employee_designation')}}">
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-6">
                    <div class="form-group m-b-20">
                        <label for="employee_name">ईमेल</label><sup class="text-danger">*</sup>
                        <input class="form-control" type="text" id="employee_email" name="employee_email" placeholder=" कर्मचारी ईमेल" value="{{old('employee_email')}}">
                    </div>
                </div>

                <div class="col-6">
                    <div class="form-group m-b-20">
                   
                       <label for="employeet_name">मोबाइल नं</label><sup class="text-danger">*</sup>
                       <input class="form-control" type="text" id="employee_mobile" name="employee_mobile" placeholder="मोबाइल नं" maxlength="10" value="{{old('employee_mobile')}}">
                   </div>
               </div>

                <div class="col-4">
                    <div class="form-group m-b-20">
                        <label for="employee_name">सम्पर्क नं</label><sup class="text-danger">*</sup>
                        <input class="form-control" type="text" id="employee_landline" required=""   name="employee_landline" placeholder="सम्पर्क नं" maxlength="10"  value="{{old('employee_landline')}}">
                    </div>
                </div>

                <div class="col-4">
                <div class="form-group m-b-20">
                        <label for="employee_room">कोठा नं</label><sup class="text-danger">*</sup>
                        <input class="form-control" id="employee_room" name="employee_room" value="{{old('employee_room')}}"
                          placeholder="कोठा नं" required>
                    </div>
                </div>

                <div class="col-4">
                    <div class="form-group m-b-20">
                        <label for="employee_rank">बरियेता क्रम</label><sup class="text-danger">*</sup>
                        <select class="form-control" id="employee_rank" name="employee_rank" required>
                            <option selected disabled>बरियेता क्रम छनौट गर्नुहोस्</option>
                            @for ($i = 1; $i <= 100; $i++)
                                <option value="{{$i}}">{{$i}}</option>
                            @endfor
                        </select>
                    </div>
                </div>               
            </div>
            
            <div class="form-group m-b-20">
                <div class="col-12">
                    <label class="css-control css-control-info css-checkbox"
                    style="display: inline !important; float: center;">
                    <input type="hidden" name="is_dept_head" value="0">
                    <label class="css-control-info">
                        <input type="checkbox" class="css-control-info" value="1" name="is_dept_head"
                            id="is_dept_head">
                        <span class="css-control-indicator"></span> सचिवालय/ महाशाखा / शाखा प्रमुख
                </label>
                </div>
            </div>

            <div class="row">
                <div class="col-6">
                    <label for="officeLogo">उपलब्ध</label><sup class="text-danger">*</sup>
                    <select class="form-control form-control-sm" id="employee_status" name="employee_status">
                        <option selected>छनोट गर्नुहोस</option>
                        <option value='in'> भित्र </option>
                        <option value='out'> बाहिर </option>
                        <option value='busy'> ब्यस्त </option>
                        <option value='none'> आवश्यकता छैन </option>
                    </select>
                 </div>
                <div class="col-6">
                    <div class="form-group m-b-20">
                            <label for="officeLogo">कर्मचारी फोटो</label><sup class="text-danger">*</sup>
                            <input type="file" class="filestyle select_image" data-buttonname="btn-primary" id="employee_image" name="employee_image" value="{{old('employee_image')}}" required>
                    </div>
                </div>
            </div>

        
            <div class="form-group account-btn text-center m-t-10">
                <div class="column-full">
                    <button class="btn btn-lg btn-primary btn-block" type="submit">Submit</button>
                </div>
            </div>

        </form>
    </div>
@endsection

@section('modal_content')
@endsection

@section('javascript_content')
<script type="text/javascript">
//    

</script>
@endsection
