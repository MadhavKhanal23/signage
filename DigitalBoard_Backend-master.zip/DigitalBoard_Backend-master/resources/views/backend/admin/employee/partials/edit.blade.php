<div class="m-t-40 card-box">
    <div class="text-center">
        <h2 class="text-uppercase m-t-0 m-b-30">
            <a href="index.html" class="text-dark">
                <span><img src="{{asset('simple_admin/images/nissan_chhap.png')}}" alt="" height="50"> नेपाल सरकार </span>
            </a>
        </h2>
    </div>
    <div>
        @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif
    </div>
    <form method="POST" action="{{route('employee.update',$employee['id'])}}" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <div class="form-group m-b-20">
            <div class="column-full">
                <label>सचिवालय/ महाशाखा / शाखा</label><sup class="text-danger">*</sup>
                <div class="input-group">
                    <select class="form-control" id="employee_office" name="employee_office">
                        <option selected value="{{$employee['department_id']}}">{{$employee->department->office['nepali_name']}} - {{$employee->department['department_name']}}</option>
                        @foreach ($departments as $department)
                            <option value={{$department['id']}}>{{$department->office['nepali_name']}} - {{$department['department_name']}}</option>
                        @endforeach
                    </select>
                </div>
            </div>
        </div>

        <div class="row">
            
            <div class="col-6">
                <div class="form-group m-b-20">
                    <label for="employee_name">कर्मचारी नाम</label><sup class="text-danger">*</sup>
                    <input class="form-control" type="text" id="employee_name" required=""   name="employee_name" placeholder="Employee Name" value="{{$employee['employee_name']}}">
                </div>
            </div>

            <div class="col-6">
                <div class="form-group m-b-20">
                    <label for="employee_designation">पद</label><sup class="text-danger">*</sup>
                    <input class="form-control" type="text" id="employee_designation" required=""   name="employee_designation" placeholder="Designation Name" value="{{$employee['designation']}}">
                </div>
            </div>

            <div class="col-6">
                <div class="form-group m-b-20">
                    <label for="employee_email">ईमेल</label><sup class="text-danger">*</sup>
                    <input class="form-control" type="text" id="employee_email" name="employee_email" placeholder="" value="{{$employee['email']}}">
                </div>
            </div>

            <div class="col-6">
                <div class="form-group m-b-20">
                    <label for="employee_mobile">मोबाइल नं</label><sup class="text-danger">*</sup>
                    <input class="form-control" type="text" id="employee_mobile" maxlength="10"  name="employee_mobile" placeholder="" value="{{$employee['mobile_no']}}">
                </div>
            </div>

            <div class="col-4">
                <div class="form-group m-b-20">
                    <label for="employee_landline">सम्पर्क नं</label><sup class="text-danger">*</sup>
                    <input class="form-control" type="text" id="employee_landline" required="" maxlength="9"  name="employee_landline" placeholder="" value="{{$employee['landline_no']}}">
                </div>
            </div>

            <div class="col-4">
                <div class="form-group m-b-20">
                    <label for="employee_room">कोठा नं</label><sup class="text-danger">*</sup>
                    <input class="form-control" id="employee_room" name="employee_room" value="{{$employee['room_no']}}" data-role="tagsinput" placeholder="104,105,106" required>
                </div>
            </div>

            <div class="col-4">
                <div class="form-group m-b-20">
                    <label for="employee_rank">बरियेता क्रम</label><sup class="text-danger">*</sup>
                    <select class="form-control" id="employee_rank" name="employee_rank" required>
                        <option selected value="{{$employee['rank']}}">
                            {{$employee['rank']}}
                        </option>
                        @for ($i = 1; $i <= 100; $i++)
                            <option value="{{$i}}">{{$i}}</option>
                        @endfor
                    </select>
                </div>
            </div> 
        </div>

        <div class="form-group m-b-20">
            <div class="col-12">
                <label class="css-control css-control-info css-checkbox"
                style="display: inline !important; float: center;">
                <input type="hidden" name="is_dept_head" value="0">
                <label class="css-control-info">
                    <input type="hidden" class="css-control-info" value="0" name="is_dept_head"
                        id="is_dept_head"> 
                    <input type="checkbox" class="css-control-info" value="1"{{$employee->is_dept_head || old('is_dept_head',0)=== 1 ? 'checked': 'unchecked' }} name="is_dept_head"
                        id="is_dept_head">   
                    <span class="css-control-indicator"></span> सचिवालय/ महाशाखा / शाखा प्रमुख
            </label>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <label for="employee_status">उपलब्ध</label>
                <select class="form-control form-control-sm" id="employee_status" name="employee_status">
                    <option selected value="{{$employee['current_status']}}">
                        @if($employee['current_status'] == "in") भित्र 
                        @elseif($employee['current_status'] == "out") बाहिर 
                        @elseif($employee['current_status'] == "None") आवश्यकता छैन
                        @else ब्यस्त @endif
                    </option>
                    <option value='in'> भित्र </option>
                    <option value='out'> बाहिर </option>
                    <option value='busy'> ब्यस्त </option>
                    <option value="none"> आवश्यकता छैन </option>
                </select>
             </div>
            <div class="col-md-6">
                <div class="form-group m-b-20">
                        <label for="employee_image">कर्मचारी फोटो</label>
                        <div class="form-group changed_image_show">
                            <img src="{{asset('storage/uploads/employee_image/'.$employee['image'])}}"
                             style="width:10%; border-radius:50%;" class="image_preview_popup float-right"
                               id="image_preview_popups_show">
                        </div>
                        <input type="hidden" value="{{$employee['image']}}" name="old_employee_image">
                        <input class="form-control filestyle select_image_popup" type="file" data-buttonname="btn-primary"
                         id="employee_image" name="employee_image">
                    </div>
                </div>
            </div>
            <div class="form-group account-btn text-center m-t-10">
                <div class="column-full">
                    <button type="submit" class="btn btn-lg btn-primary btn-block">Submit</button>
                </div>
            </div>
        </div>
    </form>
</div>