@foreach($employees as $employee)
    @if(Auth::user()->user_type == "Admin" || Auth::user()->user_type == "Superadmin")
        <tr id="{{$employee['id']}}" @if($employee->is_dept_head==1) style="color:#23B195" @endif data-url = "{{route('employee.edit', $employee['id'])}}">
            <td class="text-center">{{$loop->iteration}}</td>
            <td class="text-center" style="font-size:1rem" id="employee_office{{$employee->id}}">{{$employee->department->office['nepali_name'] ?? "N/A"}}</td>
                <td class="text-center" id="employee_department{{$employee->id}}">{{$employee->department['department_name'] ?? "N/A"}}</td>
                <td class="text-center" id="employee_name{{$employee->id}}">{{$employee['employee_name'] ?? "N/A"}} <br>
                    <img src="{{ URL::asset('storage/uploads/employee_image/'.$employee['image']) }}" class="thumb-md rounded-circle" alt="employee-img" height="50" width="50">
                </td>
                <td class="text-center" id="employee_room{{$employee->id}}">{{$employee['room_no']}}</td>
                <td>
                    @if($employee['publish'] ==1)
                    <div class="switchery-demo">
                        <input type="checkbox" class="employee_publish" data-publish="0" id="employee_publish{{$employee['id']}}" checked data-plugin="switchery" data-id="{{$employee['id']}}" data-status="1" data-color="#007bff" data-size="small"/>                
                    </div>
                @else
                    <div class="switchery-demo">
                        <input type="checkbox" class="employee_publish" data-publish="1" id="employee_Unpublish{{$employee['id']}}"  data-plugin="switchery" data-id="{{$employee['id']}}" data-status="1" data-color="#007bff" data-size="small"/>                
                    </div>
                @endif
                   </td>

                <td>
                    <div class="switchery-demo">
                        <input type="checkbox" class="employee_delete" data-url="{{route('employee.destroy', $employee['id'])}}" id="employee_delete{{$employee['id']}}" checked data-plugin="switchery" data-id="{{$employee['id']}}" data-status="1" data-color="#007bff" data-size="small"/>
                    </div>
                </td>
        </tr>
    @elseif(Auth::user()->user_type == "User" && Auth::user()->officeUser['office_id'] == $employee->department['office_id'])    
        <tr id="{{$employee['id']}}" @if($employee->is_dept_head==1) style="color:red" @endif data-url = "{{route('employee.edit', $employee['id'])}}">
            <td class="text-center">{{$loop->iteration}}</td>
            <td class="text-center" style="font-size:1rem" id="employee_office{{$employee->id}}">{{$employee->department->office['nepali_name'] ?? "N/A"}}</td>
                <td class="text-center" id="employee_department{{$employee->id}}">{{$employee->department['department_name'] ?? "N/A"}}</td>
                {{-- <td class="text-center">{{$employee['department_name']}}</td> --}}
                <td class="text-center" id="employee_name{{$employee->id}}">{{$employee['employee_name'] ?? "N/A"}} <br>
                    <img src="{{ URL::asset('storage/uploads/employee_image/'.$employee['image']) }}" class="thumb-md rounded-circle" alt="employee-img" height="50" width="50">
                </td>
                <td class="text-center" id="employee_room{{$employee->id}}">{{$employee['room_no']}}</td>
                {{-- <td class="text-center" id="employee_status{{$employee->id}}">{{$employee['current_status']}}</td> --}}

               <td>
                @if($employee['publish'] ==1)
                <div class="switchery-demo">
                    <input type="checkbox" class="employee_publish" data-publish="0" id="employee_publish{{$employee['id']}}" checked data-plugin="switchery" data-id="{{$employee['id']}}" data-status="1" data-color="#007bff" data-size="small"/>                
                </div>
            @else
                <div class="switchery-demo">
                    <input type="checkbox" class="employee_publish" data-publish="1" id="employee_Unpublish{{$employee['id']}}"  data-plugin="switchery" data-id="{{$employee['id']}}" data-status="1" data-color="#007bff" data-size="small"/>                
                </div>
            @endif
               </td>

                <td>
                    <div class="switchery-demo">
                        <input type="checkbox" class="employee_delete" data-url="{{route('employee.destroy', $employee['id'])}}" id="employee_delete{{$employee['id']}}" checked data-plugin="switchery" data-id="{{$employee['id']}}" data-status="1" data-color="#007bff" data-size="small"/>
                    </div>
                </td>
        </tr>
    @endif
@endforeach

