@extends('layouts.app')

@section('dashboard_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('breadcum_title')
<li class="breadcrumb-item active"> <a href="{{route('employee.index')}}">कर्मचारी</a></li>
<li class="breadcrumb-item active"> <a href="{{route('employee.gridView')}}">ग्रिड दृश्य</a></li>
@endsection

@section('create_button')
<a href="{{ route('employee.gridView') }}" data-toggle="modal"  data-placement="top" title="ग्रिड दृश्य"><i class="fa fa-th" aria-hidden="true"></i></a>&nbsp; &nbsp; &nbsp;
<a href="{{ route('employee.index') }}" data-toggle="modal" data-placement="top" title="सुची दृश्य"><i class="fa fa-th-list" aria-hidden="true"></i></a>&nbsp; &nbsp;&nbsp;
<a href="{{ route('employee.create') }}" data-toggle="modal" data-placement="top" title="नँया कर्मचारी"><i class="fa fa-plus" aria-hidden="true"></i></a>
@endsection

@section('box_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('content')
<style>
    .textsize{
        
        flex: 0 0 100%;
        font-size:14px;
        
    }
</style>


<div class="row">
    <div class="col-md-12">
        <hr>
        <center><h6>कर्मचारी</h6></center>
        <hr>
    </div>
    @foreach($employee_data as $employee)
        <div class="col-md-4 m-t-10">
            <div class="card-box" style="width:100%">
                <div class="text-center">
                    @if ($employee['image']!=null)
                        <img src="{{URL::asset('storage/uploads/employee_image/'.$employee['image']) }}" class="thumb-md rounded-circle" alt="employee-img" height="100" width="100">
                    @else
                        <img src="{{ URL::asset('/simple_admin/images/nissan_chhap.png')}}" class="thumb-md rounded-circle" alt="employee-img" height="100" width="100">
                    @endif
                    <h5 class="mt-2"> 
                        {{$employee->employee_name}}
                    </h5>
                    @if($employee['current_status'] != "none")
                        <div class="textsize">
                            <div class="button current_status" >
                                <select class="mb-6 employee_status text-white h6" id="employee_status{{$employee->id}}"  data-id="{{$employee['id']}}" style="border-radius:3px; border-color:#C8020C; height:25px; background-color:#23B195">
                                    <option selected disabled value="{{$employee['id']}}">
                                        @if($employee['current_status'] == "in") भित्र 
                                        @elseif($employee['current_status'] == "out") बाहिर 
                                        @else ब्यस्त @endif
                                    </option>
                                    <option value="in">भित्र </option>
                                    <option value="out">बाहिर </option>
                                    <option value="busy">ब्यस्त </option> 
                                    <option value="none"> आवश्यकता छैन </option>
                                </select>
                            </div>
                        </div>
                    @endif
                    <p class="mt-2"> <h6>{{$employee->department->office['nepali_name']}},</h6> {{$employee->department->department_name}}</p>
                </div>
                <div class="row mt-2 text-white" style="background-color:#23B195">
                    <div class="col-md-6 py-1 flex"><b>Designation:</b></div>
                    <div class="col-md-6 py-1 flex text-right"><b>{{$employee['designation']}}</b></div>
                    <div class="col-md-5 py-1 flex"><strong>Mobile no:</strong></div>
                    <div class="col-md-7 py-1 flex text-right"><strong>{{$employee['mobile_no']}}</strong></div>
                    <div class="col-md-4 py-1 flex"><strong> Email:</strong></div>
                    <div class="col-md-8 py-1 flex text-right"><b>{{$employee['email']}}</b></div> 
                </div>  
            </div>
        </div>
    @endforeach  
</div>
@endsection

@section('modal_content')
{{--  --}}
@endsection

@section('javascript_content')
<script>
    $(document).ready(function(){
        $('.current_status').on('change','.employee_status', function(e){
            e.preventDefault();
            e.stopPropagation(); 
            var status_id = $(this).data("id");
            var _token = $("input[name=_token]").val();
            var status = $('#employee_status'+status_id).val();
            url = "{{route('employee.status')}}";
            $.ajax({
                url:url, 
               type:"PUT",
                 data:{
                   '_token': _token,
                     'employee_id' : status_id,
                     'status': status
                        },
                success: function(data){
                    const Toast = Swal.mixin({
                                        title: 'Status Changed',
                                        toast: true,
                                        position: 'top-end',
                                    showConfirmButton: false,
                                    timer: 3000,
                                }); 
                                Toast.fire({
                                    type:'success',
                                    title:data.success
                                
                    }); 

                }
            });
        });
    });
</script>
@endsection