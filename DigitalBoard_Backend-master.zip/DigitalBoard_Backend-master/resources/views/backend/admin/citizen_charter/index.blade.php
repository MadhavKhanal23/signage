@extends('layouts.app')

@section('dashboard_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('breadcum_title')
<li class="breadcrumb-item active"> <a href="{{route('citizen_charter.index')}}">नागरिक वडापत्र</a></li>
@endsection

@section('create_button')
<a href="{{ route('citizen_charter.create') }}" data-toggle="modal" data-placement="top" title="नँया नागरिक वडापत्र"><i class="fa fa-plus" aria-hidden="true"></i></a>
@endsection

@section('box_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('content')
    <div class="row p-t-40">
        <div class="col-12">
            <hr>
            <center><h5>नागरिक वडापत्र</h5></center>
            <div class="alert alert-success alert-dismissible fade show text-center" role="alert" id="success_msg_div">
                <strong>नमस्कार {{Auth::user()->name}}!</strong> <span id="success_msg"> पङ्क्तिमा डबल किलिक गरि डाटा परिवर्तन गर्नुहोस। </span>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <hr>
            <div class="table-responsive">
                <table id="datatable" class="table table-bordered citizen_charter_table">
                    <thead>
                    <tr>
                        <th class="text-center">क्र.सं</th>
                        <th class="text-center">कार्यालय संरचना</th>
                        <th class="text-center">सेवा प्रकार</th>
                        <th class="text-center">सेवा समय</th>
                        <th class="text-center">सेवा शुल्क</th>
                        <th class="text-center">जिम्मेवार अधिकारी</th>
                        <th class="text-center">प्रकाशन</th>
                        <th class="text-center">उपलब्ध</th>
                    </tr>
                    </thead>

                    <tbody id="citizen_charter_tbody">
                        @include('backend.admin.citizen_charter.partials.active_data')
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection

@section('modal_content')
@endsection

@section('javascript_content')
    <script type="text/javascript">
        $('body .citizen_charter_table #citizen_charter_tbody').on('dblclick', 'tr', function(e){
                e.preventDefault();
                e.stopPropagation();
                var row_id = $(this).attr("id");
                Swal.fire({
                    title: 'पुनश्च !!!!',
                    text: "के तपाई परिवर्तन गर्न चाहनु हुन्छ ?",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'परिवर्तन',
                    cancelButtonText: 'रद्द'
                }).then((result) => {
                    if (result.value)
                    {
                        var url = $(this).data("url");
                        $.ajax({
                            url:url, 
                            type:"get",
                            data:{
                                'user_id' : row_id,
                            },
                            success:function(data){
                                const Toast = Swal.mixin({
                                    toast: true,
                                    position: 'top-end',
                                    showConfirmButton: false,
                                    timer: 3000,
                                });

                                Toast.fire({
                                    type:'success',
                                    title:'परिवर्तनको डाटा भर्नुहोस् ।।।'
                                });
                                $("#page_main_content").empty();
                                $("#page_main_content").html(data.html); 
                                CKEDITOR.replace('important_document'); 
                            },
                            error:function(data){
                                Swal.fire({
                                    title: 'Error',
                                    text: "Failed to Edit!",
                                    type: 'error'
                                });
                            },
                        });
                    }
                    else
                    {
                        e.dismiss;
                    }
                });
                
        });

        // for delete
        $('.citizen_charter_table #citizen_charter_tbody').on('change', '.citizen_charter_delete', function(e){
            e.preventDefault();
            e.stopPropagation();
            var citizen_id = $(this).data("id");
            var current = $('#citizen_delete'+citizen_id).data('status');
            if(current===1){
                Swal.fire({
                    title: 'पुनश्च !!!!',
                    text: "के तपाई नागरिक वडापत्रको डाटा हटाउन चाहनु हुन्छ ?",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'हटाउनु होस्',
                    cancelButtonText: 'रद्द'
                }).then((result) => {
                    if (result.value == true){
                        var _token = $("input[name=_token]").val();
                        var url = $(this).data("url");
                        $.ajax({
                            url:url, 
                            type:"DELETE",
                            data:{
                                '_token': _token
                            },
                            success:function(data){
                                const Toast = Swal.mixin({
                                    toast: true,
                                    position: 'top-end',
                                    showConfirmButton: false,
                                    timer: 3000,
                                });

                                Toast.fire({
                                    type:'success',
                                    title:'नागरिक वडापत्रको डाटा सफलता पुर्बक हटाएयो ।।।'
                                });
                                $('#citizen_charter_tbody').empty();
                                $('#citizen_charter_tbody').html(data.html);
                                $('.switchery-demo input').each(function(){
                                    new Switchery($(this)[0],{
                                        size:"small",
                                        color: '#007bff'
                                    });
                                });
                            },
                            error:function(data){
                                Swal.fire({
                                    title: 'Error',
                                    text: "Failed to Delete!",
                                    type: 'error'
                                });
                            },
                        });
                    } 
                    else {
                        e.dismiss;
                        $('#citizen_delete'+citizen_id).data('status',0); 
                        $('#citizen_delete'+citizen_id).trigger('click');
                    }
                });
            }
            $('#citizen_delete'+citizen_id).data('status',1); 
        });

        $('body .citizen_charter_table').on('change','.citizen_charter_publish',function(e){
            e.preventDefault();
            e.stopPropagation();
            var publish_id = $(this).data("id");
            var publish = $(this).data("publish");
            var div_id = $(this).attr('id');
            var current = $('#'+div_id).data('status');
            var text ="";
            var btntext = "";
            if(publish == 0)
            {
                text="के तपाई प्रकासन बाट हटाउन चाहनु हुन्छ ।।।";
                btntext = "अप्रकाशित";

            }
            else{
                text="के तपाई प्रकासन गर्न चाहनु हुन्छ ।।।";
                btntext = "प्रकासन";
            }

            if (current === 1)
            {
                Swal.fire({
                    title: 'पुनश्च !!!!',
                    text: text,
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: btntext,
                    cancelButtonText: 'रद्द'
                }).then((result) => {
                    if (result.value){
                        url = "{{route('citizen_charter.publish')}}";
                        var _token = $("input[name=_token]").val();
                        $.ajax({
                            url:url, 
                            type:"PUT",
                            data:{
                                '_token': _token,
                                'citizen_charter_id' : publish_id,
                                'publish': publish
                            },
                            success:function(data){
                                const Toast = Swal.mixin({
                                    toast: true,
                                    position: 'top-end',
                                    showConfirmButton: false,
                                    timer: 3000,
                                }); 
                                Toast.fire({
                                    type:'success',
                                    title:data.success
                                });
                                $("#citizen_charter_tbody").empty();
                                $("#citizen_charter_tbody").html(data.html);
                                $('.switchery-demo input').each(function(){
                                    new Switchery($(this)[0],{
                                        size:"small",
                                        color: '#007bff'
                                    });
                                });
                            },
                            error:function(data){
                                Swal.fire({
                                    title: 'Error',
                                    text: "Failed to Publish!",
                                    type: 'error'
                                });
                            },
                        });
                    }
                    else{
                        e.dismiss;
                        $('#'+div_id).data('status',0); 
                        $('#'+div_id).trigger('click');
                    }
                });
            }
            $('#'+div_id).data('status',1);
        });
    </script>
@endsection
