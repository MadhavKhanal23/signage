<div class="m-t-40 card-box">
    <div class="text-center">
        <h2 class="text-uppercase m-t-0 m-b-30">
            <a href="index.html" class="text-dark">
                <span><img src="{{asset('simple_admin/images/nissan_chhap.png')}}" alt="" height="50"> नेपाल सरकार </span>
            </a>
        </h2>
    </div>
    <div>
        @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif
    </div>
    <form method="POST" action="{{ route('citizen_charter.update',$citizen_charter['id']) }}" enctype="multipart/form-data">
        @csrf
        @method("PUT")
        <div class="form-group m-b-20">
            <div class="column-full">
                <label> सचिवालय/ महाशाखा / शाखा </label><sup class="text-danger">*</sup>
                <div class="input-group">
                    <select class="form-control" id="citizen_charter_department" name="citizen_charter_department">
                            <option selected value="{{$citizen_charter->department['id']}}"> 
                                {{$citizen_charter->department->office['nepali_name']}}-{{$citizen_charter->department['department_name']}}
                            </option>
                            @foreach ($department_data as $department)
                                <option value={{$department['id']}}>
                                    {{$citizen_charter->department->office['nepali_name']}}-{{$citizen_charter->department['department_name']}}
                                </option>
                            @endforeach
                    
                    </select>
                </div>
            </div>
        </div>

        <div class="column-full">
            <div class="form-group m-b-20">
                <label for="citizen_charter_name">नागरिक वडापत्र शीर्षक</label><sup class="text-danger">*</sup>
                <input class="form-control" type="text" id="citizen_charter_title" required=""   name="citizen_charter_title" placeholder="Service Type" value="{{$citizen_charter['citizen_charter_title']}}">
            </div>
        </div>
        <div class="row">
            <div class="col-6">
                <div class="form-group m-b-20">
                    <label>  जिम्मेवार अधिकारी </label><sup class="text-danger">*</sup>
                    <div class="input-group">
                        <select class="form-control" id="citizen_charter_employee" name="citizen_charter_employee">
                                <option selected value="{{$citizen_charter->employee['id']}}">{{$citizen_charter->employee['designation']}}</option>
                                @foreach ($employee_data as $employee)
                                    <option value={{$employee['id']}}>{{$employee['designation']}}</option>
                                @endforeach
                        </select>
                    </div>
                </div>
            </div>
            
            <div class="col-6">
                <div class="form-group m-b-20">
                    <label for="citizen_charter_name">सेवा प्रकार</label><sup class="text-danger">*</sup>
                    <input class="form-control" type="text" id="service_type" required=""   name="service_type" placeholder="Service Type" value="{{$citizen_charter['service_type']}}">
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-6">
                <div class="form-group m-b-20">
               
                    <label for="citizen_charter_name">सेवा समय</label><sup class="text-danger">*</sup>
                    <input class="form-control" type="text" id="service_time" required=""   name="service_time" placeholder="Service Time" value="{{$citizen_charter['service_time']}}">
                </div>
            </div>
            <div class="col-6">
                <div class="form-group m-b-20">
                    <label for="citizen_charter_name">सेवा शुल्क</label><sup class="text-danger">*</sup>
                    <input class="form-control" type="text" id="service_charge" required=""   name="service_charge" placeholder="Service Charge" value="{{$citizen_charter['service_charge']}}">
                </div>
            </div>
        </div>
        <div class="form-group m-b-20">
            <div class="column-full">
                <label for="citizen_charter_description">महत्वपूर्ण कागजात</label><sup class="text-danger">*</sup>
                <textarea class="form-control" id="important_document" name="important_document" value="" required>{{$citizen_charter['important_document']}}</textarea>
            </div>
        </div>
    
        <div class="form-group account-btn text-center m-t-10">
            <div class="column-full">
                <button class="btn btn-lg btn-primary btn-block" type="submit">Update</button>
            </div>
        </div>

    </form>
</div>