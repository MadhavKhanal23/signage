@foreach($citizen_charters as $data)
    @if(Auth::user()->user_type == "Admin" || Auth::user()->user_type == "Superadmin")
        <tr id="{{$data->id}}" data-url="{{route('citizen_charter.edit', $data['id'])}}">
            <td class="text-center">{{$loop->iteration}}</td>
            <td class="text-center" style="font-size: 1rem" >{{$data->department->office['nepali_name'] ?? "N/A"}} - {{$data->department['department_name']?? "N/A"}}</td>
            <td class="text-center" id="service_type{{$data->id}}">{{$data->service_type}}</td>
            <td class="text-center" id="service_time{{$data->id}}">{{$data->service_time}}</td>
            <td class="text-center" id="service_charge{{$data->id}}">{{$data->service_charge}}</td>

            <td class="text-center" id="important_document{{$data->id}}">{{$data->employee['employee_name']}}({{$data->employee['designation']}})</td>
            <td class="text-center">
                @if($data['publish'] ==1)
                
                    <div class="switchery-demo">
                        <input type="checkbox" class="citizen_charter_publish" data-publish="0" id="citizen_publish{{$data['id']}}" checked data-plugin="switchery" data-id="{{$data['id']}}" data-status="1" data-color="#007bff" data-size="small"/>                
                    </div>
                
                @else
                
                    <div class="switchery-demo">
                        <input type="checkbox" class="citizen_charter_publish" data-publish="1" id="citizen_Unpublish{{$data['id']}}"  data-plugin="switchery" data-id="{{$data['id']}}" data-status="1" data-color="#007bff" data-size="small"/>                
                    </div>
                @endif
            
            </td> 
            <td class="text-center">
                <div class="switchery-demo">
                    <input type="checkbox" class="citizen_charter_delete" data-url="{{route('citizen_charter.destroy', $data['id'])}}" id="citizen_delete{{$data['id']}}" checked data-plugin="switchery" data-id="{{$data['id']}}" data-status="1" data-color="#007bff" data-size="small"/>
                </div>
            </td>  
        </tr>
    @elseif(Auth::user()->user_type == "User" && Auth::user()->officeUser['office_id'] == $data->department['office_id'])
        <tr id="{{$data->id}}" data-url="{{route('citizen_charter.edit', $data['id'])}}">
            <td class="text-center">{{$loop->iteration}}</td>
            <td class="text-center" style="font-size: 1rem" >{{$data->department['department_name'] ?? "N/A"}}</td>
            <td class="text-center" id="service_type{{$data->id}}">{{$data->service_type}}</td>
            <td class="text-center" id="service_time{{$data->id}}">{{$data->service_time}}</td>
            <td class="text-center" id="service_charge{{$data->id}}">{{$data->service_charge}}</td>
            <td class="text-center" id="important_document{{$data->id}}">{{$data->employee['employee_name']}}({{$data->employee['designation']}})</td>
            <td class="text-center">
                @if($data['publish'] ==1)
                
                    <div class="switchery-demo">
                        <input type="checkbox" class="citizen_charter_publish" data-publish="0" id="citizen_publish{{$data['id']}}" checked data-plugin="switchery" data-id="{{$data['id']}}" data-status="1" data-color="#007bff" data-size="small"/>                
                    </div>
                
                @else
                
                    <div class="switchery-demo">
                        <input type="checkbox" class="citizen_charter_publish" data-publish="1" id="citizen_Unpublish{{$data['id']}}"  data-plugin="switchery" data-id="{{$data['id']}}" data-status="1" data-color="#007bff" data-size="small"/>                
                    </div>
                @endif
            
            </td> 
            <td class="text-center">
                <div class="switchery-demo">
                    <input type="checkbox" class="citizen_charter_delete" data-url="{{route('citizen_charter.destroy', $data['id'])}}" id="citizen_delete{{$data['id']}}" checked data-plugin="switchery" data-id="{{$data['id']}}" data-status="1" data-color="#007bff" data-size="small"/>
                </div>
            </td>  
        </tr>
    @endif
@endforeach