@extends('layouts.app')

@section('dashboard_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('breadcum_title')
<li class="breadcrumb-item active"> <a href="{{route('office.index')}}">कार्यालय</a></li>
@endsection

@section('create_button')
<a href="{{ route('office.gridView') }}" data-toggle="modal" data-placement="top" title="ग्रिड दृश्य"><i class="fa fa-th" aria-hidden="true"></i></a>&nbsp; &nbsp; &nbsp;
<a href="{{ route('office.index') }}" data-toggle="modal" data-placement="top" title="सुची दृश्य"><i class="fa fa-th-list" aria-hidden="true"></i></a>&nbsp; &nbsp; &nbsp;
<a href="{{ route('office.create') }}" data-toggle="modal" data-placement="top" title="नँया कार्यालय"><i class="fa fa-plus" aria-hidden="true"></i></a>
@endsection

@section('box_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('content')
    @include('backend.admin.office.partials.indexContent')
@endsection

@section('modal_content')
@endsection

@section('javascript_content')
    <script type="text/javascript">
        $('.office_table #office_tbody').on('dblclick', 'tr', function(e){
            e.preventDefault();
            e.stopPropagation();

            Swal.fire({
                title: 'पुनश्च !!!!',
                text: "के तपाई परिवर्तन गर्न चाहनु हुन्छ ?",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'परिवर्तन',
                cancelButtonText: 'रद्द'
            }).then((result) => {
                if (result.value){
                    var row_id = $(this).attr("id");
                    var url = $(this).data("url");

                    $.ajax({
                        url:url, 
                        type:"get",
                        data:{
                            'user_id' : row_id,
                        },
                        success:function(data){
                            const Toast = Swal.mixin({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                            });

                            Toast.fire({
                                type:'success',
                                title:data.message
                            });
                            $("#page_main_content").empty();
                            $("#page_main_content").html(data.html);
                            
                        },
                        error:function(data){
                            Swal.fire({
                                title: 'Error',
                                text: "Failed to Edit!",
                                type: 'error'
                            });
                        },
                    });
                } 
                else {
                    e.dismiss;
                }
            });
        });
            
        $('.office_table #office_tbody').on('change', '.office_delete', function(e){
            e.preventDefault();
            var row_id = $(this).data("id");
            var current = $('#office_delete'+row_id).data('status'); 
            if(current===1){
                Swal.fire({
                    title: 'पुनश्च !!!!',
                    text: "के तपाई कार्यालयको डाटा हटाउन चाहनु हुन्छ ?",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'हटाउनु होस्',
                    cancelButtonText: 'रद्द'
                }).then((result) => {
                    if (result.value == true){
                        var _token = $("input[name=_token]").val();
                        var url = $(this).data("url");
                        $.ajax({
                            url:url, 
                            type:"DELETE",
                            data:{
                                '_token': _token
                            },
                            success:function(data){
                                const Toast = Swal.mixin({
                                    toast: true,
                                    position: 'top-end',
                                    showConfirmButton: false,
                                    timer: 3000,
                                });

                                Toast.fire({
                                    type:'success',
                                    title:data.message
                                });
                                $('#office_tbody').empty();
                                $('#office_tbody').html(data.html);
                                $('.switchery-demo input').each(function(){
                                    new Switchery($(this)[0],{
                                        size:"small",
                                        color: '#007bff'
                                    });
                                });
                            },
                            error:function(data){
                                Swal.fire({
                                    title: 'Error',
                                    text: "Failed to Delete!",
                                    type: 'error'
                                });
                            },
                        });
                    } 
                    else {
                        e.dismiss;
                        $('#office_delete'+row_id).data('status',0); 
                        $('#office_delete'+row_id).trigger('click');
                    }
                });
            }
            $('#office_delete'+row_id).data('status',1); 
        });
    </script>
@endsection
