@foreach($offices as $office)
    @if(Auth::user()->user_type == "Admin" || Auth::user()->user_type == "Superadmin")
        <tr id="{{$office->id}}" data-url="{{route('office.edit',$office->id)}}">
            <td class="text-center">{{$loop->iteration}}</td>
            <td class="text-center">
                @if ($office['logo']!=null)
                <img src="{{ URL::asset('storage/uploads/office_logo/'.$office['logo']) }}" class="thumb-md rounded-circle" alt="user-img" height="50" width="50">
            
            @else
                <img src="{{ URL::asset('/simple_admin/images/noimages.jpg')}}" alt="user-img" height="50" width="50">
            @endif
                {{-- <img style="height:2rem; width:2rem;" src="{{asset('storage/uploads/office_logo/'.$office['logo'])}}" alt="" class="thumb-md rounded-circle"> --}}
            </td>
            <td class="text-center">
                <p style="font-size: 1rem" id="nepaliOfficeName{{$office->id}}">{{$office->nepali_name}}</p>
                <hr>
                <p style="font-size: 1rem" id="nepaliOfficeName{{$office->id}}">{{$office->english_name}}</p>
            </td>
            
            <td class="text-center" id="officeAddress{{$office->id}}">{{$office->address}}</td>
            <td class="text-center" id="officePhoneNumber{{$office->id}}">{{$office->email}}</td>
            <td class="text-center" id="officeLandLineNumber{{$office->id}}">{{$office->landline_number}}</td>
             <td class="text-center" id="officeSlogan{{$office->id}}">{{$office->slogan}}</td>
            <td class="text-center">
                <div class="switchery-demo">
                    <input type="checkbox" id="office_delete{{$office['id']}}" data-url="{{route('office.destroy',$office['id'])}}" class="office_delete" data-id="{{$office['id']}}" checked data-status="1" data-plugin="switchery" data-color="#007bff" data-size="small"/>
                </div>
            </td>
        </tr>
    @elseif(Auth::user()->user_type == "User" && Auth::user()->officeUser['office_id'] == $office['id'])
        <tr id="{{$office->id}}" data-url="{{route('office.edit',$office->id)}}">
            <td class="text-center">{{$loop->iteration}}</td>
            <td class="text-center">
                <p style="font-size: 1rem" id="nepaliOfficeName{{$office->id}}">{{$office->nepali_name}}</p></td>
            <td class="text-center">
                @if ($office['logo']!=null)
                <img src="{{ URL::asset('storage/uploads/office_logo/'.$office['logo']) }}" class="thumb-md rounded-circle" alt="user-img" height="50" width="50">
            
            @else
                <img src="{{ URL::asset('/simple_admin/images/noimages.jpg')}}" alt="user-img" height="50" width="50">
            @endif
                {{-- <img style="height:2rem; width:2rem;" src="{{asset('storage/uploads/office_logo/'.$office['logo'])}}" alt="" class="thumb-md rounded-circle"> --}}
            </td>
            <td class="text-center" id="officeAddress{{$office->id}}">{{$office->address}}</td>
            <td class="text-center" id="officePhoneNumber{{$office->id}}">{{$office->email}}</td>
            <td class="text-center" id="officeLandLineNumber{{$office->id}}">{{$office->landline_number}}</td>
            <td class="text-center" id="officeSlogan{{$office->id}}">{{$office->slogan}}</td>
            <td class="text-center">
                <div class="switchery-demo">
                    <input type="checkbox" id="office_delete{{$office['id']}}" data-url="{{route('office.destroy',$office['id'])}}" class="office_delete" data-id="{{$office['id']}}" checked data-status="1" data-plugin="switchery" data-color="#007bff" data-size="small"/>
                </div>
            </td>
        </tr>
    @endif
@endforeach