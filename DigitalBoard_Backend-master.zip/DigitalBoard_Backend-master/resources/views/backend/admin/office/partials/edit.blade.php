<div class="m-t-40 card-box">

    <div class="text-center">
        <h2 class="text-uppercase m-t-0 m-b-30">
            <a href="index.html" class="text-dark">
                <span><img src="{{asset('simple_admin/images/nissan_chhap.png')}}" alt="" height="50"> नेपाल सरकार </span>
            </a>
        </h2>
    </div>
    <div>
        @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif
    </div>
    <form method="POST" id="officeEditForm" action="{{route('office.update', $office['id'])}}" enctype="multipart/form-data">
        @csrf
        @method("PUT")
            <div class="row">
                <div class="col-6">
                    <div class="form-group m-b-20">
                        <label for="officeNepaliName">कार्यालयको नाम</label><sup class="text-danger">*</sup>
                        <input class="form-control" type="text" id="officeNepaliName" required=""   name="officeNepaliName" placeholder="कार्यालयको नाम" value="{{$office['nepali_name']}}" required>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group m-b-20">
                        <label for="officeEnglishName">कार्यालयको अंग्रेजी नाम</label><sup class="text-danger">*</sup>
                            <input class="form-control" type="text" id="officeEnglishName" required=""   name="officeEnglishName" placeholder="कार्यालयको अंग्रेजी नाम" value="{{$office['english_name']}}">
                    </div>
                </div>
            </div>
           
        
        <div class="row">
            <div class="col-6">
                <div class="form-group m-b-20">
                    <label for="emailaddress">कार्यालयको ठेगाना</label>
                    <input class="form-control" type="text" id="officeAddress" name="officeAddress" required="" placeholder="Tilottoma-02, Janakinagar" value="{{$office['address']}}" required>
                </div>
            </div>

            
             <div class="col-6">
                <div class="form-group m-b-20">
                    <label for="logo_file">कार्यालयको लोगो </label>
                    <div class="form-group changed_image_show">
                        <img src="{{URL::asset('storage/uploads/office_logo/'.$office['logo'])}}" style="width:10%; border-radius:50%;" class="image_preview_popup float-right"  id="image_preview_popups_show">
                    </div>
                    <input type="hidden" value="{{$office['logo']}}" name="oldOfficeLogo">
                    <input type="file" class="filestyle select_image_popup" data-buttonname="btn-primary" id="logo_file" name="logo_file">
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-6">
                <div class="form-group m-b-20">
                    <label for="email">इमेल </label>
                    <input class="form-control" type="email" id="email"  name="email" required="" placeholder="Office Email Address" value="{{$office['email']}}" required>
                </div>
            </div>
    
           
            <div class="col-6">
                <div class="form-group m-b-20">
                    <label for="landLineNumber">सम्पर्क नं </label>
                    <input class="form-control" type="text" id="landLineNumber" maxlength="10" name="landLineNumber" required="" value="{{$office['landline_number']}}" required>
                </div>
            </div>  
        </div>
        
        
        <div class="form-group m-b-20">
            <div class="column-full">
                <label for="officeSlogan">कार्यालयको नारा </label>
                <textarea class="form-control" type="text" id="officeSlogan" name="officeSlogan" required="" placeholder="कार्यालयको नारा" required>{{$office['slogan']}}</textarea>
            </div>
        </div>

        

        <div class="form-group account-btn text-center m-t-10">
            <div class="column-full">
                <button class="btn btn-lg btn-primary btn-block" type="submit">Submit</button>
            </div>
        </div>

    </form>
</div>