<div class="row p-t-40">
    <div class="col-12">
        <hr>
        <center><h5>कार्यालय </h5></center>
        <div class="alert alert-success alert-dismissible fade show text-center" role="alert" id="success_msg_div">
            <strong>नमस्कार {{Auth::user()->name}}!</strong> <span id="success_msg"> पङ्क्तिमा डबल किलिक गरि डाटा परिवर्तन गर्नुहोस। </span>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <hr>
        <div class="table-responsive">
            <table id="datatable" class="table table-bordered office_table">
                <thead>
                <tr>
                    <th class="text-center">क्र.सं</th>
                    <th class="text-center">लोगो</th>
                    <th class="text-center">कार्यालय नाम</th>
                    <th class="text-center">ठेगाना </th>
                    <th class="text-center">इमेल </th>
                    <th class="text-center">सम्पर्क नं </th>
                    <th class="text-center">नारा </th>
                    <th class="text-center">उपलब्ध </th>
                </tr>
                </thead>

                <tbody id="office_tbody">
                    @include('backend.admin.office.partials.activeData')
                </tbody>
            </table>
        </div>
    </div>
</div>