@extends('layouts.app')

@section('dashboard_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('breadcum_title')
<li class="breadcrumb-item active"> <a href="{{route('office.index')}}">कार्यालय</a></li>
<li class="breadcrumb-item active"> <a href="{{route('office.create')}}">नँया कार्यालय</a></li>
@endsection

@section('create_button')
<a href="{{ route('office.create') }}" data-toggle="modal" data-placement="top" title="नँया कार्यालय"><i class="fa fa-plus" aria-hidden="true"></i></a>
@endsection

@section('box_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('content')
    <div class="m-t-40 card-box">
        <div class="text-center">
            <h2 class="text-uppercase m-t-0 m-b-30">
                <a href="#" class="text-dark">
                    <span><img src="{{asset('simple_admin/images/nissan_chhap.png')}}" alt="" height="50"> नेपाल सरकार </span>
                </a>
            </h2>
        </div>
        <div>
            @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
            @endif
        </div>
        <div class="container">
            <div class="row">
               <div class="col-md-12">
                <form method="POST" action="{{ route('office.store') }}" enctype="multipart/form-data">
                    @csrf
                    <div class="row">

                        <div class="col-sm-6">
                            <div class="form-group m-b-20">
                                <label for="officeNepaliName">कार्यालयको नाम</label><sup class="text-danger">*</sup>
                                <input class="form-control" type="text" id="officeNepaliName" required=""   name="officeNepaliName" placeholder="कार्यालयको नाम" value="{{old('officeNepaliName')}}">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group m-b-20">
                                <label for="officeEnglishName">कार्यालयको अंग्रेजी नाम</label><sup class="text-danger">*</sup>
                                <input class="form-control" type="text" id="officeEnglishName" required=""   name="officeEnglishName" placeholder="कार्यालयको अंग्रेजी नाम" value="{{old('officeEnglishName')}}">
                            </div>
                        </div>
                        
                        <div class="col-sm-6">
                            <div class="form-group m-b-20">
                                <label for="emailaddress">कार्यालयको ठेगाना</label><sup class="text-danger">*</sup>
                                <input class="form-control" type="text" id="officeAddress" name="officeAddress" required="" placeholder="कार्यालयको ठेगाना" value="{{old('officeAddress')}}">
                            </div>
                        </div>

                        <div class="col-sm-6">
                        <div class="form-group m-b-20">
                                <label for="email">इमेल </label><sup class="text-danger">*</sup>
                                <input class="form-control" type="email" id="email"  name="email" required="" placeholder="कार्यालयको इमेल" value="{{old('email')}}">
                            </div>
                        </div>
                        <div class="col-sm-6">
                        <div class="form-group m-b-20">
                                <label for="landLineNumber"> सम्पर्क नं </label><sup class="text-danger">*</sup>
                                <input class="form-control" type="text" id="landLineNumber" maxlength="10" name="landLineNumber" required="" placeholder="कार्यालयको सम्पर्क नं" value="{{old('landLineNumber')}}">
                            </div>
                        </div> 
                        
                        <div class="col-sm-6">
                            <div class="form-group m-b-20">
                          
                               <label for="officeLogo">कार्यालयको लोगो</label><sup class="text-danger">*</sup>
                               <input type="file" class="filestyle select_image_popup" data-buttonname="btn-primary" id="officeLogo" name="officeLogo" value="{{old('officeLogo')}}" required>
                           </div>
                       </div> 
                    </div>
                  
                        <div class="column-full">
                            <div class="form-group m-b-20">
                            
                                <label for="officeSlogan">कार्यालयको नारा</label><sup class="text-danger">*</sup>
                                <textarea class="form-control" type="text" id="officeSlogan" name="officeSlogan" required="" placeholder="कार्यालयको नारा" value="{{old('officeSlogan')}}"></textarea>
                            </div>
                        </div> 
                        
                   
                   
        
                    <div class="form-group account-btn text-center m-t-10">
                        <div class="column-full">
                            <button class="btn btn-lg btn-primary btn-block" type="submit">Submit</button>
                        </div>
                    </div>
        
                </form>
               </div>
            </div>
        </div>
        
    </div>
@endsection

@section('modal_content')
@endsection

@section('javascript_content')
<script>
//  CKEDITOR.replace('officeSlogan');

</script>
@endsection
