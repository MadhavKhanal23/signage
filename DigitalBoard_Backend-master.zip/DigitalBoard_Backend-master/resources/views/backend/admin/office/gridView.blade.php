@extends('layouts.app')

@section('dashboard_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('breadcum_title')
<li class="breadcrumb-item active"> <a href="{{route('office.index')}}">कार्यालय</a></li>
<li class="breadcrumb-item active"> <a href="{{route('office.gridView')}}">ग्रिड दृश्य</a></li>
@endsection

@section('create_button')
<a href="{{ route('office.gridView') }}" data-toggle="modal"  data-placement="top" title="ग्रिड दृश्य"><i class="fa fa-th" aria-hidden="true"></i></a>&nbsp; &nbsp; &nbsp;
<a href="{{ route('office.index') }}" data-toggle="modal" data-placement="top" title="सुची दृश्य"><i class="fa fa-th-list" aria-hidden="true"></i></a>&nbsp; &nbsp;&nbsp;
<a href="{{ route('office.create') }}" data-toggle="modal" data-placement="top" title="नँया कार्यालय"><i class="fa fa-plus" aria-hidden="true"></i></a>
@endsection

@section('box_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('content')
<style>
    .textsize{
        margin-left:20px;
        flex: 0 0 40%;
        
    }
</style>

<div class="row">
    <div class="col-md-12">
        <hr>
        <center><h5>कार्यालय</h5></center>
        <hr>
    </div>
    @foreach($office_data as $office)
        <div class="col-md-4 m-t-10">
            <div class="card-box grid-card" style="width:100%;">
                <div class="text-center">
                    @if ($office['logo']!=null)
                        <img src="{{ URL::asset('storage/uploads/office_logo/'.$office['logo']) }}" class="thumb-md rounded-circle" alt="office-img" height="100" width="100">
                    @else
                        <img src="{{ asset('/simple_admin/images/nissan_chhap.png')}}" class="thumb-md rounded-circle" alt="office-img" height="100" width="100">
                    @endif
                    <h6 class="mt-2"> {{$office['english_name']}}</h6>
                    <h6 class="mt-2"> {{$office['nepali_name']}}</h6>
                    <h6 class="">{{$office->address}}</h6>
                </div>
                <div class="row mt-2 text-white" style="background-color:#23B195">
                    <div class="col-md-6 py-1 flex"><strong>Phone-no:</strong></div>
                    <div class="col-md-6 py-1 flex text-right"><strong>{{$office["landline_number"]}}</strong></div>
                    <div class="col-7 py-1 flex"><strong>Email</strong></div>
                    <div class="col-5 py-1 flex text-right"><strong>{{$office["email"]}}</strong></div>
                </div>   
                <p class="m-b-5 mt-2 text-center"><b>{{$office->slogan}}</b></p>
            </div>
        </div>
    @endforeach 
</div>
@endsection