@foreach($users as $user)
@if( $user['email'] != "superadmin@gmail.com" && $user['name'] != "SuperAdmin")
<tr id="{{$user->id}}">
    <td class="text-center" id="">@if(Auth::user()->user_type == "Admin") {{$loop->iteration}} @else {{$loop->iteration - 1}} @endif</td>
    <td class="text-center" id="user_name{{$user->id}}">{{$user->name}}</td>
    <td class="text-center" style="font-size: 1rem">
        @if($user['user_type'] == "Admin")
         {{$user->officeUser->officeData['nepali_name'] ?? "N/A"}}
        @elseif($user['user_type'] == "User")
        {{$user->officeUser->officeData['nepali_name'] ?? "N/A"}} [{{$user->departmentUser->departmentData['department_name'] ?? "N/A"}}]
        @endif
    </td>
    <td class="text-center"id="user_email{{$user->id}}">{{$user->email}}</td>
    <td class="text-center" id="user_mobile{{$user->id}}">{{$user->mobile_number}}</td>
    <td class="text-center" id="user_address{{$user->id}}">{{$user->address}}</td>
    <td class="text-center">
        <div class="switchery-demo">
            <input type="checkbox" id="user_delete{{$user['id']}}" class="user_delete" data-id="{{$user['id']}}" checked data-plugin="switchery" data-status="1" data-color="#007bff" data-size="small"/>
            
        </div>
    </td>
</tr>
@endif
@endforeach