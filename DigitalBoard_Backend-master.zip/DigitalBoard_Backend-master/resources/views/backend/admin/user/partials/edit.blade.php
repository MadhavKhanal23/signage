<x-guest-layout>
    <section>
        <div>
            <div class="row">
                <div class="col-lg-12">

                    <div>

                        <div class="m-t-40 card-box">
                            <div class="text-center">
                                <h2 class="text-uppercase m-t-0 m-b-30">
                                    <a href="index.html" class="text-dark">
                                        <span><img src="{{asset('simple_admin/images/nissan_chhap.png')}}" alt="" height="50"> नेपाल सरकार </span>
                                    </a>
                                </h2>
                                <!--<h4 class="text-uppercase font-bold m-b-0">Sign In</h4>-->
                            </div>
                            <div class="account-content">
                                <!-- Validation Errors -->
                                <x-auth-validation-errors class="mb-4" :errors="$errors" />
                                <form method="POST" action="{{route('user.update')}}" enctype="multipart/form-data" id="userFormEdit">
                                    @csrf
                                    <input type="hidden" id="user_id" name="user_id" value="{{$user['id']}}">
                                    <div class="form-group m-b-20">
                                        <div class="col-12">
                                            <label for="username">प्रयोगकर्ताको नाम</label>
                                            <input class="form-control" type="text" id="username" required=""   name="name" value="{{$user['name']}}">
                                        </div>
                                    </div>

                                    <div class="form-group m-b-20">
                                        <div class="col-12">
                                            <label for="emailaddress">इमेल</label>
                                            <input class="form-control" type="email" id="emailaddress" name="email" required="" value="{{$user['email']}}">
                                        </div>
                                    </div>

                                    <div class="form-group m-b-20">
                                        <div class="col-12">
                                            <label for="mobileNumber">मोबाइल नं</label>
                                            <input class="form-control" type="text" id="mobileNumber" name="mobile_number"maxlength="10" required="" value="{{$user['mobile_number']}}">
                                        </div>
                                    </div>

                                    <div class="form-group m-b-20">
                                        <div class="col-12">
                                            <label for="userAddress">ठेगाना</label>
                                            <input class="form-control" type="text" id="userAddress" name="user_address" required="" value="{{$user['address']}}">
                                        </div>
                                    </div>

                                    <div class="form-group m-b-20 row">
                                        <div class="col-6">
                                            <label for="userTypeEdit">प्रयोगकर्ताको प्रकार</label>
                                            <select class="form-control " name="user_type" id="userTypeEdit">
                                                @if(Auth:: user()->user_type == "Superadmin")
                                                    <option selected value={{$user->user_type}}>{{$user->user_type}}</option>
                                                    <option value="Admin">Admin</option>
                                                    <option value="User">User</option>
                                                @else
                                                    <option selected value={{$user->user_type}}>{{$user->user_type}}</option>
                                                    <option value="User" selected>User</option>
                                                @endif
                                            </select>
                                        </div>

                                        <div class="col-6">
                                            <input type="checkbox" name="changePasword" id="changePasword">
                                            <label for="changePasword">पास्वोर्ड परिवर्तन</label>
                                            <div class="newPassword" style="display: none" >
                                                <div class="input-group">
                                                    <input type='password' class="form-control" name="newPassword" id="newPassword" placeholder="नयाँ पास्वोर्ड ">
                                                    <div class="input-group-append">
                                                        <span class="input-group-text showPassword"><i class="mdi mdi-eye" style="color:#36B195;"></i></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div> 

                                    <div class="form-group m-b-20">
                                        
                                    </div> 



                                    <div class="form-group m-b-20 edituserOffice">
                                        <div class="col-12">
                                            <label for="userAddress">प्रयोगकर्ताको कार्यालय</label>
                                            <select class="form-control" name="userOffice" id="userOffice">
                                                <option selected value="{{$user->officeUser['office_id']}}">{{$user->officeUser->officeData['nepali_name']}}</option>
                                                @foreach($offices as $office)
                                                    <option value="{{$office['id']}}">{{$office['nepali_name']}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div class = "edit_office_department_information" @if($user->user_type == "Admin")style="display:none" @endif>
                                        <div class="form-group m-b-20 edituserDepartment">
                                            <div class="col-12">
                                                <label for="userDepartment">प्रयोगकर्ताको सचिवालय/ महाशाखा / शाखा</label>
                                                <select class="form-control" name="userDepartment" id="userDepartment">
                                                    <option selected value="{{$user->departmentUser['department_id'] ?? null}}">{{$user->departmentUser->departmentData['department_name'] ?? null}}</option>
                                                    @foreach($departments as $department)
                                                    {{-- <option value="{{$department['id']}}">{{$department['department_name'] ?? null}}</option> --}}
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    

                                    <div class="form-group account-btn text-center m-t-10">
                                        <div class="col-12">
                                            <button class="btn btn-lg btn-primary btn-block" type="submit">Update</button>
                                        </div>
                                    </div>

                                </form>

                                <div class="clearfix"></div>

                            </div>
                        </div>

                    </div>
                    <!-- end wrapper -->

                </div>
            </div>
        </div>
        <script type="text/javascript">
            $('#userFormEdit').on('change', '#changePasword', function(e)
            {
                e.preventDefault();
                if ($(this).is(':checked')) {
                    $('#userFormEdit .newPassword').show();
                }else{
                    $('#userFormEdit .newPassword').hide();
                    $('#newPassword').val('');
                }   
            });

            $('#userFormEdit .newPassword').on('click', '.showPassword', function(e){
                e.preventDefault();
                var type =  $('#userFormEdit #newPassword').attr('type')
                if(type == "password")
                {
                    $('#userFormEdit #newPassword').attr('type', 'text');
                }
                else
                {
                    $('#userFormEdit #newPassword').attr('type', 'password');
                }
            });

            $('#userFormEdit').on('change', '#userTypeEdit', function(e)
            {
                e.preventDefault();
                var userType = $(this).children("option:selected").val();
                if(userType == "Admin")
                {
                    $('.edit_office_department_information').hide();
                    $('#userDepartment').val('');
                }
                else if(userType == "User")
                {
                    $('.edit_office_department_information').show();
                }
            });

            $('#userFormEdit,select').on('change' ,'#userOffice',function(e){
                var office_id = $(this).val();
                
                $.ajax({
                     type:'GET',
                     url:"{{route('user.department')}}",
                     data:{
                         'office_id' : office_id
                     },
                     success:function(data){
                        //  console.log(data);
                        $('#userDepartment').find('option').not(':first').remove();
                         for (i = 0; i < data.length; i++)
                         {
                         $('#userDepartment').append( '<option value="'+data[i].id+'">'+data[i].department_name+'</option>' );
                         }
                           
                     },
                     error:function(){
                         
                     }
                 })
            });
        </script>
    </section>
</x-guest-layout>