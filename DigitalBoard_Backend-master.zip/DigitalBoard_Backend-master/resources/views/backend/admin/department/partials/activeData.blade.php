@foreach($departments as $department)
    @if(Auth::user()->user_type == "Admin" || Auth::user()->user_type == "Superadmin")
        <tr id="{{$department['id']}}" data-url="{{route('department.edit',$department['id'])}}">
            <td class="text-center" >{{$loop->iteration}}</td>
            <td class="text-center" style="font-size: 1rem" id="department_office{{$department['id']}}">{{$department->office['nepali_name'] ?? "N/A"}}</td>
            <td class="text-center" id="department_name{{$department['id']}}">{{$department->department_name}}</td>
            <td class="text-center" id="department_email{{$department['id']}}">{{$department->email}}</td>
            <td class="text-center" id="department_landline{{$department['id']}}">{{$department->landline_number}}</td>
            <td class="text-center" id="department_floor{{$department['id']}}">{{$department->floor_no}}</td>
            <td class="text-center" id="department_room{{$department['id']}}">{{$department->room_no}}</td>
            <td class="text-center">
                <div class="switchery-demo">
                    <input type="checkbox" class="department_delete" data-url="{{route('department.destroy', $department['id'])}}" id="department_delete{{$department['id']}}" checked data-plugin="switchery" data-id="{{$department['id']}}" data-status="1" data-color="#007bff" data-size="small"/>
                </div>
            </td>
        </tr>
    @elseif(Auth::user()->user_type == "User" && Auth::user()->officeUser['office_id'] == $department['office_id'])
        <tr id="{{$department['id']}}" data-url="{{route('department.edit',$department['id'])}}">
            <td class="text-center" >{{$loop->iteration}}</td>
            <td class="text-center" style="font-size: 1rem" id="department_office{{$department['id']}}">{{$department->office['nepali_name'] ?? "N/A"}}</td>
            <td class="text-center" id="department_name{{$department['id']}}">{{$department->department_name}}</td>
            <td class="text-center" id="department_email{{$department['id']}}">{{$department->email}}</td>
            <td class="text-center" id="department_landline{{$department['id']}}">{{$department->landline_number}}</td>
            <td class="text-center" id="department_floor{{$department['id']}}">{{$department->floor_no}}</td>
            <td class="text-center" id="department_room{{$department['id']}}">{{$department->room_no}}</td>
            <td class="text-center">
                <div class="switchery-demo">
                    <input type="checkbox" class="department_delete" data-url="{{route('department.destroy', $department['id'])}}" id="department_delete{{$department['id']}}" checked data-plugin="switchery" data-id="{{$department['id']}}" data-status="1" data-color="#007bff" data-size="small"/>
                </div>
            </td>
        </tr>
    @endif
@endforeach