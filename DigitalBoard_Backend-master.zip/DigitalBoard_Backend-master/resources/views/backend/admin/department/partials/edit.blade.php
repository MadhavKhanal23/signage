<div class="m-t-40 card-box">
    <div class="text-center">
        <h2 class="text-uppercase m-t-0 m-b-30">
            <a href="index.html" class="text-dark">
                <span><img src="{{asset('simple_admin/images/nissan_chhap.png')}}" alt="" height="50"> नेपाल सरकार </span>
            </a>
        </h2>
    </div>
    <div>
        @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif
    </div>
    <form method="POST" action="{{ route('department.update', $department['id']) }}" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <div class="form-group m-b-20">
            <div class="column-full">
                <label>कार्यालयको नाम </label><sup class="text-danger">*</sup>
                <div class="input-group">
                    <select class="form-control" id="department_office" name="department_office">
                            @if(Auth::user()->user_type == "User" || Auth::user()->user_type == "Admin")
                            <option selected value="{{$department['office_id']}}">{{$department->office['nepali_name']}}</option>
                            @elseif(Auth::user()->user_type == "Superadmin")
                            <option selected value="{{$department['office_id']}}">{{$department->office['nepali_name']}}</option>
                                @foreach ($offices as $office)
                                    <option value={{$office['id']}}>{{$office['nepali_name']}}</option>
                                @endforeach
                            @endif
                    </select>
                </div>
            </div>
        </div>
        <div class="form-group m-b-20">
            <div class="column-full">
                <label for="department_name">सचिवालय/ महाशाखा / शाखा</label><sup class="text-danger">*</sup>
                <input class="form-control" type="text" id="department_name" required=""   name="department_name" placeholder="Department Name" value="{{$department['department_name']}}">
            </div>
        </div>

        <div class="form-group m-b-20">
            <div class="column-full">
                <label for="department_name">कार्यालय संरचनाको प्रकार</label><sup class="text-danger">*</sup>
                <select class="form-control" id="edit_department_type" name="department_type">
                    <option selected value="{{$department['type']}}">{{$department['type']}}</option>
                    <option value="सचिवालय">सचिवालय</option>
                    <option value="महाशाखा">महाशाखा</option>
                    <option value="शाखा">शाखा</option>
                </select>
            </div>
        </div>

        <div class="form-group m-b-20 sakhaMahaasakha" @if($department['type'] != "शाखा") style="display: none" @endif>
            <div class="column-full">
                <label for="department_name">शाखाको महाशाखा</label><sup class="text-danger">*</sup>
                <select class="form-control" id="mahaaSakha_name" name="mahaaSakha_id">
                    <option selected value="{{$department->mahaaSakha['id'] ?? ""}}">{{$department->mahaaSakha->mahaaSakha_name['department_name'] ?? ""}}</option>
                    @foreach($mahaSakha as $dept)
                        <option value="{{$dept['id']}}">{{$dept['department_name']}}</option>
                    @endforeach
                </select>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-6">
            <div class="form-group m-b-20">
                    <label for="email">इमेल</label><sup class="text-danger">*</sup>
                    <input class="form-control" type="email" id="email"  name="email" required="" placeholder="Department Email address" value="{{$department['email']}}">
                </div>
            </div>
            <div class="col-sm-6">
            <div class="form-group m-b-20">
                    <label for="landLineNumber">सम्पर्क नं </label><sup class="text-danger">*</sup>
                    <input class="form-control" type="text" id="landlineNumber" maxlength="10" name="landline_number" required="" placeholder="Department Landline number" value="{{$department['landline_number']}}">
                </div>
            </div>  
        </div>

        <div class="row"> 
             <div class="col-6">
                 <div class="form-group m-b-20">
                    <label for="department_floor">तल्ला नं </label><sup class="text-danger">*</sup>
                    <input class="form-control" type="text" id="department_floor" name="department_floor" value="{{$department['floor_no']}}" placeholder="1" required>
                </div>
            </div>
            <div class="col-6">
                <div class="form-group m-b-20">
                    <label for="department_room">कोठा नं </label><sup class="text-danger">*</sup>
                    <input class="form-control" id="department_room" name="department_room" value="{{$department['room_no']}}" data-role="tagsinput" required>
                </div>
            </div>
        </div>

        <div class="form-group m-b-20">
            <div class="column-full">
                <label for="department_services">कार्यालय शाखाको सेवा</label><sup class="text-danger">*</sup>
                <textarea class="form-control" id="department_services" name="department_services" value="{{$department['department_services']}}" required>{{$department['department_services']}}</textarea>
            </div>
        </div>

    
        <div class="form-group account-btn text-center m-t-10">
            <div class="column-full">
                <button class="btn btn-lg btn-primary btn-block" type="submit">Submit</button>
            </div>
        </div>

    </form>
</div>

<script type="text/javascript">
    $('body').on('change', '#edit_department_type', function(e){
        e.preventDefault();
        var type = $(this).val();

        if(type == "शाखा")
        {
            $('body .sakhaMahaasakha').show();
        }
        else{
            $('body .sakhaMahaasakha').hide();
            $('body .sakhaMahaasakha #mahaaSakha_name').val('');
        }
    });
</script>