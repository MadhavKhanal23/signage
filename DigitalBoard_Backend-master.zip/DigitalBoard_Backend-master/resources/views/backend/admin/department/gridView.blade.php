@extends('layouts.app')

@section('dashboard_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('breadcum_title')
<li class="breadcrumb-item active"> <a href="{{route('department.index')}}">Department</a></li>
<li class="breadcrumb-item active"> <a href="{{route('department.gridView')}}">Grid View</a></li>
@endsection

@section('create_button')
<a href="{{ route('department.gridView') }}" data-toggle="modal"  data-placement="top" title="Grid View"><i class="fa fa-th" aria-hidden="true"></i></a>&nbsp; &nbsp; &nbsp;
<a href="{{ route('department.index') }}" data-toggle="modal" data-placement="top" title="List View"><i class="fa fa-th-list" aria-hidden="true"></i></a>&nbsp; &nbsp;&nbsp;
<a href="{{ route('department.create') }}" data-toggle="modal" data-placement="top" title="Add Office"><i class="fa fa-plus" aria-hidden="true"></i></a>
@endsection

@section('box_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('content')
<style>
    .textsize{
        margin-left:20px;
        flex:0 0 40%;
        
    }
   
    </style>

<div class="row">
    <div class="block-header block-header-default col-md-12" style="margin-top: 0px !important">
        <div class="section-body mt-3" >
            <div class="container-fluid" >
                <div class="tab-content" >
                    <div class="tab-pane fade show active " id="Project-OnGoing" role="tabpanel" >
                        <div class="row" >
                            @foreach($department_data as $department)
                                <div class="col-lg-4 col-md-12">
                                    <div class="cards" style="background-color:#e9ecef">
                                        <div class="cards-header" style="background:lightgrey;height:70px;">
                                            <h5 class="cards-title text-primary textsize" style="text-align:center;padding-top:20px">{{$department["department_name"]}}</h5>     
                                            {{-- <div class="cards-options float-right ml-5 mt-2" >
                                               
                                            </div> --}}
                                        </div>

                                        <div class="cards-body clearfix">
                                            <div class="row mt-4 mb-4 " style="margin-left: -15px !important; margin-right: -15px !important">
                                                <div class="col-5 py-1 text-primary textsize flex"><strong>Office Name:</strong></div>
                                                <div class="col-7 py-1 text-primary textsize flex">{{$department->office['english_name']}}/ {{$department->office['nepali_name']}}</div>

                                                <div class="col-5 py-1 text-primary textsize  flex"><strong>Floor no:</strong></div>
                                                <div class="col-7 py-1 text-primary textsize flex">{{$department->floor_no}}</div>
                                                
                                                <div class="col-5 py-1 text-primary textsize  flex"><strong>Room no:</strong></div>
                                                <div class="col-7 py-1 text-primary textsize flex">{{$department->room_no}}</div>
                                                <div class="col-5 py-1 text-primary textsize flex"><strong> Services:</strong></div>
                                                <div class="col-7 py-1 text-primary textsize flex">{!!$department->department_services!!}</div>

                                                
                                                {{-- here make team member avater dynamic --}}
                                                
                                            </div>
                                        </div>

                                        <div class="card-footer" style="background:lightgrey">
                                            {{-- <div class="clearfix">
                                                <div class="float-left text-primary"><strong>15%</strong></div>
                                                <div class="float-right text-primary"><small class="text-muted">Progress</small></div>
                                            </div>
                                            <div class="progress progress-xs">
                                                <div class="progress-bar bg-primary" role="progressbar" style="width: 15%" aria-valuenow="36" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div> --}}
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection