@extends('layouts.app')

@section('dashboard_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('breadcum_title')
<li class="breadcrumb-item active"> <a href="{{route('department.index')}}">कार्यालय संरचना</a></li>
@endsection

@section('create_button')
<a href="{{ route('department.create') }}" data-toggle="modal" data-placement="top" title="नँया कार्यालय संरचना"><i class="fa fa-plus" aria-hidden="true"></i></a>
@endsection

@section('box_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('content')
    @include('backend.admin.department.partials.indexContent')
@endsection

@section('modal_content')
@endsection

@section('javascript_content')
<script>
    $('.department_table #department_tbody').on('dblclick', 'tr', function(e){
        e.preventDefault();
        var department_id = $(this).attr('id');
        Swal.fire({
                    title: 'पुनश्च !!!!',
                    text: "के तपाई परिवर्तन गर्न चाहनु हुन्छ ?",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'परिवर्तन',
                    cancelButtonText: 'रद्द'
                }).then((result) => {
                    if (result.value)
                    {
                        var url = $(this).data("url");
                        $.ajax({
                            url:url, 
                            type:"get",
                            success:function(data){
                                const Toast = Swal.mixin({
                                    toast: true,
                                    position: 'top-end',
                                    showConfirmButton: false,
                                    timer: 3000,
                                });

                                Toast.fire({
                                    type:'success',
                                    title:'परिवर्तनको डाटा भर्नुहोस् ।।।'
                                });
                                $("#page_main_content").empty();
                                $("#page_main_content").html(data.html); 
                                CKEDITOR.replace('department_services'); 
                                $('#department_room').tagsinput();
                            },
                            error:function(data){
                                Swal.fire({
                                    title: 'Error',
                                    text: "Failed to Edit!",
                                    type: 'error'
                                });
                            },
                        });
                    }
                    else
                    {
                        e.dismiss;
                    }
                });
    });

    $('body .department_table').on('change', '.department_delete', function(e){
        e.preventDefault();
        var department_id = $(this).data("id");
        var current = $('#department_delete'+department_id).data('status');
        if(current===1){
            Swal.fire({
                title: 'पुनश्च !!!!',
                text: "के तपाई कार्यालय संरचनाको डाटा हटाउन चाहनु हुन्छ ?",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'हटाउनु होस्',
                cancelButtonText: 'रद्द'
            }).then((result) => {
                if (result.value == true){
                    var _token = $("input[name=_token]").val();
                    var url = $(this).data("url");
                    $.ajax({
                        url:url, 
                        type:"DELETE",
                        data:{
                            '_token': _token
                        },
                        success:function(data){
                            const Toast = Swal.mixin({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                            });

                            Toast.fire({
                                type:'success',
                                title:'कार्यालय संरचनाको डाटा सफलता पुर्बक हटाएयो ।।।'
                            });
                            $('#department_tbody').empty();
                            $('#department_tbody').html(data.html);
                            $('.switchery-demo input').each(function(){
                                new Switchery($(this)[0],{
                                    size:"small",
                                    color: '#007bff'
                                });
                            });
                        },
                        error:function(data){
                            Swal.fire({
                                title: 'Error',
                                text: "Failed to Delete!",
                                type: 'error'
                            });
                        },
                    });
                } 
                else {
                    e.dismiss;
                    $('#department_delete'+department_id).data('status',0); 
                    $('#department_delete'+department_id).trigger('click');
                }
            });
        }
        $('#department_delete'+department_id).data('status',1); 
    })
</script>
@endsection
