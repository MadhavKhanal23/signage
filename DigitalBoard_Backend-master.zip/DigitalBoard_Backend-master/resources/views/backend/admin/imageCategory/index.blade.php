@extends('layouts.app')

@section('dashboard_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('breadcum_title')
<li class="breadcrumb-item active"> <a href="{{route('image_category.index')}}">फोटो वर्ग</a></li>
@endsection

@section('create_button')
<a href="{{ route('image_category.create') }}" data-toggle="modal" data-placement="top" title="नँया फोटो वर्ग"><i class="fa fa-plus" aria-hidden="true"></i></a>
@endsection

@section('box_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('content')
<div class="row p-t-40">
    <div class="col-12">
        <hr>
        <center><h5>फोटो वर्ग</h5></center>
        <div class="alert alert-success alert-dismissible fade show text-center" role="alert" id="success_msg_div">
            <strong>नमस्कार {{Auth::user()->name}}!</strong> <span id="success_msg"> पङ्क्तिमा डबल किलिक गरि डाटा परिवर्तन गर्नुहोस। </span>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <hr>
        <div class="table-responsive">
            <table id="datatable" class="table table-bordered imageCategory_table">
                <thead>
                <tr>
                    <th class="text-center">क्र.सं</th>
                    <th class="text-center">फोटो वर्गको नाम</th>
                    <th class="text-center">उपलब्ध </th>
                </tr>
                </thead>

                <tbody id="imageCategory_tbody">
                    @include('backend.admin.imageCategory.partials.activeData')
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection

@section('modal_content')
@endsection

@section('javascript_content')
<script>
    $('.imageCategory_table #imageCategory_tbody').on('dblclick', 'tr', function(e){
        e.preventDefault();
        var imageCategory_id = $(this).attr('id');
        Swal.fire({
                    title: 'पुनश्च !!!!',
                    text: "के तपाई परिवर्तन गर्न चाहनु हुन्छ ?",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'परिवर्तन',
                    cancelButtonText: 'रद्द'
                }).then((result) => {
                    if (result.value)
                    {
                        var url = $(this).data("url");
                        $.ajax({
                            url:url, 
                            type:"get",
                            success:function(data){
                                const Toast = Swal.mixin({
                                    toast: true,
                                    position: 'top-end',
                                    showConfirmButton: false,
                                    timer: 3000,
                                });

                                Toast.fire({
                                    type:'success',
                                    title:'परिवर्तनको डाटा भर्नुहोस् ।।।'
                                });
                                $("#page_main_content").empty();
                                $("#page_main_content").html(data.html); 
                            },
                            error:function(data){
                                Swal.fire({
                                    title: 'Error',
                                    text: "Failed to Edit!",
                                    type: 'error'
                                });
                            },
                        });
                    }
                    else
                    {
                        e.dismiss;
                    }
        });
    });

    $('body .imageCategory_table').on('change', '.imageCategory_delete', function(e){
        e.preventDefault();
        var imageCategory_id = $(this).data("id");
        var current = $('#image_category_delete'+imageCategory_id).data('status');
        if(current===1){
            Swal.fire({
                title: 'पुनश्च !!!!',
                text: "के तपाई फोटो वर्गको डाटा हटाउन चाहनु हुन्छ ?",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'हटाउनु होस्',
                cancelButtonText: 'रद्द'
            }).then((result) => {
                if (result.value == true){
                    var _token = $("input[name=_token]").val();
                    var url = $(this).data("url");
                    $.ajax({
                        url:url, 
                        type:"DELETE",
                        data:{
                            '_token': _token
                        },
                        success:function(data){
                            const Toast = Swal.mixin({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                            });

                            Toast.fire({
                                type:'success',
                                title:'फोटो वर्गको डाटा सफलता पुर्बक हटाएयो ।।।'
                            });
                            $('#imageCategory_tbody').empty();
                            $('#imageCategory_tbody').html(data.html);
                            $('.switchery-demo input').each(function(){
                                new Switchery($(this)[0],{
                                    size:"small",
                                    color: '#007bff'
                                });
                            });
                        },
                        error:function(data){
                            Swal.fire({
                                title: 'Error',
                                text: "Failed to Delete!",
                                type: 'error'
                            });
                        },
                    });
                } 
                else {
                    e.dismiss;
                    $('#image_category_delete'+imageCategory_id).data('status',0); 
                    $('#image_category_delete'+imageCategory_id).trigger('click');
                }
            });
        }
        $('#image_category_delete'+imageCategory_id).data('status',1);
    })
</script>
@endsection
