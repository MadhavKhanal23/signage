@extends('layouts.app')

@section('dashboard_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('breadcum_title')
<li class="breadcrumb-item active"> <a href="{{route('image_category.index')}}">फोटो वर्ग</a></li>
<li class="breadcrumb-item active"> <a href="{{route('image_category.create')}}">नँया</a></li>
@endsection

@section('create_button')
<a href="{{ route('image_category.create') }}" data-toggle="modal" data-placement="top" title="नँया फोटो वर्ग"><i class="fa fa-plus" aria-hidden="true"></i></a>
@endsection

@section('box_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('content')
    <div class="m-t-40 card-box">
        <div class="text-center">
            <h2 class="text-uppercase m-t-0 m-b-30">
                <a href="#" class="text-dark">
                    <span><img src="{{asset('simple_admin/images/nissan_chhap.png')}}" alt="" height="50"> नेपाल सरकार </span>
                </a>
            </h2>
        </div>
        <div>
            @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
            @endif
        </div>
        <div class="container">
            <div class="row">
               <div class="col-md-12">
                <form method="POST" action="{{ route('image_category.store') }}" enctype="multipart/form-data">
                    @csrf
                    <div class="row">

                        <div class="col-12">
                            <div class="form-group m-b-20">
                                <label for="imageCategory_name">फोटो वर्गको नाम</label><sup class="text-danger">*</sup>
                                <input class="form-control" type="text" id="imageCategory_name" required=""   name="imageCategory_name" placeholder="फोटो वर्गको नाम" value="{{old('imageCategory_name')}}">
                            </div>
                        </div>
                    </div>

                    <div class="form-group account-btn text-center m-t-10">
                        <div class="column-full">
                            <button class="btn btn-lg btn-primary btn-block" type="submit">Submit</button>
                        </div>
                    </div>
        
                </form>
               </div>
            </div>
        </div>
        
    </div>
@endsection

@section('modal_content')
@endsection

@section('javascript_content')
@endsection
