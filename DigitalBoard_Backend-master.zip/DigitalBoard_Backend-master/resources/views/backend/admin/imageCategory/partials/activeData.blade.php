@foreach($image_categories as $category)
    <tr id={{$category['id']}} data-url="{{route('image_category.edit', $category['id'])}}">
        <td class="text-center">{{$loop->iteration}}</td>
        <td class="text-center">{{$category->category}}</td>
        <td class="text-center">
            <div class="switchery-demo">
                <input type="checkbox" class="imageCategory_delete" data-url="{{route('image_category.destroy', $category['id'])}}" id="image_category_delete{{$category['id']}}" checked data-plugin="switchery" data-id="{{$category['id']}}" data-status="1" data-color="#007bff" data-size="small"/>
            </div>
        </td>
    </tr>
@endforeach