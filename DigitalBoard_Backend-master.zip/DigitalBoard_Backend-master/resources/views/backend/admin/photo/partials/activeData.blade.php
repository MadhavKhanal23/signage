@foreach($photos as $photo)
    @if(Auth::user()->user_type == "Admin" || Auth::user()->user_type == "Superadmin")
        <tr id="{{$photo->id}}" @if($photo->is_important == 1) style="color:#23B195" @endif data-url="{{route('photo.edit',$photo->id)}}">
            <td class="text-center">{{$loop->iteration}}</td>
            <td style="font-size: 1rem" class="text-center">{{$photo->office['nepali_name'] ?? "N/A"}}</td>
            <td class="text-center">{{$photo['photo_title']}}</td>
            <td class="text-center">
                <img style="height:2rem; width:2rem;" src="{{asset('storage/uploads/photo_image/'.$photo['photo_image'])}}" alt="" class="thumb-md rounded-circle">
            </td>
            <td class="text-center">{{$photo['display_from'] ?? "-"}}</td>
            <td class="text-center">{{$photo['display_to'] ?? "-"}}</td>
            <td class="text-center">
                @if($photo['publish'] == 1)
                    <div class="switchery-demo">
                        <input type="checkbox" id="photo_publish{{$photo['id']}}" data-publish = 0 class="photo_publish" data-id="{{$photo['id']}}" checked data-status="1" data-plugin="switchery" data-color="#007bff" data-size="small"/>
                    </div>
                @else
                <div class="switchery-demo">
                    <input type="checkbox" id="photo_UnPublish{{$photo['id']}}"  data-publish = 1 class="photo_publish" data-id="{{$photo['id']}}" data-status="1" data-plugin="switchery" data-color="#007bff" data-size="small"/>
                </div>
                @endif
            </td>
            <td class="text-center">
                <div class="switchery-demo">
                    <input type="checkbox" id="photo_delete{{$photo['id']}}" data-url="{{route('photo.destroy',$photo['id'])}}" class="photo_delete" data-id="{{$photo['id']}}" checked data-status="1" data-plugin="switchery" data-color="#007bff" data-size="small"/>
                </div>
            </td>
        </tr>
    @elseif(Auth::user()->user_type == "User" && Auth::user()->officeUser['office_id'] == $photo['office_id'])
        <tr id="{{$photo->id}}" @if($photo->is_important == 1) style="color:#23b195" @endif data-url="{{route('photo.edit',$photo->id)}}">
            <td class="text-center">{{$loop->iteration}}</td>
            <td class="text-center" style="font-size: 1rem">{{$photo->office['nepali_name'] ?? "N/A"}}</td>
            <td class="text-center">{{$photo['photo_title']}}</td>
            <td class="text-center">
                <img style="height:2rem; width:2rem;" src="{{asset('storage/uploads/photo_image/'.$photo['photo_image'])}}" alt="" class="thumb-md rounded-circle">
            </td>
            <td class="text-center">{{$photo['display_from'] ?? "-"}}</td>
            <td class="text-center">{{$photo['display_to'] ?? "-"}}</td>
            <td class="text-center">
                @if($photo['publish'] == 1)
                    <div class="switchery-demo">
                        <input type="checkbox" id="photo_publish{{$photo['id']}}" data-publish = 0 class="photo_publish" data-id="{{$photo['id']}}" checked data-status="1" data-plugin="switchery" data-color="#007bff" data-size="small"/>
                    </div>
                @else
                <div class="switchery-demo">
                    <input type="checkbox" id="photo_UnPublish{{$photo['id']}}"  data-publish = 1 class="photo_publish" data-id="{{$photo['id']}}" data-status="1" data-plugin="switchery" data-color="#007bff" data-size="small"/>
                </div>
                @endif
            </td>
            <td class="text-center">
                <div class="switchery-demo">
                    <input type="checkbox" id="photo_delete{{$photo['id']}}" data-url="{{route('photo.destroy',$photo['id'])}}" class="photo_delete" data-id="{{$photo['id']}}" checked data-status="1" data-plugin="switchery" data-color="#007bff" data-size="small"/>
                </div>
            </td>
        </tr>
    @endif
@endforeach