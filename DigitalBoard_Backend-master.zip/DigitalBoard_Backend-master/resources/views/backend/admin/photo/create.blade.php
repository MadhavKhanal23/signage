@extends('layouts.app')

@section('dashboard_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('breadcum_title')
<li class="breadcrumb-item active"> <a href="{{route('photo.index')}}">फोटो</a></li>
<li class="breadcrumb-item active"> <a href="{{route('photo.create')}}">नँया</a></li>

@endsection

@section('create_button')
<a href="{{ route('photo.create') }}" data-toggle="modal" data-placement="top" title="नँया फोटो"><i class="fa fa-plus" aria-hidden="true"></i></a>
@endsection

@section('box_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('content')
<div class="m-t-40 card-box">
    <div class="text-center">
        <h2 class="text-uppercase m-t-0 m-b-30">
            <a href="index.html" class="text-dark">
                <span><img src="{{asset('simple_admin/images/nissan_chhap.png')}}" alt="" height="50"> नेपाल सरकार </span>
            </a>
        </h2>
    </div>
    <div>
        @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif
    </div>
    <form method="POST" action="{{ route('photo.store') }}" enctype="multipart/form-data">
        @csrf
       
        
        <div class="row">
            <div class="col-12">
                <div class="form-group m-b-20">
                    <label> कार्यालय </label><sup class="text-danger">*</sup>
                    <div class="input-group">
                        <select class="form-control" id="photo_office" name="photo_office">
                            @if(Auth::user()->user_type == "User")
                                <option selected value="{{Auth::user()->officeUser->office_id}}"> {{Auth::user()->officeUser->officeData->nepali_name}} </option>
                            @elseif(Auth::user()->user_type == "Admin" || Auth::user()->user_type == "Superadmin")
                                <option selected disabled>कार्यालय छनौट गर्नुहोस्</option>
                                @foreach ($office_data as $office)
                                    <option value={{$office['id']}}>{{$office['nepali_name']}}</option>
                                @endforeach
                            @endif
                        </select>
                    </div>
                </div>
            </div>

            <div class="col-6">
                    <div class="form-group m-b-20">
                    <label for="photo_title">फोटोको शीर्षक</label><sup class="text-danger">*</sup>
                    <input class="form-control" type="text" id="photo_title" name="photo_title" placeholder="फोटोको शीर्षक" value="{{old('photo_title')}}">
                </div>
            </div>
            
            <div class="col-6">
                <div class="form-group m-b-20">
                    <label for="photo_image">फोटो</label>
                    <input type="file" class="filestyle select_image_popup" data-buttonname="btn-primary" id="photo_image" name="photo_image" value="{{old('photo_image')}}" required>
                </div>
            </div> 

            <div class="col-12">
                <div class="form-group m-b-20">
                    <label for="photo_category"> फोटो वर्ग </label><sup class="text-danger">*</sup>
                    <div class="input-group">
                        <select class="form-control" id="photo_category" name="photo_category">
                            <option selected disabled>फोटो वर्ग छनौट गर्नुहोस्</option>
                            @foreach ($image_categories as $category)
                                <option value={{$category['id']}}>{{$category['category']}}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <div class="form-group m-b-20 important_photo">
            <div class="col-12">
                <label class="css-control css-control-info css-checkbox"
                style="display: inline !important; float: center;">
                <input type="hidden" name="is_important" value="0">
                <label class="css-control-info">
                    <input type="checkbox" class="css-control-info" value="1" name="is_important"
                        id="is_important">
                    <span class="css-control-indicator"></span>मिति र समय तोक्नुहोस
            </label>
            </div>
        </div>
        
        <div class="row dateTime" style="display: none">

            <div class="col-4">
                <div class="form-group m-b-20">
                    <label for="photo_display_from">फोटो प्रकाशन मिति</label>
                    <input class="form-control date" type="date" id="photo_display_from" name="photo_display_from" placeholder="Photo Display From" value="{{old('photo_display_from')}}">
                </div>
            </div>
        
            <div class="col-4">
                <div class="form-group m-b-20">
                    <label for="photo_display_to">फोटो प्रकाशन अन्तिम मिति</label>
                    <input class="form-control date" type="date" id="photo_display_to" name="photo_display_to" placeholder="Photo Display To" value="{{old('photo_display_to')}}">
                </div>
            </div>

            <div class="col-4">
                <div class="form-group m-b-20">
                    <label for="photo_display_time">फोटो प्रकाशन समय</label>
                    <input class="form-control date" type="text" id="photo_display_time"    name="photo_display_time" placeholder="hh:mm:ss" value="{{old('photo_display_time')}}">
                </div>
            </div>
        </div>
        <div class="form-group m-b-20">
            <div class="column-full">
                <label for="photo_description">फोटो विवरण</label><sup class="text-danger">*</sup>
                <textarea  class="form-control" type="text" id="photo_description"  name="photo_description" placeholder="फोटोको विवरण लेख्नुहोस्" value="{{old('photo_description')}}"></textarea>
            </div>
        </div>
        <div class="form-group account-btn text-center m-t-10">
            <div class="column-full">
                <button class="btn btn-lg btn-primary btn-block" type="submit">Submit</button>
            </div>
        </div>
    </form>
</div>
@endsection

@section('modal_content')
@endsection

@section('javascript_content')
<script type="text/javascript">
    $('.important_photo').on('change', '#is_important', function(e){
        e.preventDefault();
        if ($('.important_photo #is_important').is(':checked')) {
            $('.dateTime').show();
            $('#photo_display_from').prop('required',true)
            $('#photo_display_to').prop('required',true)
            $('#photo_display_time').prop('required',true)
        }
        else{
            $('.dateTime').hide();
            $('#photo_display_from').prop('required',false)
            $('#photo_display_to').prop('required',false)
            $('#photo_display_time').prop('required',false)
        }
    })
    
</script>
@endsection
