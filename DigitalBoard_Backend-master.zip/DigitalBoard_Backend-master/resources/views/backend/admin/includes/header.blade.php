<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>डिजिटल सूचना बोर्ड</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'डिजिटल सूचना बोर्ड') }}</title>

        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">



        <!-- Styles -->
        {{-- <link rel="stylesheet" href="{{ asset('css/app.css') }}"> --}}

        <!-- Scripts -->
        {{-- <script src="{{ asset('js/app.js') }}" defer></script> --}}

        <!-- App favicon -->
        <link rel="shortcut icon" href="{{asset('simple_admin/images/nissan_chhap.png')}}" />

        <link rel="stylesheet" href="{{asset('simple_admin/plugins/switchery/switchery.min.css')}}">

        <link rel="stylesheet" href="{{asset('simple_admin/plugins/sweetalert2/sweetalert2.min.css')}}">
        <!--Morris Chart CSS -->
        {{-- <link rel="stylesheet" href="{{asset('simple_admin/plugins/morris/morris.css')}}"> --}}

        <!-- DataTables -->
        <link
            href="{{asset('simple_admin/plugins/datatables/dataTables.bootstrap4.min.css')}}"
            rel="stylesheet"
            type="text/css"
        />

        {{-- <link rel="stylesheet" href="{{asset('simple_admin/css/breadcrumbs.css')}}"> --}}
       

        <link
            href="{{asset('simple_admin/plugins/datatables/buttons.bootstrap4.min.css')}}"
            rel="stylesheet"
            type="text/css"
        />
        <!-- Responsive datatable examples -->
        <link
            href="{{asset('simple_admin/plugins/datatables/responsive.bootstrap4.min.css')}}"
            rel="stylesheet"
            type="text/css"
        />

        <!-- Multi Item Selection examples -->
        <link
            href="{{asset('simple_admin/plugins/datatables/select.bootstrap4.min.css')}}"
            rel="stylesheet"
            type="text/css"
        />

        <!-- App css -->
        <link
        href="{{asset('simple_admin/css/bootstrap.min.css')}}"
        rel="stylesheet"
        type="text/css"
        />
        <link href="{{asset('simple_admin/css/icons.css')}}" rel="stylesheet" type="text/css" />
        <link
        href="{{asset('simple_admin/css/metismenu.min.css')}}"
        rel="stylesheet"
        type="text/css"
        />
        <link rel="stylesheet" href="{{asset('simple_admin/plugins/bootstrap-tagsinput/css/bootstrap-tagsinput.css')}}">
        <link href="{{asset('simple_admin/css/style.css')}}" rel="stylesheet" type="text/css" />

        {{-- nepalidatepicker --}}
        <link href="{{asset('simple_admin/plugins/bootstrap-nepaliDatePicker/nepali.datepicker.v3.5.min.css')}}" rel="stylesheet" type="text/css"
        />

        <script src="{{asset('simple_admin/js/modernizr.min.js')}}"></script>

    </head>