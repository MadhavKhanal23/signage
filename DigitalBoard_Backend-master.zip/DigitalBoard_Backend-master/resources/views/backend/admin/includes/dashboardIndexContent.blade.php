<div class="container text-center dashboard">
    <div class="row p-t-40 mt-4">
        <div class="col-sm-4">
          <a href="{{route('photo.index')}}">
            <div class="card-box"> 
              <i class="fa fa-picture-o fa-3x mr-1" style="color: #23B195"></i><br>
                <h6 class="text-muted font-15 mt-2 text-uppercase ">
                  फोटो संख्या
                </h6>
                <h3 class="mt-3" @if($photo_count == 0) Style="color:#C70611"@else Style="color:black" @endif><span>{{$photo_count}}</span></h3>
            </div>
          </a>
        </div>

        <div class="col-sm-4">
          <a href="{{route('scroll_notice.index')}}">
            <div class="card-box">
              <i class="fa fa-file-text fa-3x mr-2" style="color: #23B195"></i><br>
                <h6 class="text-muted font-15 mt-2 text-uppercase">
                  सूचना संख्या</h6>
                <h3 class="mt-3" @if($scroll_notice_count == 0) Style="color:#C70611"@else Style="color:black" @endif><span>{{$scroll_notice_count}}</span></h3>
            </div>
          </a>
        </div>

        <div class="col-sm-4">
          <a href="{{route('department.index')}}">
            <div class="card-box">
              <i class="fa fa-building fa-3x" style="color: #23B195"></i><br>
                <h6 class="text-muted font-15 mt-2 text-uppercase">
                  कार्यालय संख्या</h6>
                <h3 class="mt-3" @if($department_count == 0) Style="color:#C70611"@else Style="color:black" @endif><span>{{$department_count}}</span></h3>
            </div>
          </a>
        </div>
    </div>
    <hr>
    <div id="page_main_content">
        <ul class="nav navbar-light nav-pills mb-3" id="pills-tab" role="tablist"
          style="background-color: #f7f8fb;">
          <li class="nav-item">
            <a class="nav-link tab_link active" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab"
              aria-controls="pills-profile" aria-selected="false">सचिवालय/ महाशाखा / शाखा</a>
          </li>

          <li class="nav-item">
            <a class="nav-link tab_link" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab"
              aria-controls="pills-home" aria-selected="true">कर्मचारी</a>
          </li>
        </ul>
        <div class=" tab-content" id="pills-tabContent">
          <div class="tab-pane fade" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
            <div id="operate">
              <div class="row">
                <div class="col-sm-12">
                  <div class="card-box">
                      <a class="text-secondary" href="{{route("employee.index")}}">
                            <h6 class="m-t-0">कर्मचारी</h6>
                      </a>
                    <div class="table-responsive">
                      <table class="table table-hover mails m-0 table table-actions-bar">
                        <thead>
                            <tr>
                                <th class="text-left">नाम [पद]</th>
                                <th class="text-left">इमेल </th>
                                <th class="text-left">मोबाइल नं </th>
                                <th class="text-left">तल्ला/कोठा नं </th>
                            </tr>
                          </thead>
    
                        <tbody>
                            @foreach($employees as $employee)
                            <tr>
                                <td class="text-left">
                                    @if ($employee['image']!=null)
                                        <img src="{{URL::asset('storage/uploads/employee_image/'.$employee['image']) }}" class="thumb-md rounded-circle" alt="employee-img" height="40" width="40">
                                    @else
                                        <img src="{{ URL::asset('/simple_admin/images/nissan_chhap.png')}}" class="thumb-md rounded-circle" alt="employee-img" height="40" width="40">
                                    @endif
                                    &nbsp;&nbsp;{{$employee['employee_name']}}, [{{$employee->designation}}]
                                </td>
                                <td class="text-left">{{$employee['email']}}</td>
                                <td class="text-left">{{$employee['mobile_no']}}</td>
                                <td class="text-left">{{$employee->department['floor_no']}}/{{$employee['room_no']}}</td>
                            </tr>
                            @endforeach
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="tab-pane fade show active" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
            <div class="row">
              <div class="col-sm-12">
                <div class="card-box">
                    <a class="text-secondary" href="{{route('department.index')}}">
                        <h6 class="m-t-0">सचिवालय/ महाशाखा / शाखा</h6>
                    </a>
                  <div class="table-responsive">
                    <table class="table table-hover mails m-0 table table-actions-bar">
                        <thead>
                            <tr>
                              <th class="text-left">कार्यालयको नाम </th>
                              <th class="text-left">संरचनाको नाम </th>
                              <th class="text-left">सम्पर्क नं </th>
                              <th class="text-left">तल्ला/कोठा नं</th>
                            </tr>
                        </thead>
    
                      <tbody>     
                            @foreach($departments as $department)
                                <tr>
                                    <td class="text-left">{{$department->office->nepali_name ?? "NA"}}</td>
                                    <td class="text-left">{{$department->department_name}}</td>
                                    <td class="text-left">{{$department->landline_number}}</td>
                                    <td class="text-left">{{$department->floor_no}}/{{$department->room_no}}</td>
                                </tr>
                            @endforeach
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
</div>