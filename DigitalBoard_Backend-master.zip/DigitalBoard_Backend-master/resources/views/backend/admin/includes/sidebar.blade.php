

            <!-- Begin page -->

                <!-- Top Bar Start -->
                <div class="topbar">

                    <!-- LOGO -->
                    <div class="topbar-left">
                        <a href="{{route('dashboard')}}" class="logo">
                            @if(Auth::user()->user_type == "Superadmin")
                                <span>
                                    <img src="{{asset('simple_admin/images/nissan_chhap.png')}}" alt=""> नेपाल सरकार 
                                </span>
                            @else                           
                                <span>
                                    <img src="{{URL::asset('storage/uploads/office_logo/'.Auth::user()->officeUser->officeData['logo'])}}" alt=""> मुख्यमुन्त्री तथा मुन्त्रिपरिषद्को कार्यालय 
                                </span>
                            @endif
                                <i>
                                    <img src="{{asset('simple_admin/images/nissan_chhap.png')}}" alt="">
                                </i>
                        </a>
                    </div>

                    <nav class="navbar-custom">
                        <ul class="list-unstyled topbar-right-menu float-right mb-0">
                            <li class="dropdown notification-list">
                                <a class="nav-link dropdown-toggle waves-effect waves-light nav-user" data-toggle="dropdown" href="#" role="button"
                                aria-haspopup="false" aria-expanded="false">
                                <span class="ml-1">{{Auth::user()->name}} <i class="mdi mdi-chevron-down" style="color:black"></i> </span>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                                    
                                    <form method="POST" action="{{route('logout')}}">
                                        @csrf
                                        <button type="submit" class="dropdown-item notify-item"><i class="ti-power-off"></i> <span>Logout</span>
                                        </button>
                                    </form>

                                </div>
                            </li>

                        </ul>
                    </nav>

                </div>
                <!-- Top Bar End -->


                <!-- ========== Left Sidebar Start ========== -->
                <div class="left side-menu">
                    <div class="user-details">
                        <div class="pull-left">
                            <img src="{{asset('simple_admin/images/nissan_chhap.png')}}" alt="" class="thumb-md rounded-circle">
                        </div>
                        <div class="user-info">
                            <a href="#">{{Auth::user()->name}}</a>
                            <p class="text-muted m-0">{{Auth::user()->user_type}}</p>
                        </div>
                    </div>

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu" id="side-menu">
                            <li class="menu-title">Navigation</li>
                            <li>
                                <a href="{{route('dashboard')}}">
                                    <i class="ti-home"  style="color: grey"></i><span> गृहपृष्ठ </span>
                                </a>
                            </li>
                            @if(Auth::user()->user_type != "User")
                                <li>
                                    <a> <i class="fa fa-cogs" style="color: grey"></i> <span> सेटिंग
                                        </span>
                                        <span class="menu-arrow"></span>
                                    </a>
                                    <ul class="nav-second-level" aria-expanded="false">
                                        @if(Auth::user()->user_type == "Superadmin")
                                            <li>
                                                <a class="collapse-item" href="{{ route('office.gridView') }}">
                                                    <i class="fa fa-building" style="color: grey"></i> <span> कार्यालय  </span>
                                                </a>
                                            </li>
                                        @endif

                                        <li>
                                            <a class="collapse-item" href="{{ route('department.index') }}">
                                                <i class="fa fa-sitemap"  style="color: grey"></i> <span> कार्यालय संरचना </span>
                                            </a>
                                        </li>

                                        <li>
                                            <a class="collapse-item" href="{{ route('user.index') }}">
                                                <i class="fa fa-user"  style="color: grey"></i> <span> प्रयोगकर्ता </span>
                                            </a>
                                        </li>

                                        @if(Auth::user()->user_type == "Admin" || Auth::user()->user_type == "Superadmin")
                                            <li>
                                                <a class="collapse-item" href="{{ route('image_category.index') }}">
                                                    <i class="fa fa-file-image-o"  style="color: grey"></i> <span> फोटो वर्ग </span>
                                                </a>
                                            </li>
                                        @endif
                                    </ul>
                                </li>
                            @endif

                            <li>
                                <a href="{{ route('employee.index') }}">
                                    <i class="fa fa-users"  style="color: grey"></i> <span> कर्मचारी </span>
                                </a>
                            </li>

                            <li>
                                <a href="{{ route('citizen_charter.index') }}">
                                    <i class="fa fa-info-circle"  style="color: grey"></i> <span> नागरिक वडापत्र </span>
                                </a>
                            </li>

                            @if(Auth::user()->user_type != "User")
                                <li>
                                    <a> <i class="fa fa-pinterest-p" style="color: grey"></i> <span> प्रगति प्रतिबेदन
                                        </span>
                                        <span class="menu-arrow"></span>
                                    </a>
                                    <ul class="nav-second-level" aria-expanded="false">
                                        <li>
                                            <a class="collapse-item" href="{{route('monthly_progress.index')}}">
                                                <i class="fa fa-calendar" style="color: grey"></i> <span> मासिक प्रगति </span>
                                            </a>
                                        </li>

                                        <li>
                                            <a class="collapse-item" href="{{route('quarterly_progress.index')}}">
                                                <i class="fa fa-calendar"  style="color: grey"></i> <span> त्रैमासिक प्रगति</span>
                                            </a>
                                        </li>

                                        <li>
                                            <a class="collapse-item" href="{{route('yearly_progress.index')}}">
                                                <i class="fa fa-calendar"  style="color: grey"></i> <span> बार्षिक प्रगति </span>
                                            </a>
                                        </li>

                                    </ul>
                                </li>

                                <li>
                                    <a href="{{ route('photo.index') }}">
                                        <i class="fa fa-picture-o"  style="color: grey"></i> <span> फोटो ग्यालरी </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="{{ route('scroll_notice.index') }}">
                                        <i class="fa fa-file-text"  style="color: grey"></i> <span> सूचना तथा समाचार </span>
                                    </a>
                                </li>
                            @endif

                        </ul>

                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>

                </div>
                <!-- Left Sidebar End -->

