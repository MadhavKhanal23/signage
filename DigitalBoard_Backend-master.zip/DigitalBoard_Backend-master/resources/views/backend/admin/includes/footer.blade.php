        <!-- jQuery  -->
        <script src="{{asset('simple_admin/js/jquery.min.js')}}"></script>
        <script src="{{asset('simple_admin/js/popper.min.js')}}"></script>
        <script src="{{asset('simple_admin/js/bootstrap.min.js')}}"></script>
        <script src="{{asset('simple_admin/js/metisMenu.min.js')}}"></script>
        <script src="{{asset('simple_admin/js/waves.js')}}"></script>
        <script src="{{asset('simple_admin/js/jquery.slimscroll.js')}}"></script>
        

        <!-- Required datatable js -->
        <script src="{{asset('simple_admin/plugins/datatables/jquery.dataTables.min.js')}}"></script>
        <script src="{{asset('simple_admin/plugins/datatables/dataTables.bootstrap4.min.js')}}"></script>
        <script src="{{asset('simple_admin/plugins/switchery/switchery.min.js')}}"></script>
        <script src="{{asset('simple_admin/plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js')}}" type="text/javascript"></script>
        <!-- Buttons examples -->
        <script src="{{asset('simple_admin/plugins/datatables/dataTables.buttons.min.js')}}"></script>
        <script src="{{asset('simple_admin/plugins/datatables/buttons.bootstrap4.min.js')}}"></script>
        <script src="{{asset('simple_admin/plugins/datatables/jszip.min.js')}}"></script>
        <script src="{{asset('simple_admin/plugins/datatables/pdfmake.min.js')}}"></script>
        <script src="{{asset('simple_admin/plugins/datatables/vfs_fonts.js')}}"></script>
        <script src="{{asset('simple_admin/plugins/datatables/buttons.html5.min.js')}}"></script>
        <script src="{{asset('simple_admin/plugins/datatables/buttons.print.min.js')}}"></script>
        <script src="{{asset('simple_admin/plugins/sweetalert2/sweetalert2.min.js')}}"></script>
        <script src="{{asset('simple_admin/plugins/bootstrap-tagsinput/js/bootstrap-tagsinput.min.js')}}"></script>

        <!-- Key Tables -->
        <script src="{{asset('simple_admin/plugins/datatables/dataTables.keyTable.min.js')}}"></script>

        <!-- Responsive examples -->
        <script src="{{asset('simple_admin/plugins/datatables/dataTables.responsive.min.js')}}"></script>
        <script src="{{asset('simple_admin/plugins/datatables/responsive.bootstrap4.min.js')}}"></script>

        <!-- Selection table -->
        <script src="{{asset('simple_admin/plugins/datatables/dataTables.select.min.js')}}"></script>

          {{-- ck editor --}}
        <script src="//cdn.ckeditor.com/4.14.1/standard/ckeditor.js"></script>

        {{-- NEPALIDATETIME PICKER --}}
        <script src="{{asset('simple_admin/plugins/bootstrap-nepaliDatePicker/nepali.datepicker.v3.5.min.js')}}"></script>

        <script type="text/javascript">
            $(document).ready(function () {
                // Default Datatable
                $("#datatable").DataTable();

                //Buttons examples
                var table = $("#datatable-buttons").DataTable({
                lengthChange: false,
                buttons: ["copy", "excel", "pdf"],
                });

                // Key Tables

                $("#key-table").DataTable({
                keys: true,
                });

                // Responsive Datatable
                $("#responsive-datatable").DataTable();

                // Multi Selection Datatable
                $("#selection-datatable").DataTable({
                select: {
                    style: "multi",
                },
                });

                table
                .buttons()
                .container()
                .appendTo("#datatable-buttons_wrapper .col-md-6:eq(0)");
            });
        </script>
        
        <!--Morris Chart-->
        {{-- <script src="{{asset('simple_admin/plugins/morris/morris.min.js')}}"></script>
        <script src="{{asset('simple_admin/plugins/raphael/raphael-min.js')}}"></script> --}}

        <!-- Dashboard init -->
        {{-- <script src="{{asset('simple_admin/pages/jquery.dashboard.js')}}"></script> --}}

        <!-- App js -->
        <script src="{{asset('simple_admin/js/jquery.core.js')}}"></script>
        <script src="{{asset('simple_admin/js/jquery.app.js')}}"></script>
        <script>
             //for popup modal to select image and preview image
            function popup_perview_images(input) {
                    if (input.files && input.files[0]) {
                        var reader = new FileReader();
                        reader.onload = function (e) {
                            $('.image_preview_popup').attr('src', e.target.result);
                        }
                        reader.readAsDataURL(input.files[0]);
                    }
            }
            //for showing the selected replaced image
            $('body').on('change','.select_image_popup',(function(e){
                e.preventDefault();
                $('.changed_image_show').css('display','block');
                popup_perview_images(this);
            }));
        </script>

        {{-- for user type office / department selection --}}
        <script type="text/javascript">
            $('#userForm').on('change', '#userType', function(e)
            {
                e.preventDefault();
                var userType = $(this).children("option:selected").val();
                if(userType == "Admin")
                {
                    $('.office_department_information').hide();
                }
                else if(userType == "User")
                {
                    $('.office_department_information').show();
                }
            });
  
            $('#userForm,select').on( 'change','#userOffice', function(e) {
                var office_id = $(this).val();
                
                 $.ajax({
                     type:'GET',
                     url:"{{route('user.department')}}",
                     data:{
                         'office_id' : office_id
                     },
                     success:function(data){
                        //  console.log(data);
                        // $('#userDepartment').find('option').not(':first').remove();
                         for (i = 0; i < data.length; i++)
                         {
                         $('.userDepartment1').append( '<option value="'+data[i].id+'">'+data[i].department_name+'</option>' );
                         }
                           
                     },
                     error:function(){
                         
                     }
                 })
            });
        </script>
