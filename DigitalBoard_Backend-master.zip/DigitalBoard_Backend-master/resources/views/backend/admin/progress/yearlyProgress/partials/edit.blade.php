<div class="m-t-40 card-box">
    <div class="text-center">
        <h2 class="text-uppercase m-t-0 m-b-30">
            <a href="index.html" class="text-dark">
                <span><img src="{{asset('simple_admin/images/nissan_chhap.png')}}" alt="" height="50"> नेपाल सरकार </span>
            </a>
        </h2>
    </div>
    <div>
        @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif
    </div>
    <form method="POST" action="{{ route('yearly_progress.update', $yearlyProgress['id']) }}" enctype="multipart/form-data">
        @csrf
        @method("PUT")
        <div class="form-group m-b-20 row">
            <div class="col-md-6">
                <label> कार्यालय </label><sup class="text-danger">*</sup>
                <div class="input-group">
                    <select class="form-control" id="yearlyProgress_office" name="yearlyProgress_office">
                        @if(Auth::user()->user_type == "User")
                            <option selected value="{{Auth::user()->officeUser->office_id}}"> {{Auth::user()->officeUser->officeData->nepali_name}} </option>
                        @elseif(Auth::user()->user_type == "Admin" || Auth::user()->user_type == "Superadmin")
                            <option selected value="{{$yearlyProgress->office_id}}">{{$yearlyProgress->office['nepali_name']}}</option>
                            @foreach ($office_data as $office)
                                <option value={{$office['id']}}>{{$office['nepali_name']}}</option>
                            @endforeach
                        @endif
                    </select>
                </div>
            </div>

            <div class="col-md-6">
                <label> आर्थिक बर्ष </label><sup class="text-danger">*</sup>
                <div class="input-group">
                    <select class="form-control" id="yearlyProgress_year" name="yearlyProgress_year">
                            <option selected value="{{$yearlyProgress->fiscal_year_id}}">{{$yearlyProgress->year['fiscal_year']}}</option>
                            @foreach ($years as $year)
                                <option value={{$year['id']}}>{{$year['fiscal_year']}}</option>
                            @endforeach
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-6">
                <div class="form-group m-b-20">
                    <label for="year_current_budget">चालु बार्षिक बजेट</label><sup class="text-danger">*</sup>
                    <input class="form-control" type="text" id="year_current_budget" required="" name="year_current_budget" placeholder="yearly Current Budget" value="{{$yearlyProgress->budget['current_total_budget']}}">
                </div>
            </div>
            
            <div class="col-6">
                <div class="form-group m-b-20">
                    <label for="year_spend_budget">चालु खर्च</label><sup class="text-danger">*</sup>
                    <input class="form-control" type="text" id="year_spend_budget" required="" name="year_spend_budget" placeholder="yearly Spend Budget" value="{{$yearlyProgress->budget['current_spend_budget']}}">
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-6">
                <div class="form-group m-b-20">
                    <label for="year_capital_budget">पुजीगत बजेट</label><sup class="text-danger">*</sup>
                    <input class="form-control" type="text" id="year_capital_budget" required="" name="year_capital_budget" placeholder="Capital Total Budget" value="{{$yearlyProgress->budget['capital_total_budget']}}">
                </div>
            </div>
            
            <div class="col-6">
                <div class="form-group m-b-20">
                    <label for="year_capital_spend_budget">पुजीगत खर्च</label><sup class="text-danger">*</sup>
                    <input class="form-control" type="text" id="year_capital_spend_budget" required="" name="year_capital_spend_budget" placeholder="Capital Spend Budget" value="{{$yearlyProgress->budget['capital_spend_budget']}}">
                </div>
            </div>
        </div>
        
        <div class="form-group account-btn text-center m-t-10">
            <div class="column-full">
                <button class="btn btn-lg btn-primary btn-block" type="submit">Submit</button>
            </div>
        </div>
    </form>
</div>