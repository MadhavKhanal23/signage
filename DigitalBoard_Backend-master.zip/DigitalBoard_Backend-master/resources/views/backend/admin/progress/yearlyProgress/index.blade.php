@extends('layouts.app')

@section('dashboard_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('breadcum_title')
<li class="breadcrumb-item active"> <a href="{{route('yearly_progress.index')}}">बार्षिक</a></li>
@endsection

@section('create_button')
<a href="{{ route('yearly_progress.create') }}" data-toggle="modal" data-placement="top" title="नँया बार्षिक प्रगति"><i class="fa fa-plus" aria-hidden="true"></i></a>
@endsection

@section('box_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('content')
    <div class="row p-t-40">
        <div class="col-12">
            <hr>
            <center><h5>बार्षिक प्रगति</h5></center>
            <div class="alert alert-success alert-dismissible fade show text-center" role="alert" id="success_msg_div">
                <strong>नमस्कार {{Auth::user()->name}}!</strong> <span id="success_msg"> पङ्क्तिमा डबल किलिक गरि डाटा परिवर्तन गर्नुहोस। </span>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <hr>
            <div class="table-responsive">
                <table id="datatable" class="table table-bordered yearlyProgress_table">
                    <thead>
                    <tr>
                        <th class="text-center">क्र.सं</th>
                        <th class="text-center">बर्ष</th>
                        <th class="text-center">चालु बजेट</th>
                        <th class="text-center">चालु खर्च</th>
                        <th class="text-center">पुजीगत बजेट</th>
                        <th class="text-center">पुजीगत खर्च</th>
                    </tr>
                    </thead>

                    <tbody id="yearlyProgress_tbody">
                        @include('backend.admin.progress.yearlyProgress.partials.activeData')
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection

@section('modal_content')
@endsection

@section('javascript_content')
<script type="text/javascript">
    $('.yearlyProgress_table #yearlyProgress_tbody').on('dblclick', 'tr', function(e){
        e.preventDefault();
        Swal.fire({
                title: 'पुनश्च !!!!',
                text: "के तपाई परिवर्तन गर्न चाहनु हुन्छ ?",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'परिवर्तन',
                cancelButtonText: 'रद्द'
            }).then((result) => {
                if (result.value){
                    var row_id = $(this).attr("id");
                    var url = $(this).data("url");

                    $.ajax({
                        url:url, 
                        type:"get",
                        success:function(data){
                            const Toast = Swal.mixin({
                                toast: true,
                                position: 'top-end',
                                showConfirmButton: false,
                                timer: 3000,
                            });

                            Toast.fire({
                                type:'success',
                                title:'परिवर्तनको डाटा भर्नुहोस् ।।।'
                            });
                            $("#page_main_content").empty();
                            $("#page_main_content").html(data.html);
                        },
                        error:function(data){
                            Swal.fire({
                                title: 'Error',
                                text: "Failed to Edit!",
                                type: 'error'
                            });
                        },
                    });
                }
                else {
                    e.dismiss;
                }
            });
    })
</script>
@endsection
