@foreach($yearly_progress as $progress)
    <tr id="{{$progress->id}}" data-url= "{{route('yearly_progress.edit',$progress['id'])}}" >
        <td class="text-center">{{$loop->iteration}}</td>
        <td class="text-center">{{$progress->year['fiscal_year']}}</td>
        <td class="text-center">{{$progress->budget['current_total_budget']}}</td>
        <td class="text-center">{{$progress->budget['current_spend_budget']}}</td>
        <td class="text-center">{{$progress->budget['capital_total_budget']}}</td>
        <td class="text-center">{{$progress->budget['capital_spend_budget']}}</td>
    </tr>
@endforeach