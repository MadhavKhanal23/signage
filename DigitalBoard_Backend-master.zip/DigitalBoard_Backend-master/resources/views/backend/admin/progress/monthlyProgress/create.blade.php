@extends('layouts.app')

@section('dashboard_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('breadcum_title')
<li class="breadcrumb-item active"> <a href="{{route('monthly_progress.index')}}">मासिक प्रगति</a></li>
<li class="breadcrumb-item active"> <a href="{{route('monthly_progress.create')}}">नँया</a></li>

@endsection

@section('create_button')
<a href="{{ route('monthly_progress.create') }}" data-toggle="modal" data-placement="top" title="नँया मासिक प्रगति"><i class="fa fa-plus" aria-hidden="true"></i></a>
@endsection

@section('box_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('content')
<div class="m-t-40 card-box">
    <div class="text-center">
        <h2 class="text-uppercase m-t-0 m-b-30">
            <a href="index.html" class="text-dark">
                <span><img src="{{asset('simple_admin/images/nissan_chhap.png')}}" alt="" height="50"> नेपाल सरकार </span>
            </a>
        </h2>
    </div>
    <div>
        @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif
    </div>
    <form method="POST" action="{{ route('monthly_progress.store') }}" enctype="multipart/form-data">
        @csrf
       
        <div class="form-group m-b-20 row">
            <div class="col-md-6">
                <label> कार्यालय </label><sup class="text-danger">*</sup>
                <div class="input-group">
                    <select class="form-control" id="monthlyProgress_office" name="monthlyProgress_office">
                        @if(Auth::user()->user_type == "User")
                            <option selected value="{{Auth::user()->officeUser->office_id}}"> {{Auth::user()->officeUser->officeData->nepali_name}} </option>
                        @elseif(Auth::user()->user_type == "Admin" || Auth::user()->user_type == "Superadmin")
                            <option selected disabled>कार्यालय छनौट गर्नुहोस् </option>
                            @foreach ($office_data as $office)
                                <option value={{$office['id']}}>{{$office['nepali_name']}}</option>
                            @endforeach
                        @endif
                    </select>
                </div>
            </div>

            <div class="col-md-6">
                <label> महिना </label><sup class="text-danger">*</sup>
                <div class="input-group">
                    <select class="form-control" id="monthlyProgress_month" name="monthlyProgress_month">
                            <option selected disabled> महिना छनौट गर्नुहोस् </option>
                            @foreach ($months as $month)
                                <option value={{$month['id']}}>{{$month['months']}}</option>
                            @endforeach
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-6">
                <div class="form-group m-b-20">
                    <label for="month_current_budget">चालु मासिक बजेट</label><sup class="text-danger">*</sup>
                    <input class="form-control" type="text" id="month_current_budget" required="" name="month_current_budget" placeholder="हालको मासिक बुजेट" value="{{old('month_current_budget')}}">
                </div>
            </div>
            
            <div class="col-6">
                <div class="form-group m-b-20">
                    <label for="month_spend_budget">चालु खर्च</label><sup class="text-danger">*</sup>
                    <input class="form-control" type="text" id="month_spend_budget" required="" name="month_spend_budget" placeholder="खर्च बजेट" value="{{old('month_spend_budget')}}">
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-6">
                <div class="form-group m-b-20">
                    <label for="month_capital_budget">पुजीगत बजेट</label><sup class="text-danger">*</sup>
                    <input class="form-control" type="text" id="month_capital_budget" required="" name="month_capital_budget" placeholder="कुल मासिक बजेट" value="{{old('month_capital_budget')}}">
                </div>
            </div>
            
            <div class="col-6">
                <div class="form-group m-b-20">
                    <label for="month_capital_spend_budget">पुजीगत खर्च</label><sup class="text-danger">*</sup>
                    <input class="form-control" type="text" id="month_capital_spend_budget" required="" name="month_capital_spend_budget" placeholder="खर्च बजेट" value="{{old('month_capital_spend_budget')}}">
                </div>
            </div>
        </div>
        
        <div class="form-group account-btn text-center m-t-10">
            <div class="column-full">
                <button class="btn btn-lg btn-primary btn-block" type="submit">Submit</button>
            </div>
        </div>
    </form>
</div>
@endsection

@section('modal_content')
@endsection

@section('javascript_content')
<script>
    //  $(document).ready(function(){
    //     $('.date').nepaliDatePicker({
           
    //     });
    // });
</script>
@endsection
