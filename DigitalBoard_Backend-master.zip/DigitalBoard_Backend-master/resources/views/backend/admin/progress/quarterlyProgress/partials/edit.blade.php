<div class="m-t-40 card-box">
    <div class="text-center">
        <h2 class="text-uppercase m-t-0 m-b-30">
            <a href="index.html" class="text-dark">
                <span><img src="{{asset('simple_admin/images/nissan_chhap.png')}}" alt="" height="50"> नेपाल सरकार </span>
            </a>
        </h2>
    </div>
    <div>
        @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif
    </div>
    <form method="POST" action="{{ route('quarterly_progress.update', $quarterlyProgress['id']) }}" enctype="multipart/form-data">
        @csrf
        @method("PUT")
        <div class="form-group m-b-20 row">
            <div class="col-md-6">
                <label> कार्यालय </label><sup class="text-danger">*</sup>
                <div class="input-group">
                    <select class="form-control" id="quarterlyProgress_office" name="quarterlyProgress_office">
                        @if(Auth::user()->user_type == "User")
                            <option selected value="{{Auth::user()->officeUser->office_id}}"> {{Auth::user()->officeUser->officeData->nepali_name}} </option>
                        @elseif(Auth::user()->user_type == "Admin" || Auth::user()->user_type == "Superadmin")
                            <option selected value="{{$quarterlyProgress->office_id}}">{{$quarterlyProgress->office['nepali_name']}}</option>
                            @foreach ($office_data as $office)
                                <option value={{$office['id']}}>{{$office['nepali_name']}}</option>
                            @endforeach
                        @endif
                    </select>
                </div>
            </div>

            <div class="col-md-6">
                <label> त्रैमासिक </label><sup class="text-danger">*</sup>
                <div class="input-group">
                    <select class="form-control" id="quarterlyProgress_quarter" name="quarterlyProgress_quarter">
                            <option selected value="{{$quarterlyProgress->quarter_id}}">{{$quarterlyProgress->quarter['quarter_name']}}</option>
                            @foreach ($quarters as $quarter)
                                <option value={{$quarter['id']}}>{{$quarter['quarter_name']}}</option>
                            @endforeach
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-6">
                <div class="form-group m-b-20">
                    <label for="quarter_current_budget">चालु त्रैमासिक बजेट</label><sup class="text-danger">*</sup>
                    <input class="form-control" type="text" id="quarter_current_budget" required="" name="quarter_current_budget" placeholder="Quarterly Current Budget" value="{{$quarterlyProgress->budget['current_total_budget']}}">
                </div>
            </div>
            
            <div class="col-6">
                <div class="form-group m-b-20">
                    <label for="quarter_spend_budget">चालु खर्च</label><sup class="text-danger">*</sup>
                    <input class="form-control" type="text" id="quarter_spend_budget" required="" name="quarter_spend_budget" placeholder="Quarterly Spend Budget" value="{{$quarterlyProgress->budget['current_spend_budget']}}">
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-6">
                <div class="form-group m-b-20">
                    <label for="quarter_capital_budget">पुजीगत बजेट</label><sup class="text-danger">*</sup>
                    <input class="form-control" type="text" id="quarter_capital_budget" required="" name="quarter_capital_budget" placeholder="Capital Total Budget" value="{{$quarterlyProgress->budget['capital_total_budget']}}">
                </div>
            </div>
            
            <div class="col-6">
                <div class="form-group m-b-20">
                    <label for="quarter_capital_spend_budget">पुजीगत खर्च</label><sup class="text-danger">*</sup>
                    <input class="form-control" type="text" id="quarter_capital_spend_budget" required="" name="quarter_capital_spend_budget" placeholder="Capital Spend Budget" value="{{$quarterlyProgress->budget['capital_spend_budget']}}">
                </div>
            </div>
        </div>
        
        <div class="form-group account-btn text-center m-t-10">
            <div class="column-full">
                <button class="btn btn-lg btn-primary btn-block" type="submit">Submit</button>
            </div>
        </div>
    </form>
</div>