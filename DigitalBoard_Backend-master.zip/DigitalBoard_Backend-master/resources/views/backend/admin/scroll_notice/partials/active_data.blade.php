@foreach($scroll_notices as $scroll_notice)
    @if(Auth::user()->user_type == "Admin" || Auth::user()->user_type == "Superadmin")
        <tr id="{{$scroll_notice->id}}" data-url="{{route('scroll_notice.edit', $scroll_notice['id'])}}">
            <td class="text-center">{{$loop->iteration}}</td>
            <td class="text-center" style="font-size: 1rem" id="notice_office{{$scroll_notice->id}}">{{$scroll_notice->office['nepali_name'] ?? "N/A"}}</td>
            <td class="text-center" id="notice_title{{$scroll_notice->id}}">{{$scroll_notice->notice_title}}</td>
            <td class="text-center" id="notice_description{{$scroll_notice->id}}">{!!$scroll_notice->notice_description!!}</td>
            <td class="text-center">
                @if($scroll_notice['publish'] ==1)
                    <div class="switchery-demo">
                        <input type="checkbox" class="scroll_notice_publish" data-publish="0" id="scroll_notice_publish{{$scroll_notice['id']}}" checked data-plugin="switchery" data-id="{{$scroll_notice['id']}}" data-status="1" data-color="#007bff" data-size="small"/>                
                    </div>
                @else
                    <div class="switchery-demo">
                        <input type="checkbox" class="scroll_notice_publish" data-publish="1" id="scroll_notice_Unpublish{{$scroll_notice['id']}}"  data-plugin="switchery" data-id="{{$scroll_notice['id']}}" data-status="1" data-color="#007bff" data-size="small"/>                
                    </div>
                @endif
            
            </td> 
            <td class="text-center">
                <div class="switchery-demo">
                    <input type="checkbox" class="scroll_notice_delete" data-url="{{route('scroll_notice.destroy', $scroll_notice['id'])}}" id="scroll_notice_delete{{$scroll_notice['id']}}" checked data-plugin="switchery" data-id="{{$scroll_notice['id']}}" data-status="1" data-color="#007bff" data-size="small"/>
                </div>
            </td>  
        </tr>
    @elseif(Auth::user()->user_type == "User" && Auth::user()->officeUser['office_id'] == $scroll_notice['office_id'])
        <tr id="{{$scroll_notice->id}}" data-url="{{route('scroll_notice.edit', $scroll_notice['id'])}}">
            <td class="text-center">{{$loop->iteration}}</td>
            <td class="text-center" style="font-size: 1rem" id="notice_office{{$scroll_notice->id}}">{{$scroll_notice->office['nepali_name'] ?? "N/A"}}</td>
            <td class="text-center" id="notice_title{{$scroll_notice->id}}">{{$scroll_notice->notice_title}}</td>
            <td class="text-center" id="notice_description{{$scroll_notice->id}}">{!!$scroll_notice->notice_description!!}</td>
            <td class="text-center">
                @if($scroll_notice['publish'] ==1)
                    <div class="switchery-demo">
                        <input type="checkbox" class="scroll_notice_publish" data-publish="0" id="scroll_notice_publish{{$scroll_notice['id']}}" checked data-plugin="switchery" data-id="{{$scroll_notice['id']}}" data-status="1" data-color="#007bff" data-size="small"/>                
                    </div>
                @else
                    <div class="switchery-demo">
                        <input type="checkbox" class="scroll_notice_publish" data-publish="1" id="scroll_notice_Unpublish{{$scroll_notice['id']}}"  data-plugin="switchery" data-id="{{$scroll_notice['id']}}" data-status="1" data-color="#007bff" data-size="small"/>                
                    </div>
                @endif
            
            </td> 
            <td class="text-center">
                <div class="switchery-demo">
                    <input type="checkbox" class="scroll_notice_delete" data-url="{{route('scroll_notice.destroy', $scroll_notice['id'])}}" id="scroll_notice_delete{{$scroll_notice['id']}}" checked data-plugin="switchery" data-id="{{$scroll_notice['id']}}" data-status="1" data-color="#007bff" data-size="small"/>
                </div>
            </td>  
        </tr>
    @endif
@endforeach