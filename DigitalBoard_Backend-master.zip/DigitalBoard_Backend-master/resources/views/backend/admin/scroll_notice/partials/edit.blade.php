
<div class="m-t-40 card-box">
    <div class="text-center">
        <h2 class="text-uppercase m-t-0 m-b-30">
            <a href="index.html" class="text-dark">
                <span><img src="{{asset('simple_admin/images/nissan_chhap.png')}}" alt="" height="50"> नेपाल सरकार </span>
            </a>
        </h2>
    </div>
    <div>
        @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif
    </div>
    <form method="POST" action="{{route('scroll_notice.update',$scroll_notice['id']) }}" enctype="multipart/form-data">
        @csrf
        @method("PUT")
        <div class="form-group m-b-20">
            <div class="column-full">
                <label> कार्यालय </label><sup class="text-danger">*</sup>
                <div class="input-group">
                    <select class="form-control" id="notice_office" name="notice_office">
                        @if(Auth::user()->user_type == "User")
                            <option selected value="{{Auth::user()->officeUser->office_id}}"> {{Auth::user()->officeUser->officeData->nepali_name}} </option>
                        @elseif(Auth::user()->user_type == "Admin" || Auth::user()->user_type == "Superadmin")
                            <option selected value="{{$scroll_notice->office['id']}}">{{$scroll_notice->office['nepali_name']}}</option>
                            @foreach ($office_data as $office)
                                <option value={{$office['id']}}>{{$office['nepali_name']}}</option>
                            @endforeach
                        @endif
                    </select>
                </div>
            </div>
        </div>

        <div class="form-group m-b-20">
            <div class="column-full">
                <label for="notice_title">सूचनाको शीर्षक</label><sup class="text-danger">*</sup>
                <input class="form-control" type="text" id="notice_title" required=""   name="notice_title" placeholder="Notice Title" value="{{$scroll_notice['notice_title']}}">
            </div>
        </div>
        <div class="row">
            <div class="col-6">
                <div class="form-group m-b-20">
                        <div class="form-group m-b-20">
                        <label for="notice_display_from">प्रकाशन मिति</label><sup class="text-danger">*</sup>
                        <input class="form-control date" type="date" id="notice_display_from" required=""   name="notice_display_from" placeholder="Notice Display From" value="{{$scroll_notice['display_from']}}">
                    </div>
                </div>
            </div>
                <div class="col-6">
                        <div class="form-group m-b-20">
                        <label for="notice_display_to">प्रकाशन अन्तिम मिति</label><sup class="text-danger">*</sup>
                        <input class="form-control date" type="date" id="notice_display_to" required=""   name="notice_display_to" placeholder="Notice Display To" value="{{$scroll_notice['display_to']}}">
                    </div>
                </div>
        </div>
        <div class="form-group m-b-20">
            <div class="column-full">
                <label for="notice_description">सूचनाको विवरण</label><sup class="text-danger">*</sup>
                <textarea class="form-control" type="text" id="notice_description" required=""   name="notice_description" placeholder="Notice Description">{{$scroll_notice['notice_description']}}</textarea>
            </div>
        </div>

      
        <div class="form-group account-btn text-center m-t-10">
            <div class="column-full">
                <button class="btn btn-lg btn-primary btn-block" type="submit">Submit</button>
            </div>
        </div>
    </form>
</div>

<script>
    // $(document).ready(function(){
    //     $('.date').nepaliDatePicker({
    //         unicodeDate: true
    //     });
    // });
</script>