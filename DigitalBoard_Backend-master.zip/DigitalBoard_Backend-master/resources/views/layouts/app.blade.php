@include('backend.admin.includes.header')
<style>
    li a{
      color:white;
    }
    a i{
      color: white;
    }
    a{
      color: white;
    }
    .design{
      border-radius: 50px; 
      background-color:#23b195;
    }
  </style>
<body>
    <!-- Begin page -->
    <div id="wrapper">
      @include('backend.admin.includes.sidebar')
  
      <div class="content-page">
        <!-- Start content -->
        <div class="content">
          <div class="container-fluid">
  
            <div class="row">
              <div class="col-sm-12 justify-content-between">
                <div class="row">
  
                  <div class="col-md-4">
                    <div class="c-subheader justify-content-between">
                      <ol class="breadcrumb breadcurmb-bg border-0 m-0 px-0 px-md-3 design" >
                        <li class="breadcrumb-item list" > <a  class="font-color" href="{{route('dashboard')}}" ><i class="fa fa-home"style="color:#FFFFFF;"></i></a></li>
                        @yield('breadcum_title')  
                      </ol>
                    </div>
                  </div>
                  <div class="col-md-4">
                    {{-- // --}}
                  </div>
                  <div class="col-md-4">
                    <div class="breadcrumb float-right design">
                      @yield('create_button')
                    </div>
  
                  </div>
                </div>
              </div>
  
            </div>
            <div id="page_main_content">
              @if(Session::has('message'))
              <div class="alert alert-success alert-dismissible fade show" role="alert">
                {{ Session::get('message') }}
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              @endif
              @yield('content')
              @yield('modal_content')
            </div>
  
          </div> <!-- container -->
  
  
          <div class="footer">
            <div>
              <strong>Bootwal R & D</strong> - Copyright © 2021
            </div>
          </div>
  
        </div> <!-- content -->
  
      </div>
  
      <!-- ============================================================== -->
      <!-- End Right content here -->
      <!-- ============================================================== -->
  
  
    </div>
@include('backend.admin.includes.footer')
@yield('javascript_content')
</body>
</html>



