@extends('layouts.app')

@section('dashboard_heading')
Welcome ! {{Auth::user()->name}}
@endsection



@section('breadcum_title')
<li class="breadcrumb-item active"> <a href="{{route('dashboard')}}"> गृहपृष्ठ </a></li>
@endsection

@section('create_button')
<a href="{{route('dashboard')}}"><i class="fa fa-home" aria-hidden="true"></i> गृहपृष्ठ</a>
@endsection

@section('box_heading')
Welcome ! {{Auth::user()->name}}
@endsection

@section('content')
    @include('backend.admin.includes.dashboardIndexContent')
@endsection

@section('modal_content')
@endsection

@section('javascript_content')
@endsection



