<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style.css">
        <title>Smart TV</title>
        <!-- App favicon -->
        <link rel="shortcut icon" href="{{asset('simple_admin/images/nissan_chhap.png')}}" />

            <style>
                * {
                padding: 0;
                margin: 0;
                box-sizing: border-box;
                }

                html {
                    font-size: 10px;
                    font-family: monospace;
                }

                a {
                    text-decoration: none;
                }

                .container {
                    min-height: 100vh;
                    width: 100%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }

                #hero {
                    background-size: cover;
                    /* height: 40%;
                    width: 100%; */
                    background-attachment: fixed;
                    background-position: center; 
                    position: relative;
                    z-index: 1;
                }

                #hero::after {
                    content: "";
                    position: absolute;
                    left: 0;
                    top: 0;
                    height: 100%;
                    width: 100%;
                    background-color: black;
                    opacity: .7;
                    z-index: -1;
                }

                #hero h1 {
                    display: block;
                    color: white;
                    width: fit-content;
                    font-size: 2.5rem;
                    position: relative;
                }

                #hero h2 {
                    display: block;
                    color: white;
                    width: fit-content;
                    font-size: 1rem;
                    position: relative;
                }

                #hero .cta {
                    display: block;
                    padding: 10px 30px;
                    color: white;
                    background-color: transparent;
                    border: 2px solid green;
                    font-size: 2rem;
                    text-transform: uppercase;
                    letter-spacing: .1rem;
                    transition: .3s ease;
                    transition-property: background-color, color;
                    margin-top: 30px;
                    margin-left: 10px;
                    text-align:center;
                /* left:50%; */
                }
                #hero .home_page{
                    display: block;
                    text-align:center;
                    padding: 10px 30px;
                    color: white;
                    background-color: transparent;
                    border: 2px solid green;
                    font-size: 2rem;
                    text-transform: uppercase;
                    letter-spacing: .1rem;
                    transition: .3s ease;
                    transition-property: background-color, color;
                    margin-top: 30px;

                }
                .footer
                {
                    color:white;
                    text-align:center;
                    font-size: 1.5rem;
                    letter-spacing: .1rem;
                    margin-top:30px;
                }


                #hero .cta:hover {
                    color: white;
                    background-color: green;
                }

                #hero .home_page:hover {
                    color: white;
                    background-color: green;
                }
               /* .image{
                margin-left: 170px;
                height:150px;
                width:150px;
                border-top-left-radius: 50% 50%;
                border-top-right-radius: 50% 50%;
                border-bottom-right-radius: 50% 50%;
                border-bottom-left-radius: 50% 50%;
                } */
                .heading span{
                    margin-left: 140px;
                    margin-bottom: 8px;
                    display: block;
                    color: white;
                    width: fit-content;
                    font-size: 2rem; 
                     position: relative;
                }
                .heading span #text{
                    margin-left:40px;
                    display: block;
                    color: white;
                    width: fit-content;
                    font-size: 2rem; 
                     position: relative;
                }
                .heading h3{
                    color:white;
                    font-size: 2.8rem;
                    margin-bottom:10px;
                    margin-left: 25px;

                }

                #hero .container:hover{
                    /* background-color: rgba(0, 0, 0, 0.3); */
                    /* box-shadow: 0 0 10px #000;
                    border-radius: 5px; */
                    position:absolute;
                    margin: auto auto;
                }
                #hero .container{
                    margin: auto auto;
                    padding: 40px;
                    position:relative;
                    left: 0;
                    right: 0;
                    width: 600px;
                    top:50%;
                }

                #hero .container:before {
                background-image: url('{{ asset('/simple_admin/images/TV_App.png') }}');
                width: 100%;
                height: 100%;
                background-size: cover;
                content: "";
                position: fixed;
                left: 0;
                right: 0;
                top: 0;
                bottom: 0;
                z-index: -1;
                /* display: block; */
                filter: blur(0px);
                }
                
                #hero .logo-image{
                    margin-left: 200px;
                    margin-bottom: 10px;
                }
            </style>
    </head>

    <body>
        
        <section id="hero">
            <div class="container hero">
                <div>
                    <img class="logo-image" src="{{asset('simple_admin/images/nissan_chhap.png')}}" alt="" height="50">
                    <div class="heading">
                      <span>
                        <b id="text" > प्रदेश सरकार <br/><br/>
                        लुम्बिनी प्रदेश </b>
                      </span>
                        <h3>
                            <strong>
                    मुख्यमन्त्री तथा मन्त्रिपरिषदको कार्यालय<br>
                            </strong>
                        </h3>
                        <span>
                     <b>मुकाम: बुटवल,नेपाल</b> <br><br>
                      </span>   
                    </div>
                
                    <h1 style="margin-left: 130px; font-size:2.5rem">डिजिटल सूचना बोर्ड</h1>
                    @if (Route::has('login'))
                    @auth
                    <a href="{{ url('/dashboard') }}" type="button" class="text-lg underline home_page">Home</a>
                    @else
                    <a href="{{ route('login') }}" type="button" class="text-lg underline cta">Login</a>
                    @endif
                    @endif
                    <div class="footer text-center">
                        <div>
                            <strong > <a style="color:#ffff !important;" href="https://www.bootwal.com/" target="blank"> Bootwal R & D </a></strong> - Copyright
                            ©
                            2021
                        </div>
                    </div>
                    {{-- <a href="#" type="button" class="cta">Login</a> --}}
                </div>
            </div>
        </section>


    </body>

</html>

