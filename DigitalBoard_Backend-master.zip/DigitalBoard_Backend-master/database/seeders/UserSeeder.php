<?php

namespace Database\Seeders;
use Illuminate\Supports\Facades\DB;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // User::truncate();

        $users = User::create([
            'name' => "SuperAdmin",
            'email' => 'superadmin@gmail.com',
            'password' => Hash::make('superadmin@gmail.com'),
            'mobile_number' => '9847008700',
            'address' => 'Butwal-11, Devinagar',
            'user_type'=> "SuperAdmin"
        ]);
    }
}
