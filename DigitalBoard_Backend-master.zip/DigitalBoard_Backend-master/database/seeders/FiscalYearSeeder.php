<?php

namespace Database\Seeders;

use App\Models\FiscalYear;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FiscalYearSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('fiscal_years')->truncate();
        FiscalYear::insert([
            ['fiscal_year' => '०७७/०७८'],
            ['fiscal_year' => '०७८/०७९'],
            ['fiscal_year' => '०७९/०८०'],
            ['fiscal_year' => '०८०/०८१'],
            ['fiscal_year' => '०८१/०८२']
        ]);
    }
}
