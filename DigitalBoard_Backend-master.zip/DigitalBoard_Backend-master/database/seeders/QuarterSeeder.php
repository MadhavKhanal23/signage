<?php

namespace Database\Seeders;

use App\Models\Quarter;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class QuarterSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('quarters')->truncate();
        Quarter::insert([
            ['quarter_name' => 'प्रथम त्रैमासिक'],
            ['quarter_name' => 'दोस्रो त्रैमासिक'],
            ['quarter_name' => 'तेस्रो त्रैमासिक'],
            ['quarter_name' => 'चौथो त्रैमासिक'],

        ]);
    }
}
