<?php

namespace Database\Seeders;
use DB;

use Illuminate\Database\Seeder;
use App\Models\Month;



class MonthSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('months')->truncate();
        Month::insert([
            ['months' => 'वैशाख'],
            ['months' => 'ज्येष्ठ'], 
            ['month' => 'आषाढ़'],
            ['month' => 'श्रावण'],
            ['month' => 'भदौ'],
            ['month' => 'असोज'],
            ['month' => 'कार्तिक'],
            ['month' => 'मंसिर'],
            ['month' => 'पुष'],
            ['month' => 'माघ'],
            ['month' => 'फागुन'],
            ['month' => 'चैत'],

        ]);
        
    }
}
