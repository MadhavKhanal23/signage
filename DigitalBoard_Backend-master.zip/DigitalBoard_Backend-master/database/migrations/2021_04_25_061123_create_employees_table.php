<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEmployeesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employees', function (Blueprint $table) {
            $table->id();
            $table->integer('department_id');
            $table->string('employee_name',100);
            $table->string('designation',50);
            $table->integer('room_no');
            $table->string('mobile_no',15);
            $table->string('landline_no',15);
            $table->string('email');
            $table->string('image');
            $table->enum('current_status',['in','out','busy']);
            $table->boolean('is_dept_head')->default(0);
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employees');
    }
}
