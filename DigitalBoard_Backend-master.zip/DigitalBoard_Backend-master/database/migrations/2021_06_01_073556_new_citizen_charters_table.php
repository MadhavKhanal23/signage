<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class NewCitizenChartersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('citizen_charters', function (Blueprint $table) {
            Schema::dropIfExists('citizen_charters');
            $table->id();
            $table->integer('department_id');
            $table->integer('employee_id');
            $table->string('service_type',250);
            $table->string('service_time',255);
            $table->string('service_charge');
            $table->longtext('important_document');
            $table->boolean('publish')->default(0);
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('citizen_charters');
    }
}
