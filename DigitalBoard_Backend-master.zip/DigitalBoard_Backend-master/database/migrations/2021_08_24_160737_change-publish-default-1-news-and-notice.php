<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class ChangePublishDefault1NewsAndNotice extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('scroll_notices', function (Blueprint $table) {
            $table->boolean('publish')->default(1)->change();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('scroll_notices', function (Blueprint $table) {
            $table->boolean('publish')->default(0)->change();
        });
    }
}
