<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class DropProjectTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::dropIfExists('projects');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::create('projects', function (Blueprint $table) {
            $table->id();
            $table->integer('office_id');
            $table->string('project_title');
            $table->longText('project_description');
            $table->string('fiscal_year', 125);
            $table->date('start_date');
            $table->date('end_date');
            $table->boolean('publish')->default(0);
            $table->softDeletes();
            $table->timestamps();
        });
    }
}
