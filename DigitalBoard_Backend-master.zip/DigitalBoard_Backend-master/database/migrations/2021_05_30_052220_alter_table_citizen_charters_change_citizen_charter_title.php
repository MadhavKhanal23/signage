<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterTableCitizenChartersChangeCitizenCharterTitle extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('citizen_charters', function (Blueprint $table) {
            $table->string('citizen_charter_title',255)->change();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('citizencharters', function (Blueprint $table) {
            $table->dropColumn('citizen_charter_title');
            
        });
    }
}
