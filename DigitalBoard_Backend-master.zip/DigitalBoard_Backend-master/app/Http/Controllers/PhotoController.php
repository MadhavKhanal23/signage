<?php

namespace App\Http\Controllers;

use App\Models\ImageCategory;
use App\Models\Office;
use App\Models\OfficeUser;
use App\Models\Photo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Storage;
use Auth;

class PhotoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(Auth::user()->user_type == "Superadmin")
        {
            $photos = Photo::all();
        }
        else if(Auth::user()->user_type == "Admin")
        {
            $office_id = Auth::user()->officeUser->office_id;
            $photos = Photo::where('office_id', $office_id)->latest()->get();

        }
        else{
            Session::flash('message','फोटोको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
        return view('backend.admin.photo.index',compact('photos'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {   
        if(Auth:: user()->user_type == "Superadmin")
        {
            $office_data = Office::all();
            $image_categories = ImageCategory::all();
        }
        elseif(Auth::user()->user_type == "Admin" )
        {
            $office_id = Auth::user()->officeUser->office_id;
            $office_data = Office::where('id', $office_id)->latest()->get();
            $image_categories = ImageCategory::all();
        }
        else{
            Session::flash('message','प्रगति प्रतिबेदनको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
        return view('backend.admin.photo.create',compact('office_data','image_categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'photo_office' => 'required|integer',
            'photo_title' => 'nullable|string',
            'photo_description' => 'nullable|string',
            'photo_category' =>'required|integer',
            'photo_display_from' => 'nullable|date',
            'photo_display_to' => 'nullable|date',
            'photo_display_time' => 'nullable|string',
            'photo_image' => 'required|mimes:png,jpeg,jpg,svg',
            'is_important' => 'nullable|boolean'
        ]);


        $fileName =Null;
        if($request->hasFile('photo_image'))
        {
            $fileName=time().$request->photo_image->getClientOriginalName();
            $filePath = $request->file('photo_image')->storeAs('public/uploads/photo_image', $fileName);
        }

        $photo = Photo::create([
            'office_id' => $validated['photo_office'],
            'photo_title' => $validated['photo_title'],
            'category_id' => $validated['photo_category'],
            'photo_image' => $fileName,
            'description' => $validated['photo_description'],
            'display_from' => $validated['photo_display_from'],
            'display_to' => $validated['photo_display_to'],
            'display_time' => $validated['photo_display_time'],
            'is_important'=> $validated['is_important']
        ]);

        Session::flash('message','फोटोको डाटा सुरक्छित भयो ।।।');
        return redirect()->route('photo.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Photo  $photo
     * @return \Illuminate\Http\Response
     */
    public function show(Photo $photo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Photo  $photo
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, $id)
    {
        $photo_data = Photo::find($id);
        if($request->ajax()){
            if(Auth:: user()->user_type == "Superadmin")
            {
                $office_data = Office::all();
                $image_categories = ImageCategory::all();
            }
            elseif(Auth::user()->user_type == "Admin" )
            {
                $office_id = Auth::user()->officeUser->office_id;
                $office_data = Office::where('id', $office_id)->latest()->get();
                $image_categories = ImageCategory::all();
            }
            
            $html =  view('backend.admin.photo.partials.edit')->with(compact('photo_data','office_data','image_categories'))->render();
            return response()->json(['success'=> "success",'data'=>$photo_data,'html'=>$html]);
        }
        else{
            Session::flash('message','प्रगति प्रतिबेदनको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Photo  $photo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'photo_office' => 'required|integer',
            'photo_title' => 'sometimes|string|max:255',
            'photo_category' =>'required|integer',
            'photo_description' => 'sometimes|string',
            'photo_display_from' => 'nullable|date',
            'photo_display_to' => 'nullable|date',
            'photo_display_time' => 'nullable|string',
            'oldPhotoImage'=>'sometimes|string',
            'photo_image' => 'sometimes|mimes:png,jpeg,jpg,svg',
            'is_important' => 'required|boolean'
        ]);

        $fileName =Null;
        if($request->hasFile('photo_image'))
        {
            Storage::delete('public/uploads/photo_image'.$validated['oldPhotoImage']);
            $fileName=time().$request->photo_image->getClientOriginalName();
            $filePath = $request->file('photo_image')->storeAs('public/uploads/photo_image', $fileName);
        }
        else
        {
            $fileName = $validated['oldPhotoImage'];
        }

        $photo_update = Photo::where('id', $id)->update([
            'office_id' => $validated['photo_office'],
            'photo_title' => $validated['photo_title'],
            'category_id' => $validated['photo_category'],
            'photo_image' => $fileName,
            'description' => $validated['photo_description'],
            'display_from' => $validated['photo_display_from'],
            'display_to' => $validated['photo_display_to'],
            'display_time' => $validated['photo_display_time'],
            'is_important' => $validated['is_important'],
        ]);

        Session::flash('message','फोटोको डाटा परिवर्तन भयो ।।।');
        return redirect()->route('photo.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Photo  $photo
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        if($request->ajax()){
            $photo_delete = Photo::where('id', $id)->delete();

            if(Auth::user()->user_type == "Superadmin")
            {
                $photos = Photo::all();
            }
            else if(Auth::user()->user_type == "Admin")
            {
                $office_id = Auth::user()->officeUser->office_id;
                $photos = Photo::where('office_id', $office_id)->latest()->get();
            }
        
            $html =  view('backend.admin.photo.partials.activeData')->with(compact('photos'))->render();
            return response()->json(['success'=> "success", 'html'=>$html]);
        }
        else{
            Session::flash('message','प्रगति प्रतिबेदनको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }

    }

    public function publish(Request $request)
    {
       $id = $request->photo_id;

       if($request->ajax()){
            $photo_publish = Photo::where('id', $id)->update([
                    'publish' => $request->publish
            ]);
            if(Auth::user()->user_type == "Superadmin")
            {
                $photos = Photo::all();
            }
            else if(Auth::user()->user_type == "Admin")
            {
                $office_id = Auth::user()->officeUser->office_id;
                $photos = Photo::where('office_id', $office_id)->latest()->get();
            }
            $success = '';
            if($request->publish == 1)
            {
                    $success = "फोटोको डाटा प्रकासित भयो ।।। ";
            }
            else
            {
                    $success = "फोटोको डाटा अप्रकासित भयो ।।। ";
            }
            $html =  view('backend.admin.photo.partials.activeData')->with(compact('photos'))->render();
            return response()->json(['success'=> $success,'data'=>$photos,'html'=>$html]);
        }
        else{
            Session::flash('message','प्रगति प्रतिबेदनको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
        
    }
}
