<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class ApiUserController extends Controller
{
    function login(Request $request)
    {   
        $user= User::where('email', $request->email)->first();
            if (!$user || !Hash::check($request->password, $user->password)) {
                return response([
                    'response' => 'These credentials do not match our records.'
                ], 404);
            }
        
            // create token for the logged in users that is used to access other apis
            $token = $user->createToken('my-app-token')->plainTextToken;
        
            $response = [
                'response' => $user,
                'token' => $token,
            ];
        
            return response($response, 201);
    }
}
