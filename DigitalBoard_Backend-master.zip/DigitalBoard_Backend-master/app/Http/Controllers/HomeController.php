<?php

namespace App\Http\Controllers;

use App\Models\CitizenCharter;
use App\Models\Department;
use App\Models\Employee;
use App\Models\Photo;
use App\Models\ScrollNotice;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    public function index()
    {
        $employees = '';
        $departments = '';
        $photo_count = 0;
        $scroll_notice_count = 0;
        $department_count = Department::count();
        if(Auth::user()->user_type == "Admin" || Auth::user()->user_type == "Superadmin")
        {
            $employees = Employee::orderBy('rank', 'DESC')->take(5)->get();

            $departments = Department::latest()->take(5)->get();

            $photo_count = Photo::count();
            $scroll_notice_count = ScrollNotice::count();
        }
        else{
            $department_id = Auth::user()->departmentUser->department_id;
            $office_id = Auth::user()->officeUser->office_id;
            $departments = Department::where('office_id', $office_id)->latest()->take(5)->get();
            $employees = Employee::where('department_id', $department_id)->orderBy('rank', 'DESC')->take(5)->get();

            $photo_count = Photo::where('office_id', $office_id)->count();
            $scroll_notice_count = ScrollNotice::where('office_id', $office_id)->count();
        }

        return view("dashboard", compact('employees', 'departments' ,'photo_count', 'scroll_notice_count', 'department_count'));
    }
}
