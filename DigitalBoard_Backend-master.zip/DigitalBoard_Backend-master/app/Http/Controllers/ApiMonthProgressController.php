<?php

namespace App\Http\Controllers;

use App\Http\Resources\DataNotFoundResource;
use Illuminate\Http\Request;
use App\Models\MonthlyProgress;
use App\Http\Resources\MonthlyProgressResource;
use App\Http\Resources\MonthlyProgressCollection;
use App\Models\OfficeUser;

class ApiMonthProgressController extends Controller
{
    public function index($id)
    {
        $office_user = OfficeUser::where('user_id', $id)->first();
        $monthly_progress = MonthlyProgress::where('office_id', $office_user['office_id'])->latest()->first();
        if($monthly_progress != null)
        {
            return MonthlyProgressResource::make($monthly_progress);
        }
        else
        {
            $response = [
                'message' => "Monthly Progress Data Not Found",
            ];
            return response($response, 404);
        }
    }
}
