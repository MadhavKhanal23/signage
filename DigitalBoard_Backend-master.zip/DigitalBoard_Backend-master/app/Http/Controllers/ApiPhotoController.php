<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Photo;
use App\Http\Resources\PhotoResource;
use App\Http\Resources\PhotoCollection;
use App\Models\OfficeUser;

class ApiPhotoController extends Controller
{
    public function index($id)
    {
        $office_user = OfficeUser::where('user_id', $id)->first();
        $photo = Photo::where([['publish',1],['office_id', $office_user['office_id']]])->latest()->get();
        return PhotoResource::collection($photo);
    }
}
