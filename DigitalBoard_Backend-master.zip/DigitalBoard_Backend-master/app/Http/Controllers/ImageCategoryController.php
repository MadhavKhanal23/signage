<?php

namespace App\Http\Controllers;

use Auth;
use App\Models\ImageCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class ImageCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(Auth::user()->user_type == "Superadmin" || Auth::user()->user_type == "Admin")
        {
            $image_categories = ImageCategory::latest()->get();
            return view('backend.admin.imageCategory.index',compact('image_categories'));
        }
        else{
            Session::flash('message','फोटो वर्गको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(Auth::user()->user_type == "Superadmin" || Auth::user()->user_type == "Admin")
        {
            return view('backend.admin.imageCategory.create');
        }
        else{
            Session::flash('message','नँया फोटो वर्गको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'imageCategory_name' => 'required|string'
        ]);

        $category = ImageCategory::create([
            'category' => $validated['imageCategory_name']
        ]);

        Session::flash('message','फोटो वर्गको डाटा सुरक्छित भयो !');
        return redirect()->route('image_category.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ImageCategory  $imageCategory
     * @return \Illuminate\Http\Response
     */
    public function show(ImageCategory $imageCategory)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ImageCategory  $imageCategory
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, $id)
    {
        if($request->ajax()){
            $imageCategory_id = $id;
            $imageCategory = ImageCategory::where('id', $imageCategory_id)->first();
            $message = "परिवर्तनको डाटा भर्नुहोस् ।।।";

            $html =  view('backend.admin.imageCategory.partials.edit')->with(compact('imageCategory'))->render();
            return response()->json(['success'=> "success",'message'=>$message,'data'=>$imageCategory,'html'=>$html]);
        }
        else{
            Session::flash('message','फोटो वर्गको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ImageCategory  $imageCategory
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'imageCategory_name' => 'required|string'
        ]);

        $categoryUpdate = ImageCategory::where('id', $id)->update([
            'category' => $validated['imageCategory_name']
        ]);

        Session::flash('message','फोटो वर्गको डाटा परिवर्तन भयो !');
        return redirect()->route('image_category.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ImageCategory  $imageCategory
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        if($request->ajax()){
            $category_delete = ImageCategory::where('id', $id)->delete();
            $image_categories = ImageCategory::latest()->get();
            $message = "फोटो वर्गको डाटा सफलता पुर्बक हटाएयो ।।।";

            $html =  view('backend.admin.imageCategory.partials.activeData')->with(compact('image_categories'))->render();
            return response()->json(['success'=> "success",'message'=>$message, 'html'=>$html]);
        }
        else{
            Session::flash('message','फोटो वर्गको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }
}
