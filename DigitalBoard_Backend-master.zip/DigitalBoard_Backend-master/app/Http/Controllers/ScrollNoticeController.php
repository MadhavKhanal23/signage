<?php

namespace App\Http\Controllers;

use App\Models\Office;
use App\Models\OfficeUser;
use App\Models\ScrollNotice;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Auth;

class ScrollNoticeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(Auth::user()->user_type == "Superadmin")
        {
            $scroll_notices = ScrollNotice:: all();
        }
        else if(Auth::user()->user_type == "Admin")
        {
            $office_id = Auth::user()->officeUser->office_id;
            $scroll_notices = ScrollNotice::where('office_id', $office_id)->latest()->get();

        }
        else{
            Session::flash('message','सूचना तथा समाचारको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }

        return view('backend.admin.scroll_notice.index',compact('scroll_notices'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(Auth:: user()->user_type == "Superadmin")
        {
            $office_data = Office::all();
        }
        elseif(Auth::user()->user_type == "Admin" )
        {
            $office_id = Auth::user()->officeUser->office_id;
            $office_data = Office::where('id', $office_id)->latest()->get();
        }
        else{
            Session::flash('message','सूचना तथा समाचारको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
        return view('backend.admin.scroll_notice.create',compact('office_data'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'notice_office'=> 'required',
            'notice_title' => 'required|string|max:255',
            'notice_description' => 'required|string',
            'notice_display_from' => 'required|date',
            'notice_display_to' => 'required|date'
        ]);

        $scroll_notice = ScrollNotice::create([
            'office_id' => $validated['notice_office'],
            'notice_title' => $validated['notice_title'],
            'notice_description' => $validated['notice_description'],
            'display_from' => $validated['notice_display_from'],
            'display_to' => $validated['notice_display_to'],
        ]);

        Session::flash('message','सूचना तथा समाचार सुरक्छित भयो ।।। ');
        return redirect()->route('scroll_notice.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ScrollNotice  $scrollNotice
     * @return \Illuminate\Http\Response
     */
    public function show(ScrollNotice $scrollNotice)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ScrollNotice  $scrollNotice
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {
        $scroll_notice = ScrollNotice::where('id', $id)->first();
        if($request->ajax()){
            if(Auth:: user()->user_type == "Superadmin")
            {
                $office_data = Office::all();
            }
            elseif(Auth::user()->user_type == "Admin" )
            {
                $office_id = Auth::user()->officeUser->office_id;
                $office_data = Office::where('id', $office_id)->latest()->get();
            }
        
            $html =  view('backend.admin.scroll_notice.partials.edit')->with(compact('scroll_notice','office_data'))->render();
            return response()->json(['success'=> "success",'data'=>$scroll_notice,'html'=>$html]);
        }
        else{
            Session::flash('message','सूचना तथा समाचारको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ScrollNotice  $scrollNotice
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        
        $notice_id = $id;
        
        $validated = $request->validate([
            'notice_office'=> 'required',
            'notice_title' => 'required|string|max:255',
            'notice_description' => 'required|string',
            'notice_display_from' => 'required|date',
            'notice_display_to' => 'required|date'
        ]);
        $scroll_notice_update = ScrollNotice::where('id',$notice_id)->update([
            'office_id' => $validated['notice_office'],
            'notice_title' => $validated['notice_title'],
            'notice_description' => $validated['notice_description'],
            'display_from' => $validated['notice_display_from'],
            'display_to' => $validated['notice_display_to']
        ]);

        Session::flash('message','सूचना तथा समाचार परिवर्तन भयो ।।।');
        return redirect()->route('scroll_notice.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ScrollNotice  $scrollNotice
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
        if($request->ajax()){
            $scroll_notice_id = ScrollNotice::where('id',$id)->delete();
            if(Auth::user()->user_type == "Superadmin")
            {
                $scroll_notices = ScrollNotice:: all();
            }
            else if(Auth::user()->user_type == "Admin")
            {
                $office_id = Auth::user()->officeUser->office_id;
                $scroll_notices = ScrollNotice::where('office_id', $office_id)->latest()->get();

            }
            $html =  view('backend.admin.scroll_notice.partials.active_data')->with(compact('scroll_notices'))->render();
            return response()->json(['success'=> "success",'html'=>$html]);
        }
        else{
            Session::flash('message','सूचना तथा समाचारको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }
    public function publish(Request $request)
    {
        $id = $request->notice_id;

        if($request->ajax()){
            $scroll_notice_publish = ScrollNotice::where('id', $id)->update([
                'publish' => $request->publish
            ]);
            if(Auth::user()->user_type == "Superadmin")
            {
                $scroll_notices = ScrollNotice:: all();
            }
            else if(Auth::user()->user_type == "Admin")
            {
                $office_id = Auth::user()->officeUser->office_id;
                $scroll_notices = ScrollNotice::where('office_id', $office_id)->latest()->get();

            }

            $success = "";
            if($request->publish =1)
            {
                $success = "सूचना तथा समाचार प्रकासित भयो ।।। ";
            }
            else{
                $success = "सूचना तथा समाचार अप्रकासित भयो ।।। ";
                
            }
            $html =  view('backend.admin.scroll_notice.partials.active_data')->with(compact('scroll_notices'))->render();
            return response()->json(['success'=> $success, 'data'=> $scroll_notices,'html'=>$html]);
        }
        else{
            Session::flash('message','सूचना तथा समाचारको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }
}
