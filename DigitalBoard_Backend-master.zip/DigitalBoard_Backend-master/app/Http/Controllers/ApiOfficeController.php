<?php

namespace App\Http\Controllers;

use App\Http\Resources\DataNotFoundResource;
use Illuminate\Http\Request;
use App\Models\Office;
use App\Http\Resources\OfficeResource;
use App\Http\Resources\OfficeCollection;
use App\Models\OfficeUser;
use Auth;

class ApiOfficeController extends Controller
{
    public function index($id)
    {
        $office_user = OfficeUser::where('user_id', $id)->first();
        $office = Office::where('id', $office_user->office_id)->first();
        if($office != null)
        {
            return OfficeResource::make($office);
        }
        else{

            $response = [
                'message' => "Office User Not Found",
            ];
            return response($response, 404);
        }
    }
   

}
