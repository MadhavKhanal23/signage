<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\YearlyProgress;
use App\Http\Resources\YearlyProgressResource;
use App\Http\Resources\YearlyProgressCollection;
use App\Models\OfficeUser;

class ApiYearlyProgressController extends Controller
{
    public function index($id)
    {
        $office_user = OfficeUser::where('user_id', $id)->first();
        $yearly_progress = YearlyProgress::where('office_id', $office_user['office_id'])->latest()->first();
        if($yearly_progress != null)
        {
            return YearlyProgressResource::make($yearly_progress);
        }
        else{
            $response = [
                'message' => "Yearly Progress Data Not Found",
            ];
            return response($response, 404);
        }
    }
}
