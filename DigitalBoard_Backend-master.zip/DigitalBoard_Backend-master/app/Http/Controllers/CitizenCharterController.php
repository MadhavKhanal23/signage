<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Session;
use App\Models\CitizenCharter;
use App\Models\Department;
use App\Models\Employee;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CitizenCharterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(Auth::user()->user_type == "Superadmin")
        {
            $citizen_charters = CitizenCharter::latest()->get();
        }
        else if(Auth::user()->user_type == "Admin")
        {
            $office_id = Auth::user()->officeUser->office_id;
            $departments = Department::where('office_id', $office_id)->get();
            $department_id = [];
            foreach($departments as $department)
            {
                array_push($department_id, $department['id']);
            }
            $citizen_charters = CitizenCharter::whereIn('department_id', $department_id)->get();
        }
        else
        {
            $department_id = Auth::user()->departmentUser->department_id;
            $citizen_charters = CitizenCharter::where('department_id', $department_id)->latest()->get();
        }
        return view('backend.admin.citizen_charter.index',compact('citizen_charters'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(Auth::user()->user_type == "Superadmin")
        {
            $department_data = Department::get();
            $employee_data = Employee::latest()->get();
        }
        else if(Auth::user()->user_type == "Admin")
        {
            $office_id = Auth::user()->officeUser->office_id;
            $department_data = Department::where('office_id', $office_id)->get();
            $department_id = [];
            foreach($department_data as $department)
            {
                array_push($department_id, $department['id']);
            }
            $employee_data = Employee::whereIn('department_id', $department_id)->latest()->get();
            
        }
        else{
            $department_id = Auth::user()->departmentUser->department_id;
            $department_data = Department::where('id', $department_id)->get();
            $employee_data = Employee::where('department_id', $department_id)->latest()->get();
        }
        return view('backend.admin.citizen_charter.partials.create',compact('department_data','employee_data'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'citizen_charter_title' =>'required|string',
            'service_type'=>'required|string|min:3|max:255',
            'service_time' => 'required|string|min:3|max:255',
            'service_charge'=>'required|string',
            'important_document' => 'required|string',
            'citizen_charter_employee' => 'required',
            'citizen_charter_department'=>'required'
        ]);
       
            $office_id = $request->office_id;  
        $citizen_charter = CitizenCharter::create([
            'citizen_charter_title' =>$validated['citizen_charter_title'],
            'service_type' => $validated['service_type'],
            'service_time' =>$validated['service_time'],
            'service_charge' =>$validated['service_charge'],
            'employee_id'=>$validated['citizen_charter_employee'], 
            'department_id'=>$validated['citizen_charter_department'], 
            'important_document' => $validated['important_document']
        ]);
        Session::flash('message','नागरिक वडापत्रको डाटा सुरक्छित भयो।।। ');
        return redirect()->route('citizen_charter.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\CitizenCharter  $citizenCharter
     * @return \Illuminate\Http\Response
     */
    public function show(CitizenCharter $citizenCharter)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\CitizenCharter  $citizenCharter
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, $id)
    {
        $citizen_charter =CitizenCharter::where('id', $id)->first();
        if($request->ajax()){
            if(Auth::user()->user_type == "Superadmin")
            {
                $department_data = Department::all();
                $employee_data = Employee::latest()->get();
            }
            else if(Auth::user()->user_type == "Admin")
            {
                $office_id = Auth::user()->officeUser->office_id;
                $department_data = Department::where('office_id', $office_id)->get();
                $department_id = [];
                foreach($department_data as $department)
                {
                    array_push($department_id, $department['id']);
                }
                $employee_data = Employee::whereIn('department_id', $department_id)->latest()->get();
                
            }
            else{
                $department_id = Auth::user()->departmentUser->department_id;
                $department_data = Department::where('id', $department_id)->get();
                $employee_data = Employee::where('department_id', $department_id)->latest()->get();
            }
            $html =  view('backend.admin.citizen_charter.partials.edit')->with(compact('citizen_charter','department_data','employee_data'))->render();
            return response()->json(['success'=> "success",'data'=>$citizen_charter,'html'=>$html]);
        }
        else{
            Session::flash('message','नागरिक वडापत्रको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\CitizenCharter  $citizenCharter
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        $citizen_charter_id = $id;
        $validated = $request->validate([
            'citizen_charter_title' =>'required|string',
            'service_type'=>'required|string|min:3|max:255',
            'service_time'=>'required|string',
            'service_charge'=>'required|string',
            'important_document' => 'required|string',
            'citizen_charter_department' => 'required',
            'citizen_charter_employee' => 'required'

        ]);
        
        $citizen_update = CitizenCharter::where('id', $citizen_charter_id)->update([
            'citizen_charter_title' =>$validated['citizen_charter_title'],
            'service_type' => $validated['service_type'],
            'service_time' =>$validated['service_time'],
            'service_charge' =>$validated['service_charge'],
            'important_document' => $validated['important_document'],
            'employee_id' => $validated['citizen_charter_employee'],
            'department_id'=>$validated['citizen_charter_department'], 

        ]);
        Session::flash('message','नागरिक वडापत्रको डाटा परिवर्तन भयो।।। ');
        return redirect()->route('citizen_charter.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\CitizenCharter  $citizenCharter
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
        $citizen_charter_id = $id;
        if($request->ajax()){
            $citizen_charter_delete = CitizenCharter::where('id',$citizen_charter_id)->delete();
        
            if(Auth::user()->user_type == "Superadmin")
            {
                $citizen_charters = CitizenCharter::latest()->get();
            }
            else if(Auth::user()->user_type == "Admin")
            {
                $office_id = Auth::user()->officeUser->office_id;
                $departments = Department::where('office_id', $office_id)->get();
                $department_id = [];
                foreach($departments as $department)
                {
                    array_push($department_id, $department['id']);
                }
                $citizen_charters = CitizenCharter::whereIn('department_id', $department_id)->get();
            }
            else
            {
                $department_id = Auth::user()->departmentUser->department_id;
                $citizen_charters = CitizenCharter::where('department_id', $department_id)->latest()->get();
            }
            $html =  view('backend.admin.citizen_charter.partials.active_data')->with(compact('citizen_charters'))->render();
            return response()->json(['success'=> "success", 'html'=>$html]);
        }
        else{
            Session::flash('message','नागरिक वडापत्रको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }

    }

    public function PublishCitizen(Request $request)
    {
         
        $id = $request->citizen_charter_id;
        if($request->ajax()){
            $citizen_charter_publish = CitizenCharter::where('id',$id)->update([
                'publish'=> $request->publish,
            ]);

            if(Auth::user()->user_type == "Superadmin")
            {
                $citizen_charters = CitizenCharter::latest()->get();
            }
            else if(Auth::user()->user_type == "Admin")
            {
                $office_id = Auth::user()->officeUser->office_id;
                $departments = Department::where('office_id', $office_id)->get();
                $department_id = [];
                foreach($departments as $department)
                {
                    array_push($department_id, $department['id']);
                }
                $citizen_charters = CitizenCharter::whereIn('department_id', $department_id)->get();
            }
            else
            {
                $department_id = Auth::user()->departmentUser->department_id;
                $citizen_charters = CitizenCharter::where('department_id', $department_id)->latest()->get();
            }

            $success = '';
            if($request->publish == 1)
            {
                $success = "नागरिक वडापत्र प्रकासित भयो।।।";
            }
            else
            {
                $success = "नागरिक वडापत्र अप्रकासित भयो।।।";
            }
            $html =  view('backend.admin.citizen_charter.partials.active_data')->with(compact('citizen_charters'))->render();
            return response()->json(['success'=>  $success, 'data'=>$citizen_charters, 'html'=>$html]);
        }
        else{
            Session::flash('message','नागरिक वडापत्रको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }

}

