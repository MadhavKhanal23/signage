<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CitizenCharter;
use App\Http\Resources\CitizenCharterResource;
use App\Http\Resources\CitizenCharterCollection;
use App\Models\Department;
use App\Models\OfficeUser;

class ApiCitizenCharterController extends Controller
{
    public function index($id)
    {
        $office_user = OfficeUser::where('user_id', $id)->first();
        $departments = Department::where('office_id', $office_user->office_id)->get();
        $department_id = [];
        foreach( $departments as $depart)
        {
            array_push($department_id, $depart['id']);
        }
        $citizen_charter = CitizenCharter::where('publish',1)->whereIn('department_id',$department_id)->latest()->get();
        return CitizenCharterResource::collection($citizen_charter);
    }
}
