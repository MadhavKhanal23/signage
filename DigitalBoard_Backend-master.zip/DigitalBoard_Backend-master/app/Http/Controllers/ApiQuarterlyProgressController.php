<?php

namespace App\Http\Controllers;

use App\Http\Resources\DataNotFoundResource;
use Illuminate\Http\Request;
use App\Models\QuarterlyProgress;
use App\Http\Resources\QuarterlyProgressResource;
use App\Http\Resources\QuarterlyProgressCollection;
use App\Models\OfficeUser;

class ApiQuarterlyProgressController extends Controller
{
    public function index($id)
    {
        $office_user = OfficeUser::where('user_id', $id)->first();
        $quarter_progress = QuarterlyProgress::where('office_id', $office_user['office_id'])->latest()->first();
        if($quarter_progress != null)
        {
            return QuarterlyProgressResource::make($quarter_progress);
        }
        else{
            $response = [
                'message' => "Querterly Progress Data Not Found",
            ];
            return response($response, 404);
        }
    }
}
