<?php

namespace App\Http\Controllers;

use Auth;
use Redirect;
use App\Models\Department;
use App\Models\DepartmentUser;
use App\Models\MahaasakhaSakha;
use App\Models\Office;
use App\Models\OfficeUser;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DepartmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(Auth::user()->user_type == "Superadmin")
        {
            $departments = Department::with('mahaaSakha')->get();
        }
        else if(Auth::user()->user_type == "Admin")
        {
            $office_id = Auth::user()->officeUser->office_id;
            $departments = Department::where('office_id', $office_id)->with('mahaaSakha')->latest()->get();
        }
        else{
            Session::flash('message','कार्यालय शाखाको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
        return view('backend.admin.department.index', compact('departments'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(Auth:: user()->user_type == "Superadmin")
        {
            $type = "महाशाखा";
            $offices = Office::all();
            $departments = Department::where('type', $type)->get();
        }
        elseif(Auth::user()->user_type == "Admin" )
        {
            $office_id = Auth::user()->officeUser->office_id;
            $offices = Office::where('id', $office_id)->latest()->get();
            $departments = Department::where([['type','महाशाखा'],['office_id',$office_id]])->get();
        }
        else{
            Session::flash('message','कार्यालय शाखाको लागि अनुमति छैन ।।।');
            return redirect()->back();
        }
        return view('backend.admin.department.create',compact('offices','departments'));
       
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'department_office' => 'required|integer',
            'department_name' => 'required|string|max:50',
            'department_floor' => 'required|string',
            'department_room' => 'required|string',
            'department_services' => 'required|string',
            'email'=> 'required|email',
            'landline_number'=>'required|min:9|max:10',
            'department_type' => 'required|in:सचिवालय,महाशाखा,शाखा',
            'mahaaSakha_id' => 'sometimes|integer'
        ]);
        
        DB::transaction(function()use($request,$validated){
            $department = Department::create([
                'office_id' => $validated['department_office'],
                'department_name' => $validated['department_name'],
                'type' => $validated['department_type'],
                'floor_no' => $validated['department_floor'],
                'room_no' => $validated['department_room'],
                'department_services' => $validated['department_services'],
                'email'=>$validated['email'],
                'landline_number'=>$validated['landline_number']
            ]);
            if($request->mahaaSakha_id != null)
            {
                $mahaasakhaSakha = MahaasakhaSakha::create([
                    'mahasakha_id' => $validated['mahaaSakha_id'],
                    'sakha_id' => $department['id']
                ]);
            }
        });

        Session::flash('message','कार्यालय संरचना सुरक्छित भयो ।');
        return redirect()->route('department.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Department  $department
     * @return \Illuminate\Http\Response
     */
    public function show(Department $department)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Department  $department
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, $id)
    {
        $department_id = $id;
        if($request->ajax()){
            $department = Department::where('id', $department_id)->with('mahaaSakha')->first();
            if(Auth:: user()->user_type == "Superadmin")
            {
                $type = "महाशाखा";
                $offices = Office::all();
                $mahaSakha = Department::where('type', $type)->get();
            }
            elseif(Auth::user()->user_type == "Admin" )
            {
                $office_id = Auth::user()->officeUser->office_id;
                $offices = Office::where('id', $office_id)->latest()->get();
                $mahaSakha = Department::where([['type','महाशाखा'],['office_id',$office_id]])->get();
            }
        
            $html =  view('backend.admin.department.partials.edit')->with(compact('department','offices','mahaSakha'))->render();
            return response()->json(['success'=> "success",'data'=>$department,'html'=>$html]);
        }
        else{
            Session::flash('message','कार्यालय शाखाको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Department  $department
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'department_office' => 'required|integer',
            'department_name' => 'required|string|max:50',
            'department_floor' => 'required|string',
            'department_room' => 'required|string',
            'department_services' => 'required|string',
            'email' => 'required|email',
            'landline_number' => 'required|min:9|max:10',
            'department_type' => 'required|in:सचिवालय,महाशाखा,शाखा',
            'mahaaSakha_id' => 'nullable|integer'
        ]);

        DB::transaction(function()use($request,$validated,$id){
            $department = Department::where('id', $id)->update([
                'office_id' => $validated['department_office'],
                'department_name' => $validated['department_name'],
                'type' => $validated['department_type'],
                'floor_no' => $validated['department_floor'],
                'room_no' => $validated['department_room'],
                'department_services' => $validated['department_services'],
                'email' => $validated['email'],
                'landline_number' => $validated['landline_number'],
            ]);
            
            MahaasakhaSakha::where('sakha_id', $id)->delete();

            if($request->mahaaSakha_id != null)
            {
                $mahaasakhaSakha = MahaasakhaSakha::create([
                    'mahasakha_id' => $validated['mahaaSakha_id'],
                    'sakha_id' => $id
                ]);
            }

        });

        Session::flash('message','कार्यालय संरचना परिवर्तन भयो ।');
        return redirect()->route('department.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Department  $department
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        if($request->ajax()){
            $department_data = Department::where('id', $id)->first();
            $sakha_id = [];
            if($department_data['type'] == 'महाशाखा')
            {
                $sakhas = MahaasakhaSakha::where('mahasakha_id', $id)->get();
                foreach($sakhas as $sakha)
                {
                    array_push($sakha_id, $sakha['sakha_id']);
                }
                MahaasakhaSakha::where('mahasakha_id', $id)->delete();
                $sakha_delete = Department::whereIn('id', $sakha_id)->delete();
            }
            $department_delete = Department::where('id', $id)->delete();
            if(Auth::user()->user_type == "Superadmin")
            {
                $departments = Department::get();
            }
            else if( Auth::user()->user_type == "Admin")
            {
                $office_id = Auth::user()->officeUser->office_id;
                $departments = Department::where('office_id', $office_id)->latest()->get();
            }
            
            $html =  view('backend.admin.department.partials.activeData', compact('departments'))->render();
            return response()->json(['success'=> "success", 'html'=>$html]);
        }
        else
        {
            Session::flash('message','कार्यालय शाखाको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }
}
