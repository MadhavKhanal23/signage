<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\Department;
use App\Models\DepartmentUser;
use App\Models\Office;
use App\Models\OfficeUser;
use App\Models\User;
use Illuminate\Support\Facades\Session;
use App\Providers\RouteServiceProvider;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class RegisteredUserController extends Controller
{
    /**
     * Display the registration view.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        if(Auth:: user()->user_type == "Superadmin")
        {
            $offices = Office::get();
            $departments = Department::get();
            return view('auth.register', compact('offices', 'departments'));
        }
        else if(Auth::user()->user_type == "Admin")
        {
            $office_id = Auth::user()->officeUser->office_id;
            $offices = Office::where('id', $office_id)->get();
            $departments = Department::where('office_id', $office_id)->latest()->get();
            return view('auth.register', compact('offices', 'departments'));
        }
        else
        {
            Session::flash('message','प्रयोगकर्ताको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }

    /**
     * Handle an incoming registration request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request)
    {
        
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'mobile_number' => 'required',
            'user_type' => 'required|in:Admin,User',
            'user_address' => 'required|string|min:10|max:255',
            'password' => 'required|string|confirmed|min:8',
            'userOffice' => 'required|integer',
            'userDepartment' => 'sometimes|integer'
        ]);
    
        $user = "";
        DB::transaction(function()use($request,$validated){
            $user = User::create([
                'name' => $request->name,
                'email' => $request->email,
                'mobile_number' => $request->mobile_number,
                'address' => $request->user_address,
                'user_type' => $request->user_type,
                'password' => Hash::make($request->password),
            ]);
            if($request->user_type == "Admin")
            {
                $userOffice = OfficeUser::create([
                    'office_id' => $request->userOffice,
                    'user_id' => $user['id']
                ]);
            }
            else if($request->user_type == "User")
            {
                $userOffice = OfficeUser::create([
                    'office_id' => $request->userOffice,
                    'user_id' => $user['id']
                ]);

                $userDepartment = DepartmentUser::create([
                    'department_id' => $request->userDepartment,
                    'user_id' => $user['id']
                ]);
            }
        });

        event(new Registered($user));

        Session::flash('message','प्रयोगकर्ताको डाटा सुरक्छित भयो ।।।');
        return redirect()->route('user.index');
    }
}
