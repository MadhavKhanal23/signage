<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ScrollNotice;
use App\Http\Resources\ScrollNoticeResource;
use App\Http\Resources\ScrollNoticeCollection;
use App\Models\OfficeUser;

class ApiScrollNoticeController extends Controller
{
    public function index($id)
    {
        $office_user = OfficeUser::where('user_id', $id)->first();
        $scroll_notice = ScrollNotice::where([['publish',1],['office_id', $office_user['office_id']]])->latest()->get();
        
        return ScrollNoticeResource::collection($scroll_notice);
    }
}
