<?php

namespace App\Http\Controllers;

use App\Models\Budget;
use App\Models\CitizenCharter;
use App\Models\Department;
use App\Models\Employee;
use App\Models\Month;
use App\Models\MonthlyProgress;
use App\Models\Office;
use App\Models\OfficeUser;
use App\Models\Photo;
use App\Models\ScrollNotice;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Auth;

class MonthlyProgressController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(Auth::user()->user_type == "Superadmin")
        {
            $monthly_progress = MonthlyProgress::latest()->with('office', 'budget')->get();
        }
        else if(Auth::user()->user_type == "Admin")
        {
            $office_id = Auth::user()->officeUser->office_id;
            $monthly_progress = MonthlyProgress::where('office_id', $office_id)->latest()->with('office', 'budget')->get();
        }
        else{
            Session::flash('message','प्रगति प्रतिबेदनको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
        return view('backend.admin.progress.monthlyProgress.index', compact('monthly_progress'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $months = Month::get();
        if(Auth:: user()->user_type == "Superadmin")
        {
            $office_data = Office::all();
        }
        elseif(Auth::user()->user_type == "Admin" )
        {
            $office_id = Auth::user()->officeUser->office_id;
            $office_data = Office::where('id', $office_id)->latest()->get();
        }
        else{
            Session::flash('message','प्रगति प्रतिबेदनको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
        return view('backend.admin.progress.monthlyProgress.create', compact('months','office_data'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'monthlyProgress_office' => 'required|integer',
            'monthlyProgress_month' => 'required|integer',
            'month_current_budget' => 'required|numeric',
            'month_spend_budget' => 'required|numeric|lte:month_current_budget',
            'month_capital_budget' => 'required|numeric',
            'month_capital_spend_budget' => 'required|numeric|lte:month_capital_budget'
        ]);

        DB::transaction(function()use($request,$validated){
            $budget = Budget::create([
                'current_total_budget' => $validated['month_current_budget'],
                'current_spend_budget' => $validated['month_spend_budget'],
                'capital_total_budget' => $validated['month_capital_budget'],
                'capital_spend_budget' => $validated['month_capital_spend_budget']
            ]);

            $monthlyProgress = MonthlyProgress::create([
                'office_id' => $validated['monthlyProgress_office'],
                'month_id' => $validated['monthlyProgress_month'],
                'budget_id' => $budget['id']
            ]); 
        });

        Session::flash('message',' मासिक प्रगति प्रतिबेदन सुरक्छित भयो ।।।');
        return redirect()->route('monthly_progress.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\MonthlyProgress  $monthlyProgress
     * @return \Illuminate\Http\Response
     */
    public function show(MonthlyProgress $monthlyProgress)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\MonthlyProgress  $monthlyProgress
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, $id)
    {
        $monthly_progress_id = $id;
        if($request->ajax()){
            $monthlyProgress = MonthlyProgress::where('id', $monthly_progress_id)->first();
            $months = Month::get();
            if(Auth:: user()->user_type == "Superadmin")
            {
                $office_data = Office::all();
            }
            elseif(Auth::user()->user_type == "Admin" )
            {
                $office_id = Auth::user()->officeUser->office_id;
                $office_data = Office::where('id', $office_id)->latest()->get();
            }
        
            $html =  view('backend.admin.progress.monthlyProgress.partials.edit')->with(compact('monthlyProgress','office_data','months'))->render();
            return response()->json(['success'=> "success",'data'=>$monthlyProgress,'html'=>$html]);
        }
        else{
            Session::flash('message','प्रगति प्रतिबेदनको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\MonthlyProgress  $monthlyProgress
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $monthly_progress = MonthlyProgress::where('id', $id)->first();
        $budget_id = $monthly_progress['budget_id'];
        $validated = $request->validate([
            'monthlyProgress_office' => 'required|integer',
            'monthlyProgress_month' => 'required|integer',
            'month_current_budget' => 'required|numeric',
            'month_spend_budget' => 'required|numeric|lte:month_current_budget',
            'month_capital_budget' => 'required|numeric',
            'month_capital_spend_budget' => 'required|numeric|lte:month_capital_budget'
        ]);
        
        DB::transaction(function()use($request, $validated, $id, $budget_id){
            $budget = Budget::where('id', $budget_id)->update([
                'current_total_budget' => $validated['month_current_budget'],
                'current_spend_budget' => $validated['month_spend_budget'],
                'capital_total_budget' => $validated['month_capital_budget'],
                'capital_spend_budget' => $validated['month_capital_spend_budget']
            ]);

            $monthlyProgress = MonthlyProgress::where('id', $id)->update([
                'office_id' => $validated['monthlyProgress_office'],
                'month_id' => $validated['monthlyProgress_month'],
                'budget_id' => $budget_id
            ]); 
        });

        Session::flash('message',' मासिक प्रगति प्रतिबेदन परिवर्तन भयो ।।।');
        return redirect()->route('monthly_progress.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\MonthlyProgress  $monthlyProgress
     * @return \Illuminate\Http\Response
     */
    public function destroy(MonthlyProgress $monthlyProgress)
    {
        //
    }
}
