<?php

namespace App\Http\Controllers;

use App\Models\Budget;
use App\Models\FiscalYear;
use App\Models\Office;
use App\Models\OfficeUser;
use App\Models\YearlyProgress;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Auth;

class YearlyProgressController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(Auth::user()->user_type == "Superadmin")
        {
            $yearly_progress = YearlyProgress::latest()->with('office', 'budget')->get();
        }
        else if(Auth::user()->user_type == "Admin")
        {
            $office_id = Auth::user()->officeUser->office_id;
            $yearly_progress = YearlyProgress::where('office_id', $office_id)->latest()->with('office', 'budget')->get();
        }
        else{
            Session::flash('message','प्रगति प्रतिबेदनको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
        return view('backend.admin.progress.yearlyProgress.index', compact('yearly_progress'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $years = FiscalYear::get();
        if(Auth:: user()->user_type == "Superadmin")
        {
            $office_data = Office::all();
        }
        elseif(Auth::user()->user_type == "Admin" )
        {
            $office_id = Auth::user()->officeUser->office_id;
            $office_data = Office::where('id', $office_id)->latest()->get();
        }
        else{
            Session::flash('message','प्रगति प्रतिबेदनको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
        return view('backend.admin.progress.yearlyProgress.create', compact('years','office_data'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'yearlyProgress_office' => 'required|integer',
            'yearlyProgress_year' => 'required|integer',
            'year_current_budget' => 'required|numeric',
            'year_spend_budget' => 'required|numeric|lte:year_current_budget',
            'year_capital_budget' => 'required|numeric',
            'year_capital_spend_budget' => 'required|numeric|lte:year_capital_budget'
        ]);

        DB::transaction(function()use($request,$validated){
            $budget = Budget::create([
                'current_total_budget' => $validated['year_current_budget'],
                'current_spend_budget' => $validated['year_spend_budget'],
                'capital_total_budget' => $validated['year_capital_budget'],
                'capital_spend_budget' => $validated['year_capital_spend_budget']
            ]);

            $yearlyProgress = yearlyProgress::create([
                'office_id' => $validated['yearlyProgress_office'],
                'fiscal_year_id' => $validated['yearlyProgress_year'],
                'budget_id' => $budget['id']
            ]); 
        });

        Session::flash('message',' बार्षिक प्रगति प्रतिबेदन सुरक्छित भयो ।।।');
        return redirect()->route('yearly_progress.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\YearlyProgress  $yearlyProgress
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\YearlyProgress  $yearlyProgress
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, $id)
    {
        $yearly_progress_id = $id;
        if($request->ajax()){
            $yearlyProgress = YearlyProgress::where('id', $yearly_progress_id)->first();
            $years = FiscalYear::get();
            if(Auth:: user()->user_type == "Superadmin")
            {
                $office_data = Office::all();
            }
            elseif(Auth::user()->user_type == "Admin" )
            {
                $user_id = Auth::user()->id;
                $office = OfficeUser::where('user_id', $user_id)->first();
                $office_data = Office::where('id', $office['office_id'])->latest()->get();
            }

            $html =  view('backend.admin.progress.yearlyProgress.partials.edit')->with(compact('yearlyProgress','office_data','years'))->render();
            return response()->json(['success'=> "success",'data'=>$yearlyProgress,'html'=>$html]);
        }
        else
        {
            Session::flash('message','प्रगति प्रतिबेदनको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\YearlyProgress  $yearlyProgress
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $yearly_progress = YearlyProgress::where('id', $id)->first();
        $budget_id = $yearly_progress['budget_id'];
        $validated = $request->validate([
            'yearlyProgress_office' => 'required|integer',
            'yearlyProgress_year' => 'required|integer',
            'year_current_budget' => 'required|numeric',
            'year_spend_budget' => 'required|numeric|lte:year_current_budget',
            'year_capital_budget' => 'required|numeric',
            'year_capital_spend_budget' => 'required|numeric|lte:year_capital_budget'
        ]);
        
        DB::transaction(function()use($request, $validated, $id, $budget_id){
            $budget = Budget::where('id', $budget_id)->update([
                'current_total_budget' => $validated['year_current_budget'],
                'current_spend_budget' => $validated['year_spend_budget'],
                'capital_total_budget' => $validated['year_capital_budget'],
                'capital_spend_budget' => $validated['year_capital_spend_budget']
            ]);


            $yearlyProgress = YearlyProgress::where('id', $id)->update([
                'office_id' => $validated['yearlyProgress_office'],
                'fiscal_year_id' => $validated['yearlyProgress_year'],
                'budget_id' => $budget_id
            ]); 
        });

        Session::flash('message','बार्षिक प्रगति प्रतिबेदन परिवर्तन भयो ।।।');
        return redirect()->route('yearly_progress.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\YearlyProgress  $yearlyProgress
     * @return \Illuminate\Http\Response
     */
    public function destroy(YearlyProgress $yearlyProgress)
    {
        //
    }
}
