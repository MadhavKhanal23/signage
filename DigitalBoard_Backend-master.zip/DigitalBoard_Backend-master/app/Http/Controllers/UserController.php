<?php

namespace App\Http\Controllers;

use App\Models\Department;
use App\Models\DepartmentUser;
use App\Models\Office;
use App\Models\OfficeUser;
use Illuminate\Http\Request;
use App\Models\User;
use Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class UserController extends Controller
{
    public function index()
    {
        if(Auth:: user()->user_type == "Superadmin")
        {
            $users = User::get();
            return view('backend.admin.user.index',compact('users'));
        }
        else if(Auth::user()->user_type == "Admin")
        {
            $office_id = Auth::user()->officeUser->office_id;
            $users_data = OfficeUser::where('office_id', $office_id)->get('user_id');
            $user_id_array = [];
            foreach($users_data as $user)
            {
                array_push($user_id_array, $user['user_id']);
            }
            $users = User::whereIn('id', $user_id_array)->get();
            return view('backend.admin.user.index',compact('users'));
        }
        else
        {
            Session::flash('message','प्रयोगकर्ताको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }

    public function edit(Request $request)
    {  
        if($request->ajax()){
            $user_id = $request->user_id;
            if(Auth:: user()->id !=  $user_id){
                $offices = Office::All();
                $departments = Department::all();
                $user = User::where('id', $user_id)->first();
                $message = "परिवर्तनको डाटा भर्नुहोस् ।।।";
                
                    $html =  view('backend.admin.user.partials.edit')->with(compact('user', 'offices','departments'))->render();
                    return response()->json(['success'=> "success",'message'=>$message,'data'=>$user,'html'=>$html]);
            }
            else
            {
                $office = OfficeUser::where('user_id', $user_id)->first();
                $users_data = OfficeUser::where('office_id', $office['office_id'])->get('user_id');
                $user_id_array = [];
                foreach($users_data as $user)
                {
                    array_push($user_id_array, $user['user_id']);
                }
                $users = User::whereIn('id', $user_id_array)->get();
                $message = "लग इन प्रयोगकर्ताको डाटा परिवर्तन लागि अनुमति छैन ।।।";
                $html =  view('backend.admin.user.partials.indexContent')->with(compact('users'))->render();
                return response()->json(['success'=> "success",'data'=>$users, 'message'=>$message, 'html'=>$html]);
            }
        }
        else{
            Session::flash('message','प्रयोगकर्ताको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }

    public function update(Request $request)
    {
        if(Auth:: user()->user_type == "Superadmin" || Auth::user()->user_type == "Admin")
        {
            $user_id = $request->user_id;

            $validated = $request->validate([
                'name' => 'required|string|max:255',
                'email' => 'required|string|email|max:255',
                'mobile_number' => 'required',
                'user_address' => 'required|string|min:10|max:255',
                'userOffice' => 'required|int',
                'user_type' => 'required|in:Admin,User',
                'userDepartment' => 'nullable|integer',
                'newPassword' => 'nullable|string'
            ]);

            DB::transaction(function()use($request,$validated,$user_id){
                $user_update = User::where('id', $user_id)->update([
                    'name' => $validated['name'],
                    'user_type' => $validated['user_type'],
                    'email' => $validated['email'], 
                    'mobile_number' => $validated['mobile_number'], 
                    'address' => $validated['user_address'],
                ]);

                if($validated['newPassword'] != null || $validated['newPassword'] != null)
                {
                    User::where('id', $user_id)->update([
                        'password' => Hash::make($validated['newPassword'])
                    ]);
                }

                OfficeUser::where('user_id', $user_id)->forcedelete();
                DepartmentUser::where('user_id', $user_id)->forcedelete();
                if($request->user_type == "Admin")
                {
                    $userOffice = OfficeUser::create([
                        'office_id' => $request->userOffice,
                        'user_id' =>  $user_id
                    ]);

                    $userDepartment = DepartmentUser::where('user_id', $user_id)->first();
                    if($userDepartment != null)
                    {
                        DepartmentUser::where('user_id', $user_id)->forcedelete();
                    }
                }
                else if($request->user_type == "User")
                {
                    $userOffice = OfficeUser::create([
                        'office_id' => $request->userOffice,
                        'user_id' =>  $user_id
                    ]);
                    
                    $userDepartment = DepartmentUser::where('user_id', $user_id)->first();
                    if($userDepartment != null)
                    {
                        $userDepartment = DepartmentUser::where('user_id', $user_id)->update([
                            'department_id' => $request->userDepartment
                        ]);
                    }
                    else{
                        $userDepartment = DepartmentUser::create([
                            'department_id' => $request->userDepartment,
                            'user_id' => $user_id
                        ]);
                    }
                }
            });

            Session::flash('message','प्रयोगकर्ताको डाटा परिवर्तन भयो !');
            return redirect()->route('user.index');
        }
    }

    public function delete(Request $request)
    {
        $user_id = $request->user_id;
        if($request->ajax()){
            $system_user_id = $this->getCurrentSystemUserId();
            if($user_id != $system_user_id){
                $user_delete = User::where('id', $user_id)->forcedelete();
                $message = "प्रयोगकर्ताको डाटा सफलता पुर्बक हटाएयो ।।।";
                if(Auth:: user()->user_type == "Superadmin")
                {
                    $users = User::get();
                }
                else if(Auth::user()->user_type == "Admin")
                {
                    $office_id = Auth::user()->officeUser->office_id;
                    $users_data = OfficeUser::where('office_id', $office_id)->get('user_id');
                    $user_id_array = [];
                    foreach($users_data as $user)
                    {
                        array_push($user_id_array, $user['user_id']);
                    }
                    $users = User::whereIn('id', $user_id_array)->get();
                }

                $html =  view('backend.admin.user.partials.active_data')->with(compact('users'))->render();
                return response()->json(['success'=> "User Deleted Successfully..!!",'message'=>$message,'data'=>$users,'html'=>$html]);
            }
            else{
                if(Auth:: user()->user_type == "Superadmin")
                {
                    $users = User::get();
                    return view('backend.admin.user.index',compact('users'));
                }
                else if(Auth::user()->user_type == "Admin")
                {
                    $office_id = Auth::user()->officeUser->office_id;
                    $users_data = OfficeUser::where('office_id', $office_id)->get('user_id');
                    $user_id_array = [];
                    foreach($users_data as $user)
                    {
                        array_push($user_id_array, $user['user_id']);
                    }
                    $users = User::whereIn('id', $user_id_array)->get();
                    return view('backend.admin.user.index',compact('users'));
                }
                $message = "लग इन प्रयोगकर्ता ।।।";
                
                $html =  view('backend.admin.user.partials.active_data')->with(compact('users'))->render();
                return response()->json(['success'=> "Auth User Cannot be deleted..!!",'message'=>$message, 'data'=>$users,'html'=>$html]);
            }
        }
        else{
            Session::flash('message','प्रयोगकर्ताको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }

    public function department(Request $request)
    {
        $id = $request->office_id;
        $departments = Department::select('department_name','id')->where('office_id',$id)->get();

        return response()->json($departments);
    }

}
