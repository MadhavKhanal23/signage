<?php

namespace App\Http\Controllers;
use App\Models\Department;
use App\Models\Employee;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;

class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(Auth::user()->user_type == "Superadmin")
        {
            $employees = Employee::orderBy('rank', 'DESC')->get();
        }
        elseif(Auth::user()->user_type == "Admin")
        {
            $office_id = Auth::user()->officeUser->office_id;
            $departments = Department::where('office_id', $office_id)->latest()->get();
            $department_id = [];
            foreach($departments as $department)
            {
                array_push($department_id, $department['id']);
            }
            $employees = Employee::whereIn('department_id', $department_id)->orderBy('rank', 'DESC')->get();
        }
        else{
            $department_id = Auth::user()->departmentUser->department_id;
            $employees = Employee::where('department_id', $department_id)->orderBy('rank', 'DESC')->get();
        }
        return view('backend.admin.employee.index',compact('employees'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(Auth::user()->user_type == "Superadmin")
        {
            $departments = Department::all();
        }
        else if(Auth::user()->user_type == "Admin")
        {
            $office_id = Auth::user()->officeUser->office_id;
            $departments = Department::where('office_id', $office_id)->get();
            
        }
        else{
            $department_id = Auth::user()->departmentUser->department_id;
            $departments = Department::where('id', $department_id)->get();
        }
        return view('backend.admin.employee.create', compact('departments'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
            $validated = $request->validate([
                'employee_office' => 'required|integer',
                'employee_name' => 'required|string|max:50',
                'employee_designation' => 'required|string|max:50',
                'employee_mobile' => 'nullable',
                'employee_landline' => 'required|min:09|max:10',
                'employee_room' => 'required|string',
                'employee_email' => 'nullable|string',
                'employee_rank' => 'required|integer',
                'is_dept_head'=>'nullable',
                'employee_status' =>'required',
                'employee_image'=>'required'
            ]);

            $fileName =Null;
            if($request->hasFile('employee_image'))
            {
                
                $fileName=time().$request->employee_image->getClientOriginalName();
                $filePath = $request->file('employee_image')->storeAs('public/uploads/employee_image', $fileName);
            }
            else
            {
                $fileName = $validated['employee_image'];
            }

            $employee = Employee::create([
                'department_Id' =>$validated['employee_office'],
                'employee_name' =>$validated['employee_name'],
                'designation' =>$validated['employee_designation'],
                'room_no' =>$validated['employee_room'],
                'mobile_no' =>$validated['employee_mobile'],
                'landline_no' =>$validated['employee_landline'],
                'email'=>$validated['employee_email'],
                'image' => $fileName,
                'current_status' =>$validated['employee_status'],
                'is_dept_head' =>$validated['is_dept_head'],
                'rank' => $validated['employee_rank']
             ]);

            Session::flash('message','कर्मचारीको डाटा सुरक्छित भयो।।। ');
            return redirect()->route('employee.index');
       
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function show(Employee $employee)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {
       $employee= Employee::where('id',$id)->first();
               
        if($request->ajax()){
            if(Auth::user()->user_type == "Superadmin")
            {
                $departments = Department::get();
            }
            else if(Auth::user()->user_type == "Admin")
            {
                $office_id = Auth::user()->officeUser->office_id;
                $departments = Department::where('office_id', $office_id)->get();
                
            }
            else{
                $department_id = Auth::user()->departmentUser->department_id;
                $departments = Department::where('id', $department_id)->get();
            }
                $html =  view('backend.admin.employee.partials.edit')->with(compact('employee','departments'))->render();
                return response()->json(['success'=> "success",'data'=>$employee,'html'=>$html]);
        }
        else{
            Session::flash('message','कर्मचारीको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        
        $validated = $request->validate([
            'employee_office' => 'required|integer',
            'employee_name' => 'required|string|max:50',
            'employee_designation' => 'required|string|max:50',
            'employee_mobile' => 'nullable',
            'employee_landline' => 'required',
            'employee_room' => 'required|string',
            'employee_email' => 'nullable|string',
            'employee_rank' => 'required|integer',
            'is_dept_head'=>'nullable',
            'employee_status' =>'required',
            'old_employee_image'=>'nullable',
        ]);

        $fileName =Null;
        if($request->hasFile('employee_image'))
        {
            Storage::delete('public/uploads/employee_image'.$validated['old_employee_image']);
            $fileName=time().$request->employee_image->getClientOriginalName();
            $filePath = $request->file('employee_image')->storeAs('public/uploads/employee_image', $fileName);
        }
        else
        {
            $fileName = $validated['old_employee_image'];
        }

       $employee = Employee::where('id',$id)->update([
        'department_id'=> $validated['employee_office'],
        'employee_name'=>$validated['employee_name'],
        'designation'=>$validated['employee_designation'],
        'room_no'=>$validated['employee_room'],
        'mobile_no'=>$validated['employee_mobile'],
        'landline_no'=>$validated['employee_landline'],
        'email'=>$validated['employee_email'],
        'image'=>  $fileName ,
        'current_status'=>$validated['employee_status'],
        'is_dept_head'=>$validated['is_dept_head'],
        'rank' => $validated['employee_rank']
        ]);

        Session::flash('message','कर्मचारीको डाटा परिवर्तन भयो।।। ');
        return redirect()->route('employee.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        $employee = Employee::where('id', $id)->delete();
        if($request->ajax()){
            if(Auth::user()->user_type == "Superadmin")
            {
                $employees = Employee::orderBy('rank', 'DESC')->get();
            }
            elseif(Auth::user()->user_type == "Admin")
            {
                $office_id = Auth::user()->officeUser->office_id;
                $departments = Department::where('office_id', $office_id)->get();
                $department_id = [];
                foreach($departments as $department)
                {
                    array_push($department_id, $department['id']);
                }
                $employees = Employee::whereIn('department_id', $department_id)->orderBy('rank', 'DESC')->get();
            }
            else{
                $department_id = Auth::user()->departmentUser->department_id;
                $employees = Employee::where('department_id', $department_id)->orderBy('rank', 'DESC')->get();
            }
            $html =  view('backend.admin.employee.partials.activeData')->with(compact('employees'))->render();
            return response()->json(['success'=> "success",'data'=>$employees,'html'=>$html]);
        }
        else{
            Session::flash('message','कर्मचारीको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }

    public function gridView()
    {
        if(Auth::user()->user_type == "Superadmin")
        {
            $employee_data = Employee::orderBy('rank', 'DESC')->get();
        }
        elseif(Auth::user()->user_type == "Admin")
        {
            $office_id = Auth::user()->officeUser->office_id;
            $departments = Department::where('office_id', $office_id)->get();
            $department_id = [];
            foreach($departments as $department)
            {
                array_push($department_id, $department['id']);
            }
            $employee_data = Employee::whereIn('department_id', $department_id)->orderBy('rank', 'DESC')->get();
        }
        else{
            $department_id = Auth::user()->departmentUser->department_id;
            $employee_data = Employee::where('department_id', $department_id)->orderBy('rank', 'DESC')->get();
        }
      
       return view('backend.admin.employee.gridView',compact('employee_data'));
    }

    public function status(Request $request)
    {
        if($request->ajax()){
            $employee_id = $request->employee_id;

            $employee_data = Employee::where('id', $employee_id)->update([
                'current_status' =>$request->status
            ]);
            $success = "कर्मचारीको उपलब्धता परिवर्तन भयो  ।।।";

            $html =  view('backend.admin.employee.gridView')->with(compact('employee_data'))->render();
            return response()->json(['success'=> $success,'data'=>$employee_data,'html'=>$html]);
        }
        else{
            Session::flash('message','कर्मचारीको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }

    public function publish(Request $request)
    {
        $employee_id = $request->employee_id;
        if($request->ajax()){
            $employee_data = Employee::where('id',$employee_id)->update([
                'publish' => $request->publish
            ]);
            if(Auth::user()->user_type == "Superadmin")
            {
                $employees = Employee::orderBy('rank', 'DESC')->get();
            }
            elseif(Auth::user()->user_type == "Admin")
            {
                $office_id = Auth::user()->officeUser->office_id;
                $departments = Department::where('office_id', $office_id)->get();
                $department_id = [];
                foreach($departments as $department)
                {
                    array_push($department_id, $department['id']);
                }
                $employees = Employee::whereIn('department_id', $department_id)->orderBy('rank', 'DESC')->get();
            }
            else{
                $department_id = Auth::user()->departmentUser->department_id;
                $employees = Employee::where('department_id', $department_id)->orderBy('rank', 'DESC')->get();
            }
            $success = "";
            if($request->publish == 1)
            {
                $success = "कर्मचारी प्रकासित भयो।।। ";
            }
            else{
                $success = "कर्मचारी अप्रकासित भयो।।। ";
            }
            $html =  view('backend.admin.employee.partials.activeData')->with(compact('employees'))->render();
            return response()->json(['success'=> $success,'data'=>$employees,'html'=>$html]);
        }
        else{
            Session::flash('message','कर्मचारीको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }
}
