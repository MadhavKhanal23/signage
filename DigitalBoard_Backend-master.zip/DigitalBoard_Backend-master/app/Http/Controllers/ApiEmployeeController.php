<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Illuminate\Http\Request;
use App\Http\Resources\EmployeeResource;
use App\Http\Resources\EmployeeCollection;
use App\Models\Department;
use App\Models\OfficeUser;

class ApiEmployeeController extends Controller
{
    public function index($id)
    {
        $office_user = OfficeUser::where('user_id', $id)->first();
        $departments = Department::where('office_id', $office_user->office_id)->get();
        $department_id = [];
        foreach( $departments as $depart)
        {
            array_push($department_id, $depart['id']);
        }
        $employee = Employee::where('publish',1)->whereIn('department_id', $department_id)
        ->orderBy('rank', 'DESC')->get();
        return EmployeeResource::collection($employee);
    }   
   
}
