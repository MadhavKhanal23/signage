<?php

namespace App\Http\Controllers;

use Auth;
use Redirect;
use App\Models\Office;
use App\Models\OfficeUser;
use App\Models\User;
use App\Models\Employee;
use App\Models\Department;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Storage;

class OfficeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(Auth::user()->user_type == "Superadmin")
        {
            $offices = Office::latest()->get();
            return view('backend.admin.office.index',compact('offices'));
        }
        else{
            Session::flash('message','कार्यालयको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(Auth::user()->user_type == "Superadmin")
        {
            return view('backend.admin.office.create');
        }
        else{
            Session::flash('message','नँया कार्यालयको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'officeEnglishName' => 'required|string|max:255',
            'officeNepaliName' => 'required|string|max:255',
            'officeAddress' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:offices',
            'landLineNumber' => 'required|string|min:09|max:10',
            'officeSlogan' => 'required|string',
            'officeLogo' => 'required|mimes:png,jpeg,jpg,svg'
        ]);

        $fileName =Null;
        if($request->hasFile('officeLogo'))
        {
            $fileName=time().$request->officeLogo->getClientOriginalName();
            $filePath = $request->file('officeLogo')->storeAs('public/uploads/office_logo', $fileName);
        }

        $office = Office::create([
            'english_name' => $validated['officeEnglishName'],
            'nepali_name' => $validated['officeNepaliName'],
            'address' => $validated['officeAddress'],
            'email' => $validated['email'],
            'landline_number' => $validated['landLineNumber'],
            'slogan' => $validated['officeSlogan'],
            'logo' => $fileName
        ]);

        Session::flash('message','कार्यालयको डाटा सुरक्छित भयो !');
        return redirect()->route('office.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Office  $office
     * @return \Illuminate\Http\Response
     */
    public function show(Office $office)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Office  $office
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, $id)
    {   
        if($request->ajax()){
            $office_id = $id;
            $office = Office::where('id', $office_id)->first();
            $message = "परिवर्तनको डाटा भर्नुहोस् ।।।";

            
            $html =  view('backend.admin.office.partials.edit')->with(compact('office'))->render();
            return response()->json(['success'=> "success",'message'=>$message,'data'=>$office,'html'=>$html]);
        }
        else{
            Session::flash('message','कार्यालयको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Office  $office
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
        $office_id = $id;

        $validated = $request->validate([
            'officeEnglishName' => 'required|string|max:255',
            'officeNepaliName' => 'required|string|max:255',
            'officeAddress' => 'required|string|max:255',
            'email' => 'required|string|email|max:255',
            'landLineNumber' => 'required|string|min:9|max:10',
            'officeSlogan' => 'required|string',
            'oldOfficeLogo'=> 'sometimes|string',
            'officeLogo' => 'sometimes|mimes:png,jpeg,jpg,svg'
        ]);
        $fileName =Null;
        if($request->hasFile('logo_file'))
        {
            Storage::delete('public/uploads/office_logo'.$validated['oldOfficeLogo']);
            $fileName=time().$request->logo_file->getClientOriginalName();
            $filePath = $request->file('logo_file')->storeAs('public/uploads/office_logo', $fileName);
        }
        else
        {
            $fileName = $validated['oldOfficeLogo'];
        }
        
        $officeUpdate = Office::where('id', $office_id)->update([
            'english_name' => $validated['officeEnglishName'],
            'nepali_name' => $validated['officeNepaliName'],
            'address' => $validated['officeAddress'],
            'email' => $validated['email'],
            'landline_number' => $validated['landLineNumber'],
            'slogan' => $validated['officeSlogan'],
            'logo' => $fileName
        ]);

        Session::flash('message','कार्यालयको डाटा परिवर्तन भयो !');
        return redirect()->route('office.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Office  $office
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        if($request->ajax()){
            $office_id = $id;

            $office_delete = Office::where('id', $office_id)->delete();
            $officeUSers= OfficeUser::where('office_id', $office_id)->get();
            $officeUSer_delete= OfficeUser::where('office_id', $office_id)->delete();

            foreach($officeUSers as $user)
            {
                User::where('id', $user['user_id'])->delete();
            }

            $offices = Office::all();
            $message = "कार्यालयको डाटा सफलता पुर्बक हटाएयो ।।।";
            
                $html =  view('backend.admin.office.partials.activeData')->with(compact('offices'))->render();
                return response()->json(['success'=> "success",'message'=>$message, 'html'=>$html]);
        }
        else{
            Session::flash('message','कार्यालयको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
        
    }

    public function gridView()
    {
        if(Auth::user()->user_type == "Superadmin")
        {
            $office_data= Office::latest()->get();
            return view('backend.admin.office.gridView',compact('office_data'));
        }
        else{
            Session::flash('message','कार्यालयको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }
}
