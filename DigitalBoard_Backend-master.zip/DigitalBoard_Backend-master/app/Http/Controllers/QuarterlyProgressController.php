<?php

namespace App\Http\Controllers;

use App\Models\Budget;
use App\Models\Office;
use App\Models\OfficeUser;
use App\Models\Quarter;
use App\Models\QuarterlyProgress;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Auth;

class QuarterlyProgressController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(Auth::user()->user_type == "Superadmin")
        {
            $quarterly_progress = QuarterlyProgress::latest()->with('office', 'budget')->get();
        }
        else if(Auth::user()->user_type == "Admin")
        {
            $office_id = Auth::user()->officeUser->office_id;
            $quarterly_progress = QuarterlyProgress::where('office_id', $office_id)->latest()->with('office', 'budget')->get();
        }
        else{
            Session::flash('message','प्रगति प्रतिबेदनको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
        return view('backend.admin.progress.quarterlyProgress.index', compact('quarterly_progress'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $quarters = Quarter::get();
        if(Auth:: user()->user_type == "Superadmin")
        {
            $office_data = Office::all();
        }
        elseif(Auth::user()->user_type == "Admin" )
        {
            $office_id = Auth::user()->officeUser->office_id;
            $office_data = Office::where('id', $office_id)->latest()->get();
        }
        else{
            Session::flash('message','प्रगति प्रतिबेदनको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
        return view('backend.admin.progress.quarterlyProgress.create', compact('quarters','office_data'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'quarterlyProgress_office' => 'required|integer',
            'quarterlyProgress_quarter' => 'required|integer',
            'quarter_current_budget' => 'required|numeric',
            'quarter_spend_budget' => 'required|numeric|lte:quarter_current_budget',
            'quarter_capital_budget' => 'required|numeric',
            'quarter_capital_spend_budget' => 'required|numeric|lte:quarter_capital_budget'
        ]);

        DB::transaction(function()use($request,$validated){
            $budget = Budget::create([
                'current_total_budget' => $validated['quarter_current_budget'],
                'current_spend_budget' => $validated['quarter_spend_budget'],
                'capital_total_budget' => $validated['quarter_capital_budget'],
                'capital_spend_budget' => $validated['quarter_capital_spend_budget']
            ]);

            $quarterlyProgress = quarterlyProgress::create([
                'office_id' => $validated['quarterlyProgress_office'],
                'quarter_id' => $validated['quarterlyProgress_quarter'],
                'budget_id' => $budget['id']
            ]); 
        });

        Session::flash('message',' त्रैमासिक प्रगति प्रतिबेदन सुरक्छित भयो ।।।');
        return redirect()->route('quarterly_progress.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\QuarterlyProgress  $quarterlyProgress
     * @return \Illuminate\Http\Response
     */
    public function show(QuarterlyProgress $quarterlyProgress)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\QuarterlyProgress  $quarterlyProgress
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, $id)
    {
        $quarterly_progress_id = $id;
        if($request->ajax()){
            $quarterlyProgress = QuarterlyProgress::where('id', $quarterly_progress_id)->first();
            $quarters = Quarter::get();
            if(Auth:: user()->user_type == "Superadmin")
            {
                $office_data = Office::all();
            }
            elseif(Auth::user()->user_type == "Admin" )
            {
                $office_id = Auth::user()->officeUser->office_id;
                $office_data = Office::where('id', $office_id)->latest()->get();
            }
            $html =  view('backend.admin.progress.quarterlyProgress.partials.edit')->with(compact('quarterlyProgress','office_data','quarters'))->render();
            return response()->json(['success'=> "success",'data'=>$quarterlyProgress,'html'=>$html]);
        }
        else
        {
            Session::flash('message','प्रगति प्रतिबेदनको लागि अनुमति छैन ।।।');
            return redirect()->route('dashboard');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\QuarterlyProgress  $quarterlyProgress
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $quarterly_progress = QuarterlyProgress::where('id', $id)->first();
        $budget_id = $quarterly_progress['budget_id'];
        $validated = $request->validate([
            'quarterlyProgress_office' => 'required|integer',
            'quarterlyProgress_quarter' => 'required|integer',
            'quarter_current_budget' => 'required|numeric',
            'quarter_spend_budget' => 'required|numeric|lte:quarter_current_budget',
            'quarter_capital_budget' => 'required|numeric',
            'quarter_capital_spend_budget' => 'required|numeric|lte:quarter_capital_budget'
        ]);
        
        DB::transaction(function()use($request, $validated, $id, $budget_id){
            $budget = Budget::where('id', $budget_id)->update([
                'current_total_budget' => $validated['quarter_current_budget'],
                'current_spend_budget' => $validated['quarter_spend_budget'],
                'capital_total_budget' => $validated['quarter_capital_budget'],
                'capital_spend_budget' => $validated['quarter_capital_spend_budget']
            ]);

            $quarterlyProgress = QuarterlyProgress::where('id', $id)->update([
                'office_id' => $validated['quarterlyProgress_office'],
                'quarter_id' => $validated['quarterlyProgress_quarter'],
                'budget_id' => $budget_id
            ]); 
        });

        Session::flash('message',' त्रैमासिक प्रगति प्रतिबेदन परिवर्तन भयो ।।।');
        return redirect()->route('quarterly_progress.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\QuarterlyProgress  $quarterlyProgress
     * @return \Illuminate\Http\Response
     */
    public function destroy(QuarterlyProgress $quarterlyProgress)
    {
        //
    }
}
