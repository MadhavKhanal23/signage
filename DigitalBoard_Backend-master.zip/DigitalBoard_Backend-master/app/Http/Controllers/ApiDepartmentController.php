<?php

namespace App\Http\Controllers;

use App\Http\Resources\DepartmentResource;
use App\Models\Department;
use App\Models\Office;
use App\Models\OfficeUser;
use Illuminate\Http\Request;
use SebastianBergmann\Environment\Console;

class ApiDepartmentController extends Controller
{
    public function index($id)
    {
        $office_user = OfficeUser::where('user_id', $id)->first();
        $office = Office::where('id', $office_user->office_id)->first();
        $office_id = $office['id'];
        $departments = Department::where('office_id', $office_id)->with('mahaaSakha')->latest()->get();
        return DepartmentResource::collection($departments);
    }
}
