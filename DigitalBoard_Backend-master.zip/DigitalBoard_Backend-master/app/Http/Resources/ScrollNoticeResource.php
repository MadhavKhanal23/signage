<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ScrollNoticeResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return 
        [
            'title' => $this->notice_title,
            'description' => $this->notice_description,
            'display_from' => $this->display_from,
            'display_to' => $this->display_to

        ];
    }
}
