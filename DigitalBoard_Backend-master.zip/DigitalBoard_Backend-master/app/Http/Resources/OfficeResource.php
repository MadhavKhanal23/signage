<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class OfficeResource extends JsonResource
{
    /**
     * Transform the resource collection into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'name'=>$this->nepali_name,
            'english_name'=>$this->english_name,
            'logo'=>$this->logo,
            'address'=>$this->address,
            'email'=>$this->email,
            'landline_number'=>$this->landline_number,
            'slogan'=>$this->slogan
        ];
    }
}
