<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class QuarterlyProgressResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'office' => $this->office->nepali_name,
            'quarter'=>$this->quarter->quarter_name,
            'current total budget'=> $this->budget->current_total_budget,
            'current spend budget'=> $this->budget->current_spend_budget,
            'capital budget'=> $this->budget->capital_total_budget,
            'capital spend budget'=> $this->budget->capital_spend_budget
        ];
    }
}
