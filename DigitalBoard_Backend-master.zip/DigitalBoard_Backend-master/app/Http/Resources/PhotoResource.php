<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class PhotoResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'photo_title' =>$this->photo_title,
            'photo_image'=>$this->photo_image,
            'category' =>$this->category->category,
            'photo_description'=>$this->description,
            'display_from'=> $this->display_from,
            "display_to" => $this->display_to,
            'display_time' => $this->display_time,
            'is_important' =>$this->is_important
        ];
    }
}
