<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class EmployeeResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return[
            'Department'=>$this->department->department_name,
            'Name'=>$this->employee_name,
            'Designation'=>$this->designation,
            'Email'=>$this->email,
            'Mobile_no'=>$this->mobile_no,
            'Landline_no'=>$this->landline_no,
            'Is_dept_head'=>$this->is_dept_head,
            'Employee image'=>$this->image,
            'Current_status'=>$this->current_status,
            'floor_no' => $this->department['floor_no'],
            'room_no'=>$this->room_no
        ];
    }
}
