<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class CitizenCharterResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'title' => $this->citizen_charter_title,
            'service_type'=> $this->service_type,
            'service_time'=>$this->service_time,
            'service_charge'=>$this->service_charge,
            'citizen_charter_department' => $this->department->department_name,
            'citizen_charter_employee' => $this->employee->designation,
            'important_document' => $this->important_document,

        ];
    }
}
