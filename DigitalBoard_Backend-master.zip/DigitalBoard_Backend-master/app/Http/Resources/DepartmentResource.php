<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class DepartmentResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $mahaaSakha_name = '';
        if($this->type == "शाखा")
        {
            if($this->mahaaSakha->mahaaSakha_name != null){
                $mahaaSakha_name = $this->mahaaSakha->mahaaSakha_name['department_name'];
            }
        }
        return[
            'office_name' => $this->office->nepali_name,
            'department_type' => $this->type,
            'mahaaSakha_name' => $mahaaSakha_name,
            'department_name' => $this->department_name,
            'department_email' => $this->email,
            'contact_no.'=> $this->landline_number,
            'floor_no' => $this->floor_no,
            'room_number' => $this->room_no,
            'department_services' => $this->department_services,
        ];
    }
}
