<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class MahaasakhaSakha extends Model
{
    use HasFactory, SoftDeletes;
    protected $table= 'mahaasakha_sakhas';
    protected $guarded =[];


    public function mahaaSakha_name()
    {
        return $this->belongsTo('App\Models\Department', 'mahasakha_id', 'id');
    }
}
