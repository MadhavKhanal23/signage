<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class QuarterlyProgress extends Model
{
    use HasFactory, SoftDeletes;
    protected $table= 'quarterly_progress';
    protected $guarded =[];

    public function quarter()
    {
        return $this->belongsTo('App\Models\Quarter','quarter_id', 'id');
    }

    public function budget()
    {
        return $this->hasOne('App\Models\Budget', 'id', 'budget_id');
    }

    public function office()
    {
        return $this->belongsTo('App\Models\Office', 'office_id', 'id');
    }
}
