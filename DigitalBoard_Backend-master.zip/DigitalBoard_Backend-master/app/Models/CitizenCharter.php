<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class CitizenCharter extends Model
{
    use HasFactory,SoftDeletes;
    protected $table="citizen_charters";
    protected $guarded = [];

    public function department(){
        return $this->belongsTo('App\Models\Department','department_id','id');
    }
    public function employee(){
        return $this->belongsTo('App\Models\Employee','employee_id','id');
    }
}
