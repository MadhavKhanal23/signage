<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class MonthlyProgress extends Model
{
    use HasFactory, SoftDeletes;
    protected $table= 'monthly_progress';
    protected $guarded =[];

    public function month()
    {
        return $this->belongsTo('App\Models\Month','month_id', 'id');
    }

    public function budget()
    {
        return $this->hasOne('App\Models\Budget', 'id', 'budget_id');
    }

    public function office()
    {
        return $this->belongsTo('App\Models\Office', 'office_id', 'id');
    }
}
