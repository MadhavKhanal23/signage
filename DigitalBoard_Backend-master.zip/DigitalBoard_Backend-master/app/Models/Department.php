<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Department extends Model
{
    use HasFactory, SoftDeletes;
    protected $table= 'departments';
    protected $guarded =[];

    public function office()
    {
        return $this->belongsTo('App\Models\Office','office_id','id');
    }

    public function mahaaSakha()
    {
        return $this->belongsTo('App\Models\MahaasakhaSakha', 'id', 'sakha_id');
    }
}
