<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ApiUserController;
use App\Http\Controllers\ApiCitizenCharterController;
use App\Http\Controllers\ApiScrollNoticeController;
use App\Http\Controllers\ApiPhotoController;
use App\Http\Controllers\ApiEmployeeController;
use App\Http\Controllers\ApiOfficeController;
use App\Http\Controllers\ApiMonthProgressController;
use App\Http\Controllers\ApiQuarterlyProgressController;
use App\Http\Controllers\ApiYearlyProgressController;
use App\Http\Controllers\ApiDepartmentController;



/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

// route for login user and return user data
Route::post("userLogin",[ApiUserController::class,'login']);

Route::group(['middleware' => 'auth:sanctum'], function(){

    //route for citizen_charter
    Route::get('citizen_charter/{id}',[ApiCitizenCharterController::class,"index"]);

    //route for employee
    Route::get('employee/{id}',[ApiEmployeeController::class, "index"]);

    //route for office
    Route::get('office/{id}',[ApiOfficeController::class, "index"]);

    //route for department
    Route::get('department/{id}', [ApiDepartmentController::class, "index"]);

    //route for scroll_notice
    Route::get('scroll_notice/{id}',[ApiScrollNoticeController::class, "index"]);

    //route for phpto
    Route::get('photo/{id}',[ApiPhotoController::class, "index"]);

    //route for monthlyprogress
    Route::get('monthlyprogress/{id}',[ApiMonthProgressController::class, "index"]);

    //route for yearlyprogress
    Route::get('yearlyprogress/{id}',[ApiYearlyProgressController::class, "index"]);

    //route for quarterlyprogress
    Route::get('quarterlyprogress/{id}',[ApiQuarterlyProgressController::class, "index"]);
});
