<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\VideoController;
use App\Http\Controllers\LargeImageController;
use App\Http\Controllers\OfficeController;
use App\Http\Controllers\ScrollNoticeController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\CitizenCharterController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ImageCategoryController;
use App\Http\Controllers\MonthlyProgressController;
use App\Http\Controllers\PhotoController;
use App\Http\Controllers\ProjectController;
use App\Http\Controllers\QuarterlyProgressController;
use App\Http\Controllers\QuaterlyProgressController;
use App\Http\Controllers\YearlyProgressController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Route::get('/dashboard', function () {
//     return view('dashboard');
// })->middleware(['auth'])->name('dashboard');

require __DIR__.'/auth.php';

Route::group(['middleware' => 'auth'], function(){

    Route::get('/dashboard', [HomeController::class, 'index'])->name('dashboard');
    // route for user 
    Route::get('/users/index', [UserController::class, 'index'])->name('user.index');
    Route::post('/user/update', [UserController::class, 'update'])->name('user.update');
    Route::post('/user/delete', [UserController::class, 'delete'])->name('user.delete');
    Route::get('/user/edit', [UserController::class, 'edit'])->name('user.edit');
    Route::get('/register/department', [UserController::class, 'department'])->name('user.department');

    // route for office
    Route::get('office/gridView', [OfficeController::class, 'gridView'])->name('office.gridView');
    Route::resource('office', OfficeController::class);

    // route for CitizenCharter
    Route::PUT('citizen_charter/publish',[CitizenCharterController::class,'PublishCitizen'])->name('citizen_charter.publish');
    Route::resource('citizen_charter',CitizenCharterController::class);


    // route for photo
    Route::PUT('photo/publish', [PhotoController::class, 'publish'])->name('photo.publish');
    Route::resource('photo', PhotoController::class);

    // route for Department
    Route::resource('department', DepartmentController::class);

    // route for Employees
    Route::PUT('employee/publish',[EmployeeController::class, 'publish'])->name('employee.publish');
    Route::PUT('employee/status', [EmployeeController::class, 'status'])->name('employee.status');
    Route::get('employee/gridView', [EmployeeController::class,'gridView'])->name('employee.gridView');
    Route::resource('employee', EmployeeController::class);

    // route for ScrollNotice
    Route::PUT('scroll_notice/publish',[ScrollNoticeController::class,'publish'])->name('scroll_notice.publish');
    Route::resource('scroll_notice', ScrollNoticeController::class);

    // route for Monthly Progress
    Route::resource('monthly_progress', MonthlyProgressController::class);

    // route for Yearly Progress
    Route::resource('yearly_progress', YearlyProgressController::class);

    // route for quaterly progress
    Route::resource('quarterly_progress', QuarterlyProgressController::class);

    // route for image Category
    Route::resource('image_category', ImageCategoryController::class);
});